# WordPress MySQL database migration
#
# Generated: Thursday 12. July 2018 22:34 UTC
# Hostname: localhost
# Database: `lawyersdirectory`
# URL: //lawyers-directory.com
# Path: /Applications/MAMP/htdocs/lawyer-directory--worpdress
# Tables: wp_commentmeta, wp_comments, wp_hook_list, wp_links, wp_options, wp_pmxi_files, wp_pmxi_history, wp_pmxi_images, wp_pmxi_imports, wp_pmxi_posts, wp_pmxi_templates, wp_postmeta, wp_posts, wp_swp_cf, wp_swp_index, wp_swp_log, wp_swp_tax, wp_swp_terms, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, garrett_cpt, lawfirm, lawfirms, page, post, test
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_hook_list`
#

DROP TABLE IF EXISTS `wp_hook_list`;


#
# Table structure of table `wp_hook_list`
#

CREATE TABLE `wp_hook_list` (
  `called_by` varchar(96) NOT NULL,
  `hook_name` varchar(96) NOT NULL,
  `hook_type` varchar(15) NOT NULL,
  `first_call` int(11) NOT NULL,
  `arg_count` tinyint(4) NOT NULL,
  `file_name` varchar(128) NOT NULL,
  `line_num` smallint(6) NOT NULL,
  PRIMARY KEY (`first_call`,`hook_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_hook_list`
#

#
# End of data contents of table `wp_hook_list`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2815 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://lawyers-directory.com', 'yes'),
(2, 'home', 'http://lawyers-directory.com', 'yes'),
(3, 'blogname', 'Lawyers Directory', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'garrettcullen@yahoo.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:140:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:10:"lawfirm/?$";s:27:"index.php?post_type=lawfirm";s:40:"lawfirm/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=lawfirm&feed=$matches[1]";s:35:"lawfirm/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=lawfirm&feed=$matches[1]";s:27:"lawfirm/page/([0-9]{1,})/?$";s:45:"index.php?post_type=lawfirm&paged=$matches[1]";s:7:"test/?$";s:24:"index.php?post_type=test";s:37:"test/feed/(feed|rdf|rss|rss2|atom)/?$";s:41:"index.php?post_type=test&feed=$matches[1]";s:32:"test/(feed|rdf|rss|rss2|atom)/?$";s:41:"index.php?post_type=test&feed=$matches[1]";s:24:"test/page/([0-9]{1,})/?$";s:42:"index.php?post_type=test&paged=$matches[1]";s:45:"lawfirm_practiceareas/([^/]+)/([^/]+)/([^/]+)";s:81:"index.php?lawfirm_pa=$matches[1]&currentstate=$matches[2]&currentcity=$matches[3]";s:37:"lawfirm_practiceareas/([^/]+)/([^/]+)";s:57:"index.php?lawfirm_pa=$matches[1]&currentstate=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:56:"lawfirm_locations/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:56:"index.php?lawfirm_locations=$matches[1]&feed=$matches[2]";s:51:"lawfirm_locations/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:56:"index.php?lawfirm_locations=$matches[1]&feed=$matches[2]";s:32:"lawfirm_locations/(.+?)/embed/?$";s:50:"index.php?lawfirm_locations=$matches[1]&embed=true";s:44:"lawfirm_locations/(.+?)/page/?([0-9]{1,})/?$";s:57:"index.php?lawfirm_locations=$matches[1]&paged=$matches[2]";s:26:"lawfirm_locations/(.+?)/?$";s:39:"index.php?lawfirm_locations=$matches[1]";s:62:"lawfirm_practiceareas/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?lawfirm_practiceareas=$matches[1]&feed=$matches[2]";s:57:"lawfirm_practiceareas/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?lawfirm_practiceareas=$matches[1]&feed=$matches[2]";s:38:"lawfirm_practiceareas/([^/]+)/embed/?$";s:54:"index.php?lawfirm_practiceareas=$matches[1]&embed=true";s:50:"lawfirm_practiceareas/([^/]+)/page/?([0-9]{1,})/?$";s:61:"index.php?lawfirm_practiceareas=$matches[1]&paged=$matches[2]";s:32:"lawfirm_practiceareas/([^/]+)/?$";s:43:"index.php?lawfirm_practiceareas=$matches[1]";s:33:"lawfirm/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"lawfirm/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"lawfirm/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"lawfirm/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"lawfirm/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"lawfirm/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"lawfirm/(.+?)/embed/?$";s:40:"index.php?lawfirm=$matches[1]&embed=true";s:26:"lawfirm/(.+?)/trackback/?$";s:34:"index.php?lawfirm=$matches[1]&tb=1";s:46:"lawfirm/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?lawfirm=$matches[1]&feed=$matches[2]";s:41:"lawfirm/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?lawfirm=$matches[1]&feed=$matches[2]";s:34:"lawfirm/(.+?)/page/?([0-9]{1,})/?$";s:47:"index.php?lawfirm=$matches[1]&paged=$matches[2]";s:41:"lawfirm/(.+?)/comment-page-([0-9]{1,})/?$";s:47:"index.php?lawfirm=$matches[1]&cpage=$matches[2]";s:30:"lawfirm/(.+?)(?:/([0-9]+))?/?$";s:46:"index.php?lawfirm=$matches[1]&page=$matches[2]";s:32:"test/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"test/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"test/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"test/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"test/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"test/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"test/([^/]+)/embed/?$";s:37:"index.php?test=$matches[1]&embed=true";s:25:"test/([^/]+)/trackback/?$";s:31:"index.php?test=$matches[1]&tb=1";s:45:"test/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?test=$matches[1]&feed=$matches[2]";s:40:"test/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?test=$matches[1]&feed=$matches[2]";s:33:"test/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?test=$matches[1]&paged=$matches[2]";s:40:"test/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?test=$matches[1]&cpage=$matches[2]";s:29:"test/([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?test=$matches[1]&page=$matches[2]";s:21:"test/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"test/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"test/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"test/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"test/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"test/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=96&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'lawyerdirectory', 'yes'),
(41, 'stylesheet', 'lawyerdirectory', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:3:{s:41:"wp-rest-api-cache/class-wp-rest-cache.php";a:2:{i:0;s:13:"WP_REST_Cache";i:1;s:11:"empty_cache";}s:31:"debug-objects/debug-objects.php";a:2:{i:0;s:13:"Debug_Objects";i:1;s:12:"on_uninstall";}s:45:"debug-objects/inc/autoload/class-settings.php";a:2:{i:0;s:22:"Debug_Objects_Settings";i:1;s:19:"unregister_settings";}}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '96', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:3:{i:2;a:1:{s:5:"title";s:0:"";}i:3;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:7:"sidebar";a:1:{i:0;s:8:"search-3";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(104, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'cron', 'a:6:{i:1531436392;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1531447947;a:1:{s:20:"relevanssi_trim_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1531461069;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1531504279;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1531510388;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(120, 'can_compress_scripts', '1', 'no'),
(135, 'recently_activated', 'a:0:{}', 'yes'),
(136, 'acf_version', '5.7.0', 'yes'),
(137, 'mtphr_post_duplicator_settings', '', 'yes'),
(140, 'theme_mods_twentyseventeen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1522783944;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(141, 'current_theme', '', 'yes'),
(142, 'theme_mods_lawyerdirectory', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1526659571;s:4:"data";a:1:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(143, 'theme_switched', '', 'yes'),
(148, 'lawfirm-cate_children', 'a:2:{i:2;a:1:{i:0;i:3;}i:4;a:1:{i:0;i:5;}}', 'yes'),
(149, 'acf_to_rest_api_request_version', '3', 'yes'),
(155, 'lawfirm-cat_children', 'a:2:{i:6;a:1:{i:0;i:8;}i:7;a:1:{i:0;i:9;}}', 'yes'),
(229, 'PMXI_Plugin_Options', 'a:32:{s:12:"info_api_url";s:26:"http://www.wpallimport.com";s:16:"dismiss_speed_up";i:1;s:18:"history_file_count";i:10000;s:16:"history_file_age";i:365;s:15:"highlight_limit";i:10000;s:19:"upload_max_filesize";i:2048;s:13:"post_max_size";i:2048;s:14:"max_input_time";i:-1;s:18:"max_execution_time";i:-1;s:7:"dismiss";i:0;s:13:"html_entities";i:0;s:11:"utf8_decode";i:0;s:12:"cron_job_key";s:4:"Mxt7";s:10:"chunk_size";i:32;s:9:"pingbacks";i:1;s:33:"legacy_special_character_handling";i:1;s:14:"case_sensitive";i:1;s:12:"session_mode";s:7:"default";s:17:"enable_ftp_import";i:0;s:16:"large_feed_limit";i:1000;s:26:"cron_processing_time_limit";i:120;s:6:"secure";i:1;s:11:"log_storage";i:5;s:10:"cron_sleep";s:0:"";s:4:"port";s:0:"";s:16:"google_client_id";s:0:"";s:16:"google_signature";s:0:"";s:8:"licenses";a:1:{s:11:"PMXI_Plugin";s:128:"NmIwMjRiNTVlYjkwYTZiOTQ4ZWExNDAzOTUzMGFhNmFlOTBlNWFiNzg4NjZkMThhNTBhODUyNzM2Yjg5OTYyNzAwMzhmZTU4YTdjZjliMTkzMmE4MjZjMTA4MGY3ZjYz";}s:8:"statuses";a:1:{s:11:"PMXI_Plugin";s:5:"valid";}s:19:"force_stream_reader";i:0;s:18:"scheduling_license";s:0:"";s:25:"scheduling_license_status";s:0:"";}', 'yes'),
(235, 'pmxi_is_migrated', '4.5.2', 'yes'),
(236, 'wp_all_import_db_version', '4.5.2', 'yes'),
(248, 'PMAI_Plugin_Options', 'a:0:{}', 'yes'),
(251, 'se_meta', 'a:10:{s:7:"blog_id";b:0;s:7:"api_key";b:0;s:8:"auth_key";b:0;s:7:"version";s:5:"8.1.9";s:13:"first_version";s:5:"8.1.9";s:8:"new_user";b:1;s:4:"name";s:0:"";s:5:"email";s:0:"";s:24:"show_options_page_notice";b:0;s:16:"se_global_notice";a:2:{s:5:"title";s:28:"Searching for your car keys?";s:7:"message";s:324:"Well, there are some things our plugin can\'t search for - your car keys, your wallet, a soulmate and <strong>unregistered custom post types</strong> :) <br> It searches for almost everything else, but it also does some other amazing stuff, like ... research. <a href="http://zem.si/1l7q5KS" target="_blank">Check it out!</a>";}}', 'yes'),
(252, 'se_options', 'a:21:{s:21:"se_exclude_categories";s:0:"";s:26:"se_exclude_categories_list";s:0:"";s:16:"se_exclude_posts";s:0:"";s:21:"se_exclude_posts_list";s:0:"";s:18:"se_use_page_search";b:0;s:21:"se_use_comment_search";b:1;s:17:"se_use_tag_search";b:1;s:17:"se_use_tax_search";b:1;s:22:"se_use_category_search";b:1;s:25:"se_approved_comments_only";b:0;s:22:"se_approved_pages_only";b:0;s:21:"se_use_excerpt_search";b:0;s:19:"se_use_draft_search";b:0;s:24:"se_use_attachment_search";b:0;s:14:"se_use_authors";b:0;s:18:"se_use_cmt_authors";b:0;s:22:"se_use_metadata_search";b:1;s:16:"se_use_highlight";b:1;s:18:"se_highlight_color";s:6:"orange";s:18:"se_highlight_style";s:0:"";s:19:"se_research_metabox";a:2:{s:18:"visible_on_compose";b:1;s:23:"external_search_enabled";b:0;}}', 'yes'),
(421, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1531434849;}', 'no'),
(524, 'relevanssi_trim_logs', '10', 'yes'),
(552, 'widget_ep-related-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(553, 'widget_ep-facet', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(607, 'algolia_application_id', '2J8AZGPKXS', 'yes'),
(608, 'algolia_search_api_key', '5972e743c7391b2ac6154581ab1d8ed3', 'yes'),
(609, 'algolia_api_key', '7528d7e4962a10f9f49b34963fbf93e1', 'yes'),
(610, 'algolia_synced_indices_ids', 'a:0:{}', 'yes'),
(611, 'algolia_autocomplete_enabled', 'yes', 'yes'),
(612, 'algolia_autocomplete_config', 'a:1:{i:0;a:7:{s:8:"index_id";s:13:"posts_lawfirm";s:10:"index_name";s:16:"wp_posts_lawfirm";s:5:"label";s:8:"Lawfirms";s:10:"admin_name";s:8:"Lawfirms";s:8:"position";i:10;s:15:"max_suggestions";i:5;s:15:"tmpl_suggestion";s:28:"autocomplete-post-suggestion";}}', 'yes'),
(613, 'algolia_override_native_search', 'instantsearch', 'yes'),
(614, 'algolia_index_name_prefix', 'wp_', 'yes'),
(615, 'algolia_api_is_reachable', 'yes', 'yes'),
(616, 'algolia_powered_by_enabled', 'yes', 'yes'),
(709, 'active_plugins', 'a:10:{i:0;s:31:"query-monitor/query-monitor.php";i:1;s:41:"acf-theme-code-pro/acf_theme_code_pro.php";i:2;s:41:"acf-to-rest-api/class-acf-to-rest-api.php";i:3;s:34:"advanced-custom-fields-pro/acf.php";i:4;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:5;s:47:"monkeyman-rewrite-analyzer/rewrite-analyzer.php";i:6;s:38:"post-duplicator/m4c-postduplicator.php";i:7;s:39:"wp-all-import-pro/wp-all-import-pro.php";i:8;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";i:9;s:35:"wpai-acf-add-on/wpai-acf-add-on.php";}', 'yes'),
(710, 'upload_path', '', 'yes'),
(711, 'upload_url_path', '', 'yes'),
(733, 'theme_mods_starter-theme', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1527471337;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:7:"sidebar";a:1:{i:0;s:8:"search-3";}}}}', 'yes'),
(893, 'searchwp_settings', 'a:20:{s:7:"engines";a:1:{s:7:"default";a:4:{s:4:"post";a:3:{s:7:"enabled";b:0;s:7:"weights";a:7:{s:3:"tax";a:3:{s:8:"category";i:0;s:8:"post_tag";i:0;s:11:"post_format";i:0;}s:5:"title";i:80;s:7:"content";i:63;s:7:"excerpt";i:40;s:4:"slug";i:60;s:2:"cf";a:0:{}s:7:"comment";i:1;}s:7:"options";a:4:{s:7:"exclude";s:0:"";s:12:"attribute_to";s:1:"0";s:6:"parent";s:1:"0";s:4:"stem";s:1:"0";}}s:4:"page";a:3:{s:7:"enabled";b:0;s:7:"weights";a:5:{s:3:"tax";a:0:{}s:5:"title";i:80;s:7:"content";i:5;s:4:"slug";i:60;s:7:"comment";i:1;}s:7:"options";a:4:{s:7:"exclude";s:0:"";s:12:"attribute_to";s:1:"0";s:6:"parent";s:1:"0";s:4:"stem";s:1:"0";}}s:10:"attachment";a:3:{s:7:"enabled";b:0;s:7:"weights";a:6:{s:3:"tax";a:0:{}s:5:"title";i:80;s:7:"content";i:5;s:7:"excerpt";i:40;s:4:"slug";i:60;s:7:"comment";i:0;}s:7:"options";a:4:{s:7:"exclude";s:0:"";s:12:"attribute_to";s:1:"0";s:6:"parent";s:1:"0";s:4:"stem";s:1:"0";}}s:7:"lawfirm";a:3:{s:7:"enabled";b:1;s:7:"weights";a:7:{s:3:"tax";a:2:{s:10:"lawfirmcat";i:0;s:11:"lawfirmtags";i:0;}s:5:"title";i:80;s:7:"content";i:1;s:7:"excerpt";i:1;s:4:"slug";i:1;s:2:"cf";a:1:{s:37:"swppv392afd24ae518db932aadbf44b8f7988";a:2:{s:7:"metakey";s:25:"attorneys_0_attorney_name";s:6:"weight";i:77;}}s:7:"comment";i:1;}s:7:"options";a:4:{s:7:"exclude";s:0:"";s:12:"attribute_to";s:1:"0";s:6:"parent";s:1:"0";s:4:"stem";s:1:"0";}}}}s:9:"activated";b:1;s:9:"dismissed";a:2:{s:16:"filter_conflicts";a:0:{}s:4:"nags";a:0:{}}s:7:"notices";a:0:{}s:20:"valid_db_environment";b:0;s:15:"ignored_queries";b:0;s:6:"remote";b:0;s:11:"remote_meta";b:0;s:14:"nuke_on_delete";b:0;s:16:"initial_settings";b:1;s:19:"initial_index_built";b:1;s:5:"stats";a:5:{s:13:"last_activity";i:1526841283;s:5:"total";i:9;s:9:"remaining";i:0;s:4:"done";i:9;s:10:"in_process";b:0;}s:7:"running";b:0;s:6:"paused";b:0;s:22:"processing_purge_queue";b:0;s:7:"utf8mb4";s:1:"1";s:8:"endpoint";s:0:"";s:14:"legacy_engines";b:0;s:11:"index_dirty";b:0;s:10:"basic_auth";s:2:"no";}', 'yes'),
(894, 'searchwp_settings_backup', 'a:0:{}', 'no'),
(895, 'searchwp_indexer', 'a:5:{s:19:"initial_index_built";b:1;s:5:"stats";a:5:{s:13:"last_activity";i:1526841283;s:5:"total";i:9;s:9:"remaining";i:0;s:4:"done";i:9;s:10:"in_process";b:0;}s:7:"running";b:0;s:6:"paused";b:0;s:22:"processing_purge_queue";b:0;}', 'no'),
(896, 'searchwp_purge_queue', 'a:0:{}', 'no'),
(897, 'searchwp_progress', '100.00', 'no'),
(898, 'searchwp_utf8mb4', '1', 'no'),
(899, 'searchwp_version', '2.9.13', 'no'),
(904, 'searchwp_busy', '', 'no'),
(905, 'searchwp_delta_attempts', '0', 'no'),
(913, 'searchwp_waiting', '', 'no'),
(920, 'searchwp_license_status', 'valid', 'yes'),
(921, 'searchwp_license_expiration', '1558310399', 'yes'),
(922, 'searchwp_license_key', 'c1902b06a686a266c7b7659145b63dac', 'yes'),
(966, 'theme_mods_twentyfifteen', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1527471340;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-1";a:1:{i:0;s:8:"search-3";}}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(972, 'edd_sl_cbf9838b6f938d3fe3d1b838530ce01b', 'a:2:{s:7:"timeout";i:1526851296;s:5:"value";s:168578:"{"new_version":"2.9.13","stable_version":"2.9.13","name":"SearchWP","slug":"searchwp","url":"https:\\/\\/searchwp.com\\/downloads\\/searchwp\\/?changelog=1","last_updated":"2018-05-15 09:34:11","homepage":"https:\\/\\/searchwp.com\\/downloads\\/searchwp\\/","package":"https:\\/\\/searchwp.com\\/edd-sl\\/package_download\\/MTUyNjk1NTY5NjpjMTkwMmIwNmE2ODZhMjY2YzdiNzY1OTE0NWI2M2RhYzo4OjM2NTc1YzVmMzdmMGUwZjg5MDEwNjc5OGNjNTEyZGQ0Omh0dHBALy9sYXd5ZXJzLWRpcmVjdG9yeS5jb206MA==","download_link":"https:\\/\\/searchwp.com\\/edd-sl\\/package_download\\/MTUyNjk1NTY5NjpjMTkwMmIwNmE2ODZhMjY2YzdiNzY1OTE0NWI2M2RhYzo4OjM2NTc1YzVmMzdmMGUwZjg5MDEwNjc5OGNjNTEyZGQ0Omh0dHBALy9sYXd5ZXJzLWRpcmVjdG9yeS5jb206MA==","sections":{"description":"","changelog":"<p>2.9.13<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Prevent redundant statistics logging on paginated results when using SWP_Query<\\/li>\\n<li><strong>[Fix]<\\/strong> Better handling of taxonomy terms with special characters<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes PHP Warning and PHP Notice in certain cases<\\/li>\\n<\\/ul>\\n<p>2.9.12<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Index better optimized when limiting to Media mime type<\\/li>\\n<li><strong>[Improvement]<\\/strong> AND logic is more restrictive when applicable<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of license key when provided via constant or filter<\\/li>\\n<li><strong>[Update]<\\/strong> Updates translation source<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes inaccurate indexer progress in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes handling of All Documents mime type Media limiter<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes PHP Warning<\\/li>\\n<\\/ul>\\n<p>2.9.11<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong>\\u00a0Additional index optimization when delta updates are applied via new filter searchwp_aggressive_delta_update<\\/li>\\n<li><strong>[Improvement]<\\/strong> Debug output cleanup<\\/li>\\n<li><strong>[Fix]<\\/strong> Implements omitted filter argument<\\/li>\\n<\\/ul>\\n<p>2.9.10<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Resolves an issue where AND logic wasn\'t strict enough in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Relocated searchwp_indexer_pre action trigger to restore expected behavior<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additinal refinements to delta update queue processing to prevent excessive server resource usage in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Adds edit icon to supplemental engine name to communicate it is editable<\\/li>\\n<li><strong>[Change]<\\/strong> License key is no longer displayed in license key field if populated via constant or hook<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_engine_use_taxonomy_name that controls displaying name or label of Taxonomies in enging settings<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_and_fields_{$post_type} allowing for AND field customization per post type<\\/li>\\n<\\/ul>\\n<p>2.9.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes an issue where post type Limit rules were too aggressive in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refined index delta update routine to reduce potentially unnecessary triggers<\\/li>\\n<\\/ul>\\n<p>2.9.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Resolves issue of inaccurate results count when parent attribution is in effect<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed PHP Warning introduced in 2.9.5<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better processing of engine Rules during indexing<\\/li>\\n<\\/ul>\\n<p>2.9.6.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed PHP Warning introduced in 2.9.5<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed link in admin notice<\\/li>\\n<\\/ul>\\n<p>2.9.6<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue causing newly regiestered taxonomies to be unavailable in settings UI<\\/li>\\n<li><strong>[Fix]<\\/strong> Messaging for index being out of date is now more accurate<\\/li>\\n<li><strong>[Fix]<\\/strong> Paged searches are no longer redundantly logged<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved default regex patterns by making them more strict<\\/li>\\n<li><strong>[Update]<\\/strong> Updated PDF parsing libraries<\\/li>\\n<\\/ul>\\n<p>2.9.5<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where \'Any Custom Field\' did not work as expected in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where taxonomies added since the last engine save may not be available<\\/li>\\n<li><strong>[Improvement]<\\/strong> Actual weight multiplier is displayed in tooltip<\\/li>\\n<\\/ul>\\n<p>2.9.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a CSS bug causing multiselect overlapping when configuring multiple post types<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue preventing searches of hierarchical post types in the admin<\\/li>\\n<\\/ul>\\n<p>2.9.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a searchwp_and_logic_only regression introduced in 2.9<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of initial default engine model<\\/li>\\n<\\/ul>\\n<p>2.9.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with some custom ORDER BY statements<\\/li>\\n<\\/ul>\\n<p>2.9.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a potential issue with sql_mode=only_full_group_by support (added in 2.9)<\\/li>\\n<li><strong>[Fix]<\\/strong> Avoid error when parsing PDFs without mbstring<\\/li>\\n<\\/ul>\\n<p>2.9<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Redesigned engine configuration interface!<\\/li>\\n<li><strong>[New]<\\/strong> Index is now further optimized as per engine settings<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_weight_max to customize a maximum weight<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_legacy_settings_ui to use legacy settings UI<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_apply_engines_rules to control whether engine rules are considered during indexing<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_additional_meta_exclusions to control whether default additional Custom Fields are excluded from indexing<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_supports_label_{post_type}_{support} to customize the label used for a post type native attribute<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additional debug statements output when enabled<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better formatting of HTML comment debug output<\\/li>\\n<li><strong>[Fix]<\\/strong> Less aggressive handling of pre_get_posts during searching<\\/li>\\n<li><strong>[Fix]<\\/strong> Fix an issue with sql_mode=only_full_group_by (default in MySQL 5.7)<\\/li>\\n<\\/ul>\\n<p>2.8.17<\\/p>\\n<ul>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with database table creation<\\/li>\\n<\\/ul>\\n<p>2.8.16<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where exclusionary weight was not properly applied to all Custom Fields<\\/li>\\n<li><strong>[Fix]<\\/strong> Resolved premature AND logic aggressiveness in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Revised database creation schema to better cooperate with more database environments<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better assumed sorting of results<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_stats_table_class to control CSS class applied to stats output<\\/li>\\n<\\/ul>\\n<p>2.8.15<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of regex pattern matches<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes an issue where Media-only default engines did not fully build index<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.8.14<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Additional checks to prevent overrun with other plugins<\\/li>\\n<\\/ul>\\n<p>2.8.13<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fix a regression introduced to SWP_Query in 2.8.11 that may have prevented pagination from working as expected<\\/li>\\n<\\/ul>\\n<p>2.8.12<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Additional main query checks to improve plugin compatibility<\\/li>\\n<\\/ul>\\n<p>2.8.11<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with main query check that prevented search results from appearing in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where default includes\\/exclusions would be applied outside the main query<\\/li>\\n<li><strong>[Change]<\\/strong> Updated common words (stopwords)<\\/li>\\n<li><strong>[Change]<\\/strong> Switch from page parameter to paged<br \\/>\\nso as to better match WP_Query<\\/li>\\n<\\/ul>\\n<p>2.8.10<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Improved main query checks<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved invisible character tokenizing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with AND logic limits given certain engine configurations<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed PHP Warnings<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed lack of output for two tooltips<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where usage of -1 weights to actively exclude matches overran enabled engine post type(s)<\\/li>\\n<\\/ul>\\n<p>2.8.9<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fix PHP Fatal Error with $wp_query<\\/li>\\n<li><strong>[Fix]<\\/strong> Fix regression introduced in 2.8.8 that prevented admin searches from working properly in some cases<\\/li>\\n<\\/ul>\\n<p>2.8.8<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter searchwp_pre_set_post allowing for filtration of each post object prior to indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Better interoperation with Widgets<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent double search logs in certain cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Properly cancel native search SQL when performing admin search (props Jim)<\\/li>\\n<li><strong>[Fix]<\\/strong> Repaired application of \'Remove all traces\' feature on Advanced settings page<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where incorrect total results counts were logged<\\/li>\\n<li><strong>[Improvement]<\\/strong> PHP Warning cleanup<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better accommodation for customization during import routines<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better accommodation of engine configuration and exclusions when performing AND logic pass<\\/li>\\n<li><strong>[Change]<\\/strong> Update to SWP_Query: post__in and post__not_in parameters are now explicit (previously behaved like hooks)<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.8.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed missing tooltip content<\\/li>\\n<li><strong>[Improvement]<\\/strong> Using searchwp_admin_bar now applies to search modification notices<\\/li>\\n<li><strong>[Improvement]<\\/strong> License key now included in System Information<\\/li>\\n<li><strong>[New]<\\/strong> Taxonomy term slugs are now indexed (use searchwp_indexer_taxonomy_term_index_slug to disable)<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_taxonomy_term allowing for filtration on taxonomy terms prior to indexing<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.8.6<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Fixed an issue with imposed engine config implementation for empty searches<\\/li>\\n<\\/ul>\\n<p>2.8.5<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Engine settings (e.g. exclusions\\/inclusions) are now imposed for empty searches<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_disable_impose_engine_config to disable imposed engine settings for empty searches<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have triggered unnecessary index update requests<\\/li>\\n<li><strong>[Improvement]<\\/strong> Style updates to better match WordPress\' implementation of system font<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of indexer requests<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better support when Admin\\/Dashboard searches are enabled<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better utilization of existing extracted document content when triggering an index rebuild<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better feedback when document parsing dependencies are not available<\\/li>\\n<li><strong>[Update]<\\/strong> Added more file type limiters to engine settings<\\/li>\\n<li><strong>[Update]<\\/strong> Updated translation sources<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.8.4<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_comment to filter comment arguments during indexing<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_pre_get_comments to filter comment arguments during indexing<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_comments_args to filter comment arguments during indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented searching in the WordPress admin (when enabled)<\\/li>\\n<\\/ul>\\n<p>2.8.3<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter searchwp_search_args to filter search arguments at runtime<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of object caching<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better messaging when rebuilding index<\\/li>\\n<li><strong>[Improvement]<\\/strong> Dequeue\\/deregister legacy versions of select2 that are imposed upon SearchWP\'s settings screen\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of regex matches<\\/li>\\n<\\/ul>\\n<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that sometimes prevented the indexer progress bar from displaying after rebuilding index<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have prevented manually edited document content from being fully re-indexed<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed PHP Warning during short circuit check<\\/li>\\n<li><strong>[Fix]<\\/strong> Disabling the minimum character count reduces length to 1 instead of 2<\\/li>\\n<\\/ul>\\n<p>2.8.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a mime type mismatch that prevented accurate Media limiting using All Documents file type<\\/li>\\n<li><strong>[Fix]<\\/strong> Admin Bar and Advanced tab indexer pausing now use the same setting<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue when checking for utf8mb4 support<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved regex pattern for hyphen-separated matches<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved aggressiveness of search algorithm where necessary to prevent unexpected filtration during searches<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.8.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a potential PHP error\\u00a0with write\\u00a0context<\\/li>\\n<\\/ul>\\n<p>2.8<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Document parsing support added for Office documents (.docx, .xlsx, .pptx)<\\/li>\\n<li><strong>[New]<\\/strong> Document parsing support added for OpenOffice\\/LibreOffice documents (.odt, .ods, .odp)<\\/li>\\n<li><strong>[New]<\\/strong> Document parsing support added for Rich Text documents<\\/li>\\n<li><strong>[New]<\\/strong> Settings screen update to better accommodate common actions<\\/li>\\n<li><strong>[New]<\\/strong> Improve settings screen performance by requesting taxonomy terms via AJAX<\\/li>\\n<li><strong>[Fix]<\\/strong> When searchwp_in_admin is enabled searching in Grid view for Media now works as expected<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of large content (including parsed documents)<\\/li>\\n<li><strong>[Update]<\\/strong> Updated translation source<\\/li>\\n<li><strong>[Update]<\\/strong> Updated select2<\\/li>\\n<\\/ul>\\n<p>2.7.2<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of native search query<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a case where searchwp_show_conflict_notices was not respected<\\/li>\\n<li><strong>[Fix]<\\/strong> Fix PHP Warning (Invalid argument supplied for foreach() in \\/wp-includes\\/query.php on line 4890)<\\/li>\\n<\\/ul>\\n<p>2.7.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Cleaned up PHP Warning in SWP_Query<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed positioning of Extensions dropdown, other minor style updates<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with SWP_Query not resetting set hooks causing inaccurate results<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Alternate Indexer may report posts left to index when no post types are enabled<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where AND logic pass was too restrictive in some circumstances<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue when limiting Media results to Images only throwing a PHP Warning<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that caused some WP Admin notices to not display<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refactored some stats logic into SearchWP_Stats<\\/li>\\n<li><strong>[Change]<\\/strong> Changed PHPCS ruleset which resulted in some additional hardening\\/formatting<\\/li>\\n<li><strong>[Update]<\\/strong> Updated translation source<\\/li>\\n<\\/ul>\\n<p>2.7<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter searchwp_weight_mods allowing for direct manipulation of computed weights within the search algorithm<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_license_key to programmatically define SearchWP license key<\\/li>\\n<li><strong>[New]<\\/strong> SearchWP license key can now be defined with SEARCHWP_LICENSE_KEY constant<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_initial_engine_settings to programmatically define default engine configurations on activation<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_keyword_stem_locale to enable keyword stemming in the current locale<\\/li>\\n<li><strong>[New]<\\/strong> Support for \'fields\' =&gt; \'ids\' argument in SWP_Query<\\/li>\\n<li><strong>[New]<\\/strong> Support for post_type argument in SWP_Query<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_purge_pdf_content to remove parsed PDF content during an index purge<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_skip_vendor_libs to prevent loading of any vendor libraries<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_taxonomy_terms allowing for filtration of taxonomy terms pre-index<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where searchwp_exclusive_regex_matches could have been too greedy<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where a filtered post type could not be enabled in engine settings<\\/li>\\n<li><strong>[Fix]<\\/strong> Use multibyte string manipulation when possible<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the indexer progress bar may not display in WordPress 4.4+<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of matches when taking advantage of searchwp_exclusive_regex_matches<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved handling of deeply serialized meta data<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced indexer query overhead<\\/li>\\n<li><strong>[Improvement]<\\/strong> Keyword stemming is only available if the current locale supports it (if you are using a custom stemmer you will need to update)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Less aggressive checks against failed PDF parsing that generated false positive results<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of unicode whitespace during PDF parsing<\\/li>\\n<li><strong>[Change]<\\/strong> Debug log is now written to searchwp-debug.txt in the base uploads directory<\\/li>\\n<li><strong>[Change]<\\/strong> Parsed PDF content is not removed when the index is purged<\\/li>\\n<li><strong>[Update]<\\/strong> Updated PDF parsing library<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.6.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where AND logic may not be enforced in some circumstances<\\/li>\\n<li><strong>[Fix]<\\/strong> PDF metadata is now properly delted when Nuke on Delete is enabled<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue in the tokenizer that may have prevented tokens from being broken apart when HTML had no whitespace<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a potential issue with PDF content indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with the indexer not fully completing when only Media was enabled<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup when no results were found after tokenizing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved performance when Media is given parent attribution<\\/li>\\n<li><strong>[Improvement]<\\/strong> SearchWP will now internally short circut when an empty search is performed for the main query<\\/li>\\n<li><strong>[Improvement]<\\/strong> Filtered post types are now given priority on the settings screen<\\/li>\\n<li><strong>[New]<\\/strong> Added Dutch translation<\\/li>\\n<\\/ul>\\n<p>2.6<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New class: SWP_Query which aims to mirror WP_Query in many ways, but with a SearchWP twist<\\/li>\\n<li><strong>[New]<\\/strong> Settings UI has been revamped<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_swp_query_args to filter SWP_Query args at runtime<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_init fires when the settings utility has been initialized<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_load fires when SearchWP has loaded<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_before_header fires before the settings header is output<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_nav_tab to implement settings tabs<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_after_header fires after the settings header is output<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_before\\\\my_view where my_view is the name of the settings view for that tab<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_view\\\\my_view where my_view is the name of the settings view for that tab<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_after\\\\my_view where my_view is the name of the settings view for that tab<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_footer fires after each settings view has been displayed<\\/li>\\n<li><strong>[New]<\\/strong> Results weights are included in HTML comment block when debugging is enabled<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_debug_append_weights_to_titles whether weights should be included in HTML comment block debug information<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_show_filter_conflict_notices whether filter conflicts should be shown when debugging is enabled (defaults to false)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better license activation UX<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduction of index overhead by way of pairing to engine settings<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refined list of default common (stop) words<\\/li>\\n<li><strong>[Fix]<\\/strong> Clear out delta ceiling update check when waking up the indexer<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have caused the indexer to loop when a post has no content to index after tokenizing\\/processing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the settings screen spinner would not display<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented loading of some assets if the plugin directory was renamed<\\/li>\\n<li><strong>[Update]<\\/strong> Updated translation files<\\/li>\\n<\\/ul>\\n<p>2.5.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with utf8mb4 (e.g. emoji) support (NOTE: only <em>new<\\/em> installations will support utf8mb4) \\u2014\\u00a0more information at <a href=\\"https:\\/\\/searchwp.com\\/releases\\/\\">https:\\/\\/searchwp.com\\/releases\\/<\\/a><\\/li>\\n<li><strong>[Change]<\\/strong> All camelCase function and method names have been deprecated (not removed (yet)) in favor of underscores<\\/li>\\n<\\/ul>\\n<p>2.5.6<\\/p>\\n<ul>\\n<li><strong>[Improved]<\\/strong> Better settings standardization<\\/li>\\n<\\/ul>\\n<p>2.5.5<\\/p>\\n<ul>\\n<li><strong>[Security Fix]<\\/strong>\\u00a0XSS prevention for authenticated users in the admin with add_query_arg<\\/li>\\n<li><strong>[Improved]<\\/strong> Security improvements: additional\\/redundant escaping\\/preparing\\/casting so as to harden the code base and improve readability<\\/li>\\n<li><strong>[Improved]<\\/strong> More accurate Today stats<\\/li>\\n<li><strong>[Improved]<\\/strong> Better translation support<\\/li>\\n<li><strong>[Improved]<\\/strong> Better exception handling with PDF parsing<\\/li>\\n<li><strong>[Fix]<\\/strong>\\u00a0Better handling of misconfiguration when attributing an excluded post<\\/li>\\n<li><strong>[New]<\\/strong> Added French translation<\\/li>\\n<\\/ul>\\n<p>2.5.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with regex whitelist term duplication in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue when limiting AND fields to one field<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed inconsistent default parameter for searchwp_indexed_post_types filter<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup with filter conflict detection when debugging is enabled<\\/li>\\n<\\/ul>\\n<p>2.5.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong>\\u00a0Fixed an issue that may have prevented taxonomy searches from returning results<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a regression introduced in 2.5 that aimed to optimize the main search query by omitting taxonomies with a weight of zero<\\/li>\\n<li><strong>[Fix]<\\/strong>\\u00a0Fixed an issue that may have prevented supplemental search results from appearing<\\/li>\\n<\\/ul>\\n<p>2.5<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Alternate, browser based indexer for cases where background indexing doesn\'t work<\\/li>\\n<li><strong>[New]<\\/strong> Front end Admin Bar entry that calls out any search modifications put in place (e.g. minimum word length, common words, maximum search length)<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_alternate_indexer to trigger the new browser-based indexer<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_log_search to allow prevention of search logging on a per-case basis<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_init to allow for dynamic initialization of SearchWP<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_max_delta_attempts to catch edge cases causing repeated delta updates<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_indexer_taxonomies allows developers to customize which taxonomies are indexed<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_indexer_unindexed_args to customize WP_Query arguments used to locate unindexed posts<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_indexer_unindexed_media_args to customize WP_Query arguments used to locate unindexed Media<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_failed_index_notice to customize who can see the notice about unindexed posts<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_remove_pre_get_posts to define whether all hooks to pre_get_posts are removed during indexing (a very common conflict)<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_indexer_pre_process_content allows developers to customize the content being indexed before it is processed and indexed<\\/li>\\n<li><strong>[New]<\\/strong> Set default array of excluded IDs to the main search query\'s post__not_in<\\/li>\\n<li><strong>[New]<\\/strong> Set default array of included IDs to the main search query\'s post__in<\\/li>\\n<li><strong>[New]<\\/strong> PDF metadata is now indexed<\\/li>\\n<li><strong>[Change]<\\/strong> Use get_query_var() instead of directly grabbing $wp_query attributes<\\/li>\\n<li><strong>[Change]<\\/strong> Add index.php to default loopback endpoint to avoid false positives with WAFs<\\/li>\\n<li><strong>[Change]<\\/strong> Use debug.txt instead of debug.log<\\/li>\\n<li><strong>[Change]<\\/strong> PDF text extraction abstracted to it\'s own method SWP()-&gt;extract_pdf_text( $post_id )<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented limiting Media results for an engine to more than one MIME type group<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an off-by-one issue that prevented single terms from being indexed when using the searchwp_process_term_limit filter<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that interfered with pagination in the WP admin when searchwp_in_admin was set to true<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup in Dashboard Widget<\\/li>\\n<li><strong>[Fix]<\\/strong> Only output Dashboard Widget assets on the Dashboard<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an overflow issue in Dashboard Widget when collapsed on load<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Dashboard Widget stats transients were not cleared when stats were reset<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better minimum height for statistics graph<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better width restriction on settings screen for post type tabs<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better detection of database environment change that may interfere with indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Weights of less than 0 are now called out to ensure intention of excluding results<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better checks against searchwp_indexed_post_types when displaying settings screen<\\/li>\\n<li><strong>[Improvement]<\\/strong> Main search algorithm optimizations<\\/li>\\n<li><strong>[Improvement]<\\/strong> Indexer now checks for excluded posts before reindexing them after a purge<\\/li>\\n<li><strong>[Improvement]<\\/strong> Optimizations to search algorithm when weights of zero are used<\\/li>\\n<li><strong>[Improvement]<\\/strong> UI improvements on the settings screen<\\/li>\\n<li><strong>[Update]<\\/strong> Updated translation files<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.4.11<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented post attribution when using explicit IDs<\\/li>\\n<li><strong>[Fix]<\\/strong> Set proper flags when all search terms have been invalidated<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup with Dashboard Widget<\\/li>\\n<li><strong>[Improvement]<\\/strong> Further optimization of results pool reduction when exclusions are in place<\\/li>\\n<li><strong>[Update]<\\/strong> Updated translation source files<\\/li>\\n<li><strong>[Change]<\\/strong> searchwp_term_in filter now has a 3rd parameter with the original (e.g. unstemmed when stemming is enabled) term<\\/li>\\n<\\/ul>\\n<p>2.4.10<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> PHP 5.2 compatibility with PDF parser fallback<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where some search strings were not properly ignored<\\/li>\\n<li><strong>[Fix]<\\/strong> Proper clearing of meta boxes on stats page at certain resolutions<\\/li>\\n<\\/ul>\\n<p>2.4.9<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where limiting Media results to All Documents did not apply the expected limit<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where AND logic refinement may cause zero results to display depending on Title weight<\\/li>\\n<li><strong>[Update]<\\/strong> Updated PHP PDF parser (requires PHP 5.3+, will still fall back to less reliable legacy parser if PHP 5.2)<\\/li>\\n<li><strong>[Change]<\\/strong> Return WP_Error when an invalid search engine name is used<\\/li>\\n<\\/ul>\\n<p>2.4.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where proper weights may not have been properly retained throughout the entire search algorithm, resulting in zero results<\\/li>\\n<li><strong>[Fix]<\\/strong> Default search results now take into account an offset (if one was set)<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_query_offset allowing for customization of the offset of the default search engine<\\/li>\\n<\\/ul>\\n<p>2.4.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup: removed deprecated usage of mysql_get_server_info()<\\/li>\\n<\\/ul>\\n<p>2.4.6<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented parsed PDF content from being indexed on the first pass<\\/li>\\n<li><strong>[New]<\\/strong> Version numbers (SearchWP, WordPress, PHP, MySQL) are now passed along with support requests<\\/li>\\n<\\/ul>\\n<p>2.4.5.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup for in_array() in searchwp.php on line 1588<\\/li>\\n<\\/ul>\\n<p>2.4.5<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Direct integration of support ticket creation within the WordPress admin<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_lightweight_settings allowing for a speedier but degraded settings screen loading (e.g. not loading taxonomy terms)<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_dashboard_widget_cap for more control over Dashboard Widget visibility (defaults to settings cap (which defaults to manage_options))<\\/li>\\n<li><strong>[New]<\\/strong> Settings export\\/import facilitated by copying and pasting JSON of engine configuration(s)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Due to numerous issues with object caching, index validation hashes are stored as options instead of transients<\\/li>\\n<li><strong>[Improvement]<\\/strong> Updated licensing system framework<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of initial UI load on settings screen by obstructing UI until all bindings are properly in place<\\/li>\\n<li><strong>[Change]<\\/strong> Switched to <a href=\\"http:\\/\\/gionkunz.github.io\\/chartist-js\\/\\">Chartist<\\/a> for statistics graphs<\\/li>\\n<li><strong>[Change]<\\/strong> Reinstated automatic theme conflict notices (filter conflicts continue to appear only when debugging is enabled)<\\/li>\\n<li><strong>[Fix]<\\/strong> Search statistics for Today are more accurate<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented Shortcodes from being processed when using searchwp_do_shortcode<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue triggered by a Custom Post Type named label preventing proper SearchWP settings storage<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented Dashboard Widget transient storage if supplemental search names exceeded 17 characters<\\/li>\\n<\\/ul>\\n<p>2.4.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where certain search terms were being double-stemmed<\\/li>\\n<\\/ul>\\n<p>2.4.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where PDFs attributed to their post parent weren\'t showing up in search results<\\/li>\\n<\\/ul>\\n<p>2.4.2<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Resolved query latency introduced in 2.4.1 concerning attribution<\\/li>\\n<\\/ul>\\n<p>2.4.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented parent attribution from working properly in certain cases<\\/li>\\n<\\/ul>\\n<p>2.4<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> SearchWP will now detect whether you\'re using HTTP Basic Authentication<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_basic_auth_creds allowing developers to define HTTP Basic Authentication credentials<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_query_select_inject allowing developers the ability to inject their own statements into the main search query, allowing for extensive customization of results display beyond keyword weights<\\/li>\\n<li><strong>[New]<\\/strong> Search Statistics Dashboard Widget<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_dashboard_widget allowing developers to disable the Search Statistics Dashboard Widget<\\/li>\\n<li><strong>[New]<\\/strong> System Information panel (on the Advanced settings screen) to ease support<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of searchwp_indexer_enabled when used at the same time as searchwp_indexer_paused<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of accented characters<\\/li>\\n<li><strong>[Fix]<\\/strong> Force transient deletion<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where keyword stemming may have not been appropriately applied<\\/li>\\n<li><strong>[Change]<\\/strong> Conflict notices are now only displayed when debugging is enabled<\\/li>\\n<\\/ul>\\n<p>2.3.3<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Admin Bar entry now elaborates on why a post is not indexed (e.g. draft status if not filtered)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Admin Bar entry now more accurately calls out when a post is in the process of being indexed<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have prevented strings of only digits from being properly indexed<\\/li>\\n<\\/ul>\\n<p>2.3.2<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better capture of SQL_BIG_SELECTS errors by including a link to the fix in the Admin Bar<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of character encoding when parsing PDFs<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where posts excluded from the index were not properly listed on the exclusions page<\\/li>\\n<\\/ul>\\n<p>2.3.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a check for DOMDocument and cleaned up PHP warning about empty DOMDocument content<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where saved Custom Field keys were not retrieved properly on the settings screen<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where exclusion fields weren\'t treated with select2 when creating supplemental search engines<\\/li>\\n<li><strong>[Change]<\\/strong> Loading the settings screen UI partial via AJAX is now opt-in\\n<ul>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_lazy_settings allowing developers to trigger a cachebusting version of the settings screen<\\/li>\\n<\\/ul>\\n<\\/li>\\n<\\/ul>\\n<p>2.3<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Added UI feedback when the indexer has been automatically throttled due to excessive server load<\\/li>\\n<li><strong>[New]<\\/strong> Deprecated $searchwp global in favor of new function SWP()<\\/li>\\n<li><strong>[New]<\\/strong> You can now retrieve the specific weights that set the order for search results per-post and per-post-type-per-post (SWP()-&gt;results_weights)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_endpoint allowing developers to customize the endpoint used by the indexer for each pass (uses only the slug, the site_url() is automatically prepended)<\\/li>\\n<li><strong>[New]<\\/strong> SearchWP will now index what it considers valuable HTML element attribute content (e.g. alt text)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_indexer_tag_attributes allowing developers to customize which elements and attributes are considered valuable<\\/li>\\n<li><strong>[Improvement]<\\/strong> Significant performance increase of main search algorithm<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better UTF-8 support when tokenizing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Indexer now ensures it\'s not being throttled before jumpstarting<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reset AUTO_INCREMENT when the index is purged<\\/li>\\n<li><strong>[Improvement]<\\/strong> Deprecated and removed explicit indexed meta flag in favor of utilizing the already present last_index meta flag<\\/li>\\n<li><strong>[Fix]<\\/strong> Removed redundant error_log usage with debugging enabled<\\/li>\\n<li><strong>[Fix]<\\/strong> Properly log searches called directly from search class<\\/li>\\n<li><strong>[Fix]<\\/strong> Empty searches are no longer logged when performed via the API<\\/li>\\n<li><strong>[Change]<\\/strong> Removed Remote Debugging as it no longer applies to support<\\/li>\\n<li><strong>[Change]<\\/strong> Settings screen is now loaded via AJAX so as to get around excessive page caching in the WP admin by certain hosts<\\/li>\\n<li><strong>[Change]<\\/strong> MyISAM is no longer explicitly used when creating custom database tables (uses your MySQL default instead)<\\/li>\\n<li><strong>[Change]<\\/strong> Refined default common words<\\/li>\\n<\\/ul>\\n<p>2.2.3<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Another revision to the indexer stall check<\\/li>\\n<li><strong>[Improvement]<\\/strong> Updated translation source<\\/li>\\n<li><strong>[New]<\\/strong> Added an admin notice if your log file exceeds 2MB<\\/li>\\n<\\/ul>\\n<p>2.2.2<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better indexer stall check<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of search logs (moved from main class method to search class) to better accommodate 3rd party integrations<\\/li>\\n<\\/ul>\\n<p>2.2.1<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of indexer stall check<\\/li>\\n<li><strong>[Improvement]<\\/strong> Switched Admin Bar entry from \'Currently Being Indexed\' to \'In index queue\' for accuracy\'s sake<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of delta updates prior to the initial index being built<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better implementation of searchwp_exclusive_regex_matches usage, matches are now extracted earlier resulting in more concise results<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented search queries from being logged when instantiating the search class directly<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where manually edited PDF content would be overwritten by a subsequent delta index update after saving<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have prevented the indexer from fully waking up when waking up the indexer<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a false positive when checking for WPML Integration<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with Xpdf Integration not saving the extracted text<\\/li>\\n<\\/ul>\\n<p>2.2<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New class: SearchWP_Stats which will eventually house a number of utility methods for better statistics as development continues<\\/li>\\n<li><strong>[New]<\\/strong> SearchWP will now detect if you\'re running a plugin that has an integration Extension available and tell you about it<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_omit_meta_key allows developers to omit specific meta keys from being indexed during indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Hardened the indexer communication process, reducing server resource consumption during indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of regex whitelist matches that result with multi-word tokens (e.g. spaces within) NOTE: having multi-word matches is not recommended<\\/li>\\n<li><strong>[Improvement]<\\/strong> Added $engine parameter to searchwp_query_orderby filter<\\/li>\\n<li><strong>[Improvement]<\\/strong> Simplified the check for a stalled indexer<\\/li>\\n<li><strong>[Improvement]<\\/strong> Multi-term regex whitelist matches will no longer be tokenized but indexed as a whole for better phrase-matching<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Heartbeat index time updates were not prefixed with \\"Last indexed\\"<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the debugger would not properly instantiate thereby preventing additions to the log file<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Heartbeat API-powered timestamp of last index was missing \\"Last Indexed\\" phrasing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where in some circumstances content blocks parsed from PDFs would not be properly separated, resulted in the last word of one section being lumped together with the first word of the next section<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent over-preparation of terms when performing AND logic refinement<\\/li>\\n<li><strong>[Fix]<\\/strong> Check for indexer being disabled when issuing delta updates<\\/li>\\n<\\/ul>\\n<p>2.1.3<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better encoding and font support for PDF content extraction<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced memory footprint when not indexing PDFs<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where searchwp_settings_cap was not properly applied<\\/li>\\n<li><strong>[Fix]<\\/strong> Reduced aggressiveness when tokenizing PDF content<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed thrown exception when parsing specific PDF encodings<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a PHP 5.2 issue<\\/li>\\n<li><strong>[Fix]<\\/strong> Corrected an include path for ElementXRef.php<\\/li>\\n<\\/ul>\\n<p>2.1<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Significant query performance improvement in AND logic pass<\\/li>\\n<li><strong>[Improvement]<\\/strong> Much improved PDF content extraction when using only PHP as opposed to Xpdf Integration (requires PHP5.3+ else SearchWP will fall back to previous method)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_settings_cap allows you to customize the capability required to manage SearchWP\'s settings in the WordPress admin<\\/li>\\n<li><strong>[New]<\\/strong> You can now bulk-reintroduce posts that failed indexing<\\/li>\\n<\\/ul>\\n<p>2.0.4<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New regex whitelist pattern to support ampersand-joined terms (e.g. M&amp;M)<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where toggling whether the indexer was enabled\\/disabled would sometimes conflict if not done on the SearchWP settings screen<\\/li>\\n<li><strong>[Improvement]<\\/strong> Fixed an issue where umlaut\'s were incorrectly removed from PDF content when extracted using internal (PHP-based) method<\\/li>\\n<li><strong>[Improvement]<\\/strong> Theme conflict detection now takes into account single line comments (does not cover all commented use cases)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved term processing when using built in sanitization prior to searches<\\/li>\\n<\\/ul>\\n<p>2.0.3<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_get_custom_fields allowing developers to pre-fetch (and set) post metadata just before indexing takes place (props Stefan Hans Schonert)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_term_in allowing you to modify each term (per term) used in the main search algorithm<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of filtered terms, allowing extensions more control over the actual search query<\\/li>\\n<li><strong>[Improvement]<\\/strong> searchwp_indexer_loopback_args is now applied to every HTTP call SearchWP makes<\\/li>\\n<\\/ul>\\n<p>2.0.2<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_statistics_cap allows you to filter which capability is required to view and interact with stats<\\/li>\\n<li><strong>[Improvement]<\\/strong> Ignored queries in search statistics are now stored per user, not globally<\\/li>\\n<\\/ul>\\n<p>2.0.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue introduced in 2.0 that prevented the uninstallation routine from properly executing when not using multisite<\\/li>\\n<li><strong>[Improvement]<\\/strong> Resolved an issue in certain hosting environments that may have prevented the indexer from running<\\/li>\\n<\\/ul>\\n<p>2.0<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Shortcode processing: SearchWP can now process your Shortcodes in a number of ways<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_do_shortcode allows you to conditionally tell SearchWP to process all Shortcodes<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_set_post allows you to modify each post object prior to indexing, allowing for conditional processing of Shortcodes and more<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_nuke_on_delete to trigger Nuke on Delete (<em>overrides setting!<\\/em>)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_exclusive_regex_matches to force the indexer to prevent indexing exploded regex matches<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_omit_meta_key_{custom_field_key} allowing for per-key conditional exclusion of post meta when indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refined regex whitelist pattern for matching hyphen-separated-strings<\\/li>\\n<li><strong>[Improvement]<\\/strong> The indexer no longer strips regex matches but instead retains them to better facilitate partial matches<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better language for action\\/conflict notices<\\/li>\\n<li><strong>[Improvement]<\\/strong> You can now restore dismissed action\\/conflict notices in case you want to view them again<\\/li>\\n<li><strong>[Improvement]<\\/strong> Slight update to the settings UI (better active tab contrast, lessened border radii)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better exposure of Statistics feature<\\/li>\\n<li><strong>[Improvement]<\\/strong> Uninstallation routine now better respects multisite environment<\\/li>\\n<li><strong>[Improvement]<\\/strong> You can now exclude by terms that have not been used yet<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better default exclusion of internal metadata when indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where regex whitelist matches were not extracted from supplemental search queries during sanitization<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that might result in duplication of terms that are integers in the index<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a potential issue (during updates) where Supplemental search engine labels would inadvertently have their first letter converted to an \'A\'<\\/li>\\n<li><strong>[Fix]<\\/strong> Redundant preparation of search terms when checking for exclusions by weight of -1<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup<\\/li>\\n<\\/ul>\\n<p>1.9.11<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Added a regex whitelist pattern for hyphen-separated strings often used for serial numbers<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced the overhead of term extraction when processing the regex whitelist which might cause long posts with many regex matches to stall the indexer<\\/li>\\n<\\/ul>\\n<p>1.9.10<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a regression in version 1.9.8 that prevented the installation of new plugins from .org<\\/li>\\n<\\/ul>\\n<p>1.9.9<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where extended term-chunking of long posts may not have completed properly<\\/li>\\n<\\/ul>\\n<p>1.9.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the changelog would not be visible when clicking \'view version details\' links<\\/li>\\n<li><strong>[Change]<\\/strong> Automatic load monitoring is again enabled by default<\\/li>\\n<li><strong>[Improvement]<\\/strong> The notice that outputs an indication of posts that failed to index now respects purposefully excluded post IDs via searchwp_prevent_indexing filter<\\/li>\\n<\\/ul>\\n<p>1.9.7<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_index_comments allows you to prevent comments from being indexed<\\/li>\\n<li><strong>[Improvement]<\\/strong> Prevented potential edge case where the indexer may stall after completing a delta update<\\/li>\\n<li><strong>[Improvement]<\\/strong> More aggressive implementation of term regex whitelist (matches are now indexed fully in tact and not broken apart)<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where problematic posts that failed to index were not properly called out in the WordPress admin<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where \'Any\' Custom Field may not have applied correctly<\\/li>\\n<\\/ul>\\n<p>1.9.5<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where searchwp_in_admin may not properly hijack search results in the WordPress admin as desired<\\/li>\\n<li><strong>[Improvement]<\\/strong> Only return results from the post type being viewed when searchwp_in_admin is enabled and performing a search<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additional optimization and segmentation of settings where appropriate to prevent potential collision<\\/li>\\n<li><strong>[Improvement]<\\/strong> Use the Heartbeat API to dynamically update the Last Indexed time when on post edit screens<\\/li>\\n<\\/ul>\\n<p>1.9.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a CSS rendering issue in Firefox on the Search Stats page<\\/li>\\n<li><strong>[Improvement]<\\/strong> Hardened settings getting and setting mechanism<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_show_conflict_notices allows you to force-hide any conflict warnings generated by SearchWP<\\/li>\\n<\\/ul>\\n<p>1.9.2<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Added a number of actions to allow developers to react to various phases of indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where setting -1 posts per page was incorrectly utilized when performing searches<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented SearchWPSearch instantiation when AJAX calls were made<\\/li>\\n<li><strong>[Improvement]<\\/strong> Modified default term whitelist rules to be more targeted<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced the number of notifications displayed upon activation<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced the number of queries necessary to store\\/retrieve various settings<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better data storage so as to work alongside various object caching plugins without stalling the indexer<\\/li>\\n<\\/ul>\\n<p>1.9<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> You can now ignore queries from Search Stats (to help avoid spam getting in the way)<\\/li>\\n<li><strong>[New]<\\/strong> Term Whitelisting: you can now define regex patterns and in doing so better retain specially formatted terms (e.g. dates, phone numbers, function names) in the index that otherwise would have been stripped of punctuation<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_query_orderby allows open-ended customization of the ORDER BY clause of the main search query<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_force_run allows developers the ability to force SearchWP to run no matter what<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_leinant_accents allowing for \'lazy\' quotes (e.g. searches without quotes will find terms with quotes)<\\/li>\\n<li><strong>[Improvement]<\\/strong> PHP Error cleanup<\\/li>\\n<li><strong>[Improvement]<\\/strong> Revisited index table indices, they\'re now better optimized which should result in noticeable performance improvements<\\/li>\\n<li><strong>[Improvement]<\\/strong> Load monitoring has been removed as it proved to be holding back the indexer resulting in delayed index times<\\/li>\\n<li><strong>[Improvement]<\\/strong> Attachment indexing has been disabled by default to save the (significant) overhead, but it will enable itself if any of your search engine settings incorporate Media<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refined the number of posts indexed per indexer passed, as always this can be filtered<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced the information overload present in the debug log, allowing for easier scanning for issues<\\/li>\\n<li><strong>[Improvement]<\\/strong> Offloaded AJAX handlers to minimize footprint and impact on the indexer<\\/li>\\n<li><strong>[Improvement]<\\/strong> Fixed overflow issues on the Search Stats page<\\/li>\\n<li><strong>[Improvement]<\\/strong> Informational notice linking directly to more information on Filters having everything to do with indexer configuration<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better detection of parallel indexer processes running that could have resulted in duplicate indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Indexer pause\\/unpause has been re-named enable\\/disable to reduce confusion<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where update notifications wouldn\'t show up in the Network Administration on Multisite<\\/li>\\n<\\/ul>\\n<p>1.8.4<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of serialized objects which resulted in <em>_PHP<\\/em>Incomplete_Class errors<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better enforcement of maximum term length when indexing as defined by the database schema<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of Deadlock cases when indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved default common\\/stop words<\\/li>\\n<\\/ul>\\n<p>1.8.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Cleanup of PHP Warnings<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_outside_main_query allowing for specific overrides when performing native searches<\\/li>\\n<li><strong>[Improvement]<\\/strong> Updated translation files (accurate translations will be rewarded, please contact info@searchwp.com)<\\/li>\\n<\\/ul>\\n<p>1.8.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where update notifications would not persist properly<\\/li>\\n<\\/ul>\\n<p>1.8.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where, in certain cases, weight attribution (or a lack thereof) would cause searches to fail<\\/li>\\n<\\/ul>\\n<p>1.8<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> You can now include a LIKE modifier (%) in Custom Field keys (essentially supporting ACF Repeater field (and similar plugins) data storage)<\\/li>\\n<li><strong>[New]<\\/strong> SearchWP will now attempt to detect potential conflicts and add notices in the WordPress admin when it finds potential problems<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where custom keyword stemmers would only be used during indexing, not searching<\\/li>\\n<li><strong>[Improvement]<\\/strong> The Custom Fields dropdown on the settings page is no longer limited to the 25 most-used meta keys<\\/li>\\n<li><strong>[Improvement]<\\/strong> The Custom Fields dropdown now uses select2 to make it easier to quickly select your desired meta key<\\/li>\\n<li><strong>[Improvement]<\\/strong> Various improvements to the main settings screen styles<\\/li>\\n<li><strong>[Improvement]<\\/strong> Fixed an issue where Custom Field meta keys would be over-sanitized when saved in the SearchWP options<\\/li>\\n<li><strong>[Improvement]<\\/strong> Update checks are performed less aggressively, reducing some cases of increased latency in the WordPress admin<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better singleton instantiation, fixing an issue with localization and certain hook utilization<\\/li>\\n<li><strong>[Improvement]<\\/strong> Scheduled events are now properly removed upon plugin deactivation<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduction in query overhead when multiple Custom Field meta keys have the same weight<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduction in query overhead when multiple taxonomies have the same weight<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refactored the main query algorithm so as to improve maintainability and stability over time<\\/li>\\n<li><strong>[Improvement]<\\/strong> Formatting improvements, code quality improvements<\\/li>\\n<li><strong>[Improvement]<\\/strong> Updated translation files (accurate translations will be rewarded, please contact info@searchwp.com)<\\/li>\\n<\\/ul>\\n<p>1.7.2<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New Extension: Term Highlight - highlight search terms when outputting results!<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_found_post_objects allowing for the customization of Post objects returned by searches<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where overriding SearchWP File Content would be overwritten when the post got reindexed<\\/li>\\n<li><strong>[Fix]<\\/strong> Hotfix for a potential update issue, if you do not see an update notification in your dashboard, please download from your Account<\\/li>\\n<\\/ul>\\n<p>1.7<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> There is a new Advanced option called Nuke on Delete that adjusts the uninstallation routine to only remove data if you opt in<\\/li>\\n<li><strong>[Improvement]<\\/strong> AND logic queries now force their own index<\\/li>\\n<li><strong>[Improvement]<\\/strong> Removed unused constant<\\/li>\\n<li><strong>[Improvement]<\\/strong> Offloaded update checks to only occur in the admin and therefore reduce overhead on the front end<\\/li>\\n<li><strong>[Improvement]<\\/strong> Update checks are now performed once a day so as to reduce page load latency when working in the WordPress admin<\\/li>\\n<li><strong>[Improvement]<\\/strong> Changed the way license checks were performed to avoid potential unwanted caching issues<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed invalid textdomain usage for l18n<\\/li>\\n<\\/ul>\\n<p>1.6.10<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where keyword weights between 0 and 1 were converted to integers<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_post_statuses allowing for the customization of which post statuses are considered when indexing and searching<\\/li>\\n<\\/ul>\\n<p>1.6.9<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have generated a SQL error after late term sanitization when performing searches<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that caused taxonomies to be omitted in searches by default upon activation<\\/li>\\n<\\/ul>\\n<p>1.6.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a regression introduced in 1.6.7 that prevented the \'last indexed\' statistic from being properly maintained<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_extra_metadata allowing you to force additional content into the index per post<\\/li>\\n<\\/ul>\\n<p>1.6.7<\\/p>\\n<ul>\\n<li><strong>[Change]<\\/strong> Background indexing process has been updated to better accommodate maintenance mode plugins<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have prevented result exclusion given weight of -1 in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced the overhead of the logs table (note: search stats will be reset to accommodate this)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Miscellaneous code reorganization and optimization<\\/li>\\n<\\/ul>\\n<p>1.6.6<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New Advanced option to reset Search Stats<\\/li>\\n<\\/ul>\\n<p>1.6.5<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better appropriate suppression of WP_Query filters in internal calls<\\/li>\\n<li><strong>[Improvement]<\\/strong> Admin Bar entry better labels whether the indexer is paused<\\/li>\\n<\\/ul>\\n<p>1.6.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Admin bar entries now only show up when browsing the WordPress admin and the current user can update_options<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where overwriting the stored PDF content may not have properly taken place<\\/li>\\n<li><strong>[Improvement]<\\/strong> Initial AND logic pass now assumes keyword stem to create a better initial results pool<\\/li>\\n<li><strong>[Improvement]<\\/strong> When debugging is enabled, an HTML comment block is output at the bottom of pages to indicate what took place during that pageload<\\/li>\\n<li><strong>[Improvement]<\\/strong> Asset URLs in the admin now better respect alternative placement (props Jason C.)<\\/li>\\n<\\/ul>\\n<p>1.6.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where AND logic was wrongly applied to single term searches if you set searchwp_and_logic_only to be true<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where searchwp_posts_per_page was not properly applied to WordPress native searches<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_big_selects for cases where SearchWP breaches your MySQL-defined max_join_size<\\/li>\\n<\\/ul>\\n<p>1.6.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a PHP 5.2 compatibility error (T<em>PAAMAYIM<\\/em>NEKUDOTAYIM)<\\/li>\\n<\\/ul>\\n<p>1.6.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an error on plugin deletion via WP admin<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where (if you opt to disable automatic delta updates) the queue could be overwritten in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where (in certain circumstances) searches for values only in Custom Field data may yield no results<\\/li>\\n<\\/ul>\\n<p>1.6<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Added indexer pause toggle to Admin Bar<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_custom_fields allowing you parse custom fields, telling SearchWP what content you want to be indexed<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_custom_field_{$customFieldName} performs the same filtration, but for a single Custom Field<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_excluded_custom_fields allowing you to customize which meta_keys are automatically excluded during indexing<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_background_deltas allowing you to disable automatic delta index updates (you would then need to set up your own via WP-Cron or otherwise, useful for high traffic sites)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_weight_threshold allowing you to specify a minimum weight for search results to be considered (default is zero)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_indexed_post_types allowing you to specify which post types are indexed (note: this controls only what post types are indexed, it has no effect on enabling\\/disabling post types on the SearchWP Settings screen)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_return_orderby_random allowing search results to be returned at random<\\/li>\\n<li><strong>[Improvement]<\\/strong> Indexer optimizations in a number of places, index builds should be even faster (and more considerate of server resources)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Auto-throttling now takes into account your max<em>execution<\\/em>time so as to not exceed it<\\/li>\\n<li><strong>[Improvement]<\\/strong> Indexer now scales how many terms are processed per pass based on your memory_limit (can still be overridden)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of potential table deadlock when indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Overall reduction in memory usage when indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an off-by-one issue when filtering terms by minimum character length when parsing search terms<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the progress meter would automatically dismiss itself after purging the index<\\/li>\\n<\\/ul>\\n<p>1.5.5<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better performance on a number of queries throughout<\\/li>\\n<li><strong>[Improvement]<\\/strong> SearchWP will now monitor load averages (on Linux machines) and auto-throttle when loads get too high<\\/li>\\n<li><strong>[Change]<\\/strong> The default indexer pass timeout (throttle) is now 1 second<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Media may not be indexed on upload<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where terms in file names may be counted twice when indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Many more logging messages included, logs now include internal process identification<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with non-blocking requests and their associated timeouts potentially stalling the indexing process<\\/li>\\n<\\/ul>\\n<p>1.5<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Admin Bar entry (currently displays the last time the current post was indexed)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_admin_bar to allow you to disable the Admin Bar entry if you so choose<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_indexer_throttle allows you to tell the indexer to pause a number of seconds in between passes<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where keyword stems were not fully utilized in AND logic passes<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where attachments may not be properly reindexed after an edit<\\/li>\\n<li><strong>[Fix]<\\/strong> Better index cleanup of deleted Media<\\/li>\\n<li><strong>[Improvement]<\\/strong> SearchWP\'s indexer will now automatically pause\\/unpause when running WordPress Importer<\\/li>\\n<\\/ul>\\n<p>1.4.9<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a regression that removed the searchwp_and_logic_only filter<\\/li>\\n<\\/ul>\\n<p>1.4.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the default comment weight was not properly set on install<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of additional reduction of AND pool results<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_return_orderby_date to allow developers to return results ordered by date instead of weight<\\/li>\\n<\\/ul>\\n<p>1.4.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the minimum word length was not taken into consideration when sanitizing terms<\\/li>\\n<\\/ul>\\n<p>1.4.6<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> More precise refactor of AND logic to prevent potential false positives<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_and_fields allows you to limit which field types apply to AND logic (i.e. limit to Title)<\\/li>\\n<\\/ul>\\n<p>1.4.5<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed potential PHP Warnings<\\/li>\\n<li><strong>[New]<\\/strong> You can now use weights of -1 to forcefully <em>exclude<\\/em> matches<\\/li>\\n<li><strong>[New]<\\/strong> By default SearchWP will now ignore WordPress core postmeta (e.g. _edit_lock)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_omit_wp_metadata to include WordPress core postmeta in the index<\\/li>\\n<\\/ul>\\n<p>1.4.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Better coverage of deferred index delta updates<\\/li>\\n<\\/ul>\\n<p>1.4.3<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of refinement of AND logic in more cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of forced AND logic when it returns zero results<\\/li>\\n<\\/ul>\\n<p>1.4.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a potential issue where the search algorithm refinement may be too aggressive<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_custom_stemmer to allow for custom (usually localized) stemming. <em>Requires a re-index if utilized<\\/em><\\/li>\\n<\\/ul>\\n<p>1.4.1<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter: searchwp_and_logic_only to allow you to explicity force SearchWP to use AND logic only<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_refine_and_results tells SearchWP to further restrict AND results to titles<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_max_and_results to allow you to tell SearchWP when you want it to refine AND results<\\/li>\\n<\\/ul>\\n<p>1.4<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Added a new Advanced setting to allow you to pause the indexer without deactivating SearchWP<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_include_comment_author allows you to enable indexing of comment author<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_include_comment_email allows you to enable indexing of comment author email<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_auto_reindex to allow you to disable automatic reindexing of edited posts<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_indexer_paused to allow you to override the Advanced setting programmatically<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where comments were not accurately indexed<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved stability of results when multiple posts have the same final weight by supplementally sorting by post_date DESC<\\/li>\\n<\\/ul>\\n<p>1.3.6<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter: searchwp_short_circuit to allow you to have SearchWP <em>not<\\/em> run at runtime. Useful when implementing other plugins that utilize search.<\\/li>\\n<\\/ul>\\n<p>1.3.5<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Implemented workaround for issues experienced with Post Types Order that prevented search results from appearing<\\/li>\\n<\\/ul>\\n<p>1.3.4.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a bug with weight attribution that resulted from the update in 1.3.4<\\/li>\\n<\\/ul>\\n<p>1.3.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where taxonomy\\/custom field weight may not have been appropriate attributed when applicable<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where \'Any\' custom field weight may not have been appropriately applied<\\/li>\\n<li><strong>[Improvement]<\\/strong> Remote debugging info now updates more consistently<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additional method for remote debugging<\\/li>\\n<\\/ul>\\n<p>1.3.3<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Initial implementation of Remote Debugging (found in Advanced settings)<\\/li>\\n<li><strong>[New]<\\/strong> Extension: Xpdf Integration<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_external_pdf_processing to allow you to use your own PDF processing mechanism<\\/li>\\n<li><strong>[Improvement]<\\/strong> Less strict AND logic used in the main query<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better database environment check (needed as a result of <a href=\\"http:\\/\\/bugs.mysql.com\\/bug.php?id=41156\\">MySQL bug 41156<\\/a>)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additional cleanup of SearchWP options during uninstallation<\\/li>\\n<li><strong>[Improvement]<\\/strong> Force license deactivation during uninstallation<\\/li>\\n<\\/ul>\\n<p>1.3.2<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> SearchWP now defaults to AND logic with search terms, huge performance boost as a result (note: if no posts are found via AND, OR will be used)<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_and_logic to revert back to OR logic<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with the new deferred index updates<\\/li>\\n<\\/ul>\\n<p>1.3.1<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Added ability to \'wake up\' the indexer if you feel it has stalled<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Custom Field weights would not be properly retrieved if there were capital letters in the key<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with cron scheduling and management<\\/li>\\n<li><strong>[Improvement]<\\/strong> Delta index updates are now performed in the background<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced latency between indexer passes<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better tracking of repeated passes on lengthy index entries<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better accommodation of potential indexer pass overlapping and in doing so reduce the liklihood of database table deadlocking<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better notifications regarding license activation<\\/li>\\n<li><strong>[Improvement]<\\/strong> More useful debugger logging<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better index progress display after purging the index<\\/li>\\n<\\/ul>\\n<p>1.3<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter: searchwp_search_query_order to allow changing the search query order results at runtime<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_max_index_attempts to allow control over how many times the indexer should try to index a post<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_prevent_indexing to allow exclusion of post IDs from the index process entirely<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better low-level interception of WordPress query process so as to accommodate other plugin workflows<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better realtime monitoring of indexer progress<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better detection and handling of troublesome posts when indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of \'initial index complete\' notification after purging and reindexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Cleaned up purging and uninstallation routines<\\/li>\\n<\\/ul>\\n<p>1.2.5<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Search statistics are no longer reset along with purging the index<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better options cleanup both during index purges and uninstallations<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improvement in overall indexer performance, not by a large margin, but some<\\/li>\\n<\\/ul>\\n<p>1.2.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the database environment check was too aggressive and prevented activation before the environment was set up<\\/li>\\n<\\/ul>\\n<p>1.2.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where numeric Custom Field data was not indexed accurately<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better detection for custom database table creation<\\/li>\\n<\\/ul>\\n<p>1.2.2<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better accommodation for regression in 1.2.0 that prevented proper taxonomy exclusion<\\/li>\\n<\\/ul>\\n<p>1.2.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where index progress indicator could exceed 100% after disabling attachment indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where category exclusion would not always apply to search engine settings<\\/li>\\n<\\/ul>\\n<p>1.2.0<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Overall reduction in query time when performing searches (sometimes down to 50%!)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Indexing process now handles huge posts in a more efficient way, avoiding PHP timeouts<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of term indexing resulting in a more accurate index<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where term IDs were not pulled properly during indexing<\\/li>\\n<li><strong>[Change]<\\/strong> Changed the default weight for Titles so as to better meet user expectations<\\/li>\\n<\\/ul>\\n<p>1.1.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the WordPress database prefix was hardcoded in certain situations<\\/li>\\n<li><strong>[Improvement]<\\/strong> Removed redundant SQL call resulting in faster search queries<\\/li>\\n<\\/ul>\\n<p>1.1.1<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> More parameters passed to just about every SearchWP hook, please view the documentation for details<\\/li>\\n<\\/ul>\\n<p>1.1<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> A more formal integration of Extensions such that settings screens can be added<\\/li>\\n<li><strong>[New]<\\/strong> You can now limit Media search results by their type (e.g. search only Documents)<\\/li>\\n<li><strong>[New]<\\/strong> Extension: Term Synonyms - manually define term synonyms<\\/li>\\n<li><strong>[New]<\\/strong> Extension: WPML Integration<\\/li>\\n<li><strong>[New]<\\/strong> Extension: Polylang Integration<\\/li>\\n<li><strong>[New]<\\/strong> Extension: bbPress Integration<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_include that accepts an array of limiting post IDs during searches<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_query_main_join to allow custom joining during the main search query<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_query_join to allow custom joining in per-post-type subqueries when searching<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_query_conditions to allow custom conditions in per-post-type subqueries when searching<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_index_attachments to allow you to disable indexing of Attachments entirely to save index time<\\/li>\\n<li><strong>[Improvement]<\\/strong> Major reduction in query time if you choose to NOT include Media in search results (or limit Media to Documents)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better edge case coverage to the indexing process; it\'s now less likely to stall arbitrarily<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better delta index updates by skipping autosaves and revisions more aggressively<\\/li>\\n<li><strong>[Improvement]<\\/strong> Fixed a UI issue where the CPT column on the settings screen may expand beyond the right hand column<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better default weights<\\/li>\\n<\\/ul>\\n<p>1.0.10<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Added filter searchwp_common_words<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_enable_parent_attribution_{posttype}<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_enable_attribution_{posttype}<\\/li>\\n<\\/ul>\\n<p>1.0.9<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better cleaning and processing of taxonomy terms<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additional parameter when invoking SearchWPSearch for 3rd party integrations (props Matt Gibbs)<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with Firefox not liking SVG files<\\/li>\\n<\\/ul>\\n<p>1.0.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where duplicate terms could get returned when sanitizing<\\/li>\\n<li><strong>[New]<\\/strong> Extension: Fuzzy Searching<\\/li>\\n<li><strong>[New]<\\/strong> Extension: Term Archive Priority<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_results to faciliate filtration of results before they\'re returned<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_query_limit_start to allow offsetting the main query results<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_query_limit_total to allow offsetting the main query results<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_pre_search_terms to allow filtering search terms before searches run<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_load_posts so as to prevent weighty loading of all post data when all you want is IDs (props Matt Gibbs)<\\/li>\\n<li><strong>[Improvement]<\\/strong> More arguments passed to searchwp<em>before<\\/em>query<em>index and searchwp<\\/em>after<em>query<\\/em>index actions<\\/li>\\n<\\/ul>\\n<p>1.0.7<\\/p>\\n<ul>\\n<li><strong>[NOTICE]<\\/strong> Due to an indexer update, it is recommended that you purge your index after updating<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better, more performant indexer behavior during updates<\\/li>\\n<li><strong>[Improvement]<\\/strong> Added logging for supplemental searches<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better punctuation handling during indexing and searching<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better cleanup of stored options when applicable<\\/li>\\n<li><strong>[Fix]<\\/strong> Better logging of original search queries compared to what actually gets sent through the algorithm<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed potential PHP warning<\\/li>\\n<\\/ul>\\n<p>1.0.6<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of source code-related indexing and searching<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_engine_settings_{$engine} to allow adjustment of weights at runtime<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_max_search_terms to cap the number of search terms that can be searched for (default 6)<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_max_search_terms_supplemental to cap the number of terms for supplemental searches<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_max_search_terms_supplemental_{$engine} to cap the number of terms for supplemental searches by engine<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with empty search queries showing up in search stats<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with CSS alignment of search stats<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the indexer would index and then re-index posts when not needed<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a MySQL error when logging indexer actions<\\/li>\\n<\\/ul>\\n<p>1.0.5<\\/p>\\n<ul>\\n<li><strong>[Change]<\\/strong> Updated user-agent of indexer background process for easier debugging<\\/li>\\n<li><strong>[New]<\\/strong> Added initial support for common debugging assistance via searchwp_log action<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better support for WordPress installations in subdirectories<\\/li>\\n<li><strong>[Improvement]<\\/strong> If the initial index is already built by the time you go from activation to settings screen, a notice is displayed<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better support for generating your own pagination with supplemental searches http:\\/\\/d.pr\\/MXgp<\\/li>\\n<li><strong>[Fix]<\\/strong> Stopped \'empty\' search queries from being logged<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_index_chunk_size to adjust how many posts are indexed at a clip<\\/li>\\n<\\/ul>\\n<p>1.0.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Much better handling of all UTF-8 characters both when indexing and when searching<\\/li>\\n<\\/ul>\\n<p>1.0.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with the auto-update script not resolving properly<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of special characters both when indexing and querying<\\/li>\\n<\\/ul>\\n<p>1.0.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Custom Field weights weren\'t saving properly on the Settings screen<\\/li>\\n<\\/ul>\\n<p>1.0.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that would cause searches to fail if an enabled custom post type had a hyphen in it\'s name<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an off-by-one issue in generating statistical figures<\\/li>\\n<\\/ul>\\n<p>1.0.0<\\/p>\\n<ul>\\n<li>Initial release<\\/li>\\n<\\/ul>\\n"},"banners":{"high":"","low":""},"description":[""],"changelog":["<p>2.9.13<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Prevent redundant statistics logging on paginated results when using SWP_Query<\\/li>\\n<li><strong>[Fix]<\\/strong> Better handling of taxonomy terms with special characters<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes PHP Warning and PHP Notice in certain cases<\\/li>\\n<\\/ul>\\n<p>2.9.12<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Index better optimized when limiting to Media mime type<\\/li>\\n<li><strong>[Improvement]<\\/strong> AND logic is more restrictive when applicable<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of license key when provided via constant or filter<\\/li>\\n<li><strong>[Update]<\\/strong> Updates translation source<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes inaccurate indexer progress in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes handling of All Documents mime type Media limiter<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes PHP Warning<\\/li>\\n<\\/ul>\\n<p>2.9.11<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong>\\u00a0Additional index optimization when delta updates are applied via new filter searchwp_aggressive_delta_update<\\/li>\\n<li><strong>[Improvement]<\\/strong> Debug output cleanup<\\/li>\\n<li><strong>[Fix]<\\/strong> Implements omitted filter argument<\\/li>\\n<\\/ul>\\n<p>2.9.10<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Resolves an issue where AND logic wasn\'t strict enough in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Relocated searchwp_indexer_pre action trigger to restore expected behavior<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additinal refinements to delta update queue processing to prevent excessive server resource usage in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Adds edit icon to supplemental engine name to communicate it is editable<\\/li>\\n<li><strong>[Change]<\\/strong> License key is no longer displayed in license key field if populated via constant or hook<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_engine_use_taxonomy_name that controls displaying name or label of Taxonomies in enging settings<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_and_fields_{$post_type} allowing for AND field customization per post type<\\/li>\\n<\\/ul>\\n<p>2.9.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixes an issue where post type Limit rules were too aggressive in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refined index delta update routine to reduce potentially unnecessary triggers<\\/li>\\n<\\/ul>\\n<p>2.9.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Resolves issue of inaccurate results count when parent attribution is in effect<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed PHP Warning introduced in 2.9.5<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better processing of engine Rules during indexing<\\/li>\\n<\\/ul>\\n<p>2.9.6.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed PHP Warning introduced in 2.9.5<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed link in admin notice<\\/li>\\n<\\/ul>\\n<p>2.9.6<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue causing newly regiestered taxonomies to be unavailable in settings UI<\\/li>\\n<li><strong>[Fix]<\\/strong> Messaging for index being out of date is now more accurate<\\/li>\\n<li><strong>[Fix]<\\/strong> Paged searches are no longer redundantly logged<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved default regex patterns by making them more strict<\\/li>\\n<li><strong>[Update]<\\/strong> Updated PDF parsing libraries<\\/li>\\n<\\/ul>\\n<p>2.9.5<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where \'Any Custom Field\' did not work as expected in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where taxonomies added since the last engine save may not be available<\\/li>\\n<li><strong>[Improvement]<\\/strong> Actual weight multiplier is displayed in tooltip<\\/li>\\n<\\/ul>\\n<p>2.9.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a CSS bug causing multiselect overlapping when configuring multiple post types<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue preventing searches of hierarchical post types in the admin<\\/li>\\n<\\/ul>\\n<p>2.9.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a searchwp_and_logic_only regression introduced in 2.9<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of initial default engine model<\\/li>\\n<\\/ul>\\n<p>2.9.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with some custom ORDER BY statements<\\/li>\\n<\\/ul>\\n<p>2.9.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a potential issue with sql_mode=only_full_group_by support (added in 2.9)<\\/li>\\n<li><strong>[Fix]<\\/strong> Avoid error when parsing PDFs without mbstring<\\/li>\\n<\\/ul>\\n<p>2.9<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Redesigned engine configuration interface!<\\/li>\\n<li><strong>[New]<\\/strong> Index is now further optimized as per engine settings<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_weight_max to customize a maximum weight<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_legacy_settings_ui to use legacy settings UI<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_apply_engines_rules to control whether engine rules are considered during indexing<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_additional_meta_exclusions to control whether default additional Custom Fields are excluded from indexing<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_supports_label_{post_type}_{support} to customize the label used for a post type native attribute<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additional debug statements output when enabled<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better formatting of HTML comment debug output<\\/li>\\n<li><strong>[Fix]<\\/strong> Less aggressive handling of pre_get_posts during searching<\\/li>\\n<li><strong>[Fix]<\\/strong> Fix an issue with sql_mode=only_full_group_by (default in MySQL 5.7)<\\/li>\\n<\\/ul>\\n<p>2.8.17<\\/p>\\n<ul>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with database table creation<\\/li>\\n<\\/ul>\\n<p>2.8.16<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where exclusionary weight was not properly applied to all Custom Fields<\\/li>\\n<li><strong>[Fix]<\\/strong> Resolved premature AND logic aggressiveness in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Revised database creation schema to better cooperate with more database environments<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better assumed sorting of results<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_stats_table_class to control CSS class applied to stats output<\\/li>\\n<\\/ul>\\n<p>2.8.15<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of regex pattern matches<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixes an issue where Media-only default engines did not fully build index<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.8.14<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Additional checks to prevent overrun with other plugins<\\/li>\\n<\\/ul>\\n<p>2.8.13<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fix a regression introduced to SWP_Query in 2.8.11 that may have prevented pagination from working as expected<\\/li>\\n<\\/ul>\\n<p>2.8.12<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Additional main query checks to improve plugin compatibility<\\/li>\\n<\\/ul>\\n<p>2.8.11<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with main query check that prevented search results from appearing in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where default includes\\/exclusions would be applied outside the main query<\\/li>\\n<li><strong>[Change]<\\/strong> Updated common words (stopwords)<\\/li>\\n<li><strong>[Change]<\\/strong> Switch from page parameter to paged<br \\/>\\nso as to better match WP_Query<\\/li>\\n<\\/ul>\\n<p>2.8.10<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Improved main query checks<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved invisible character tokenizing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with AND logic limits given certain engine configurations<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed PHP Warnings<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed lack of output for two tooltips<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where usage of -1 weights to actively exclude matches overran enabled engine post type(s)<\\/li>\\n<\\/ul>\\n<p>2.8.9<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fix PHP Fatal Error with $wp_query<\\/li>\\n<li><strong>[Fix]<\\/strong> Fix regression introduced in 2.8.8 that prevented admin searches from working properly in some cases<\\/li>\\n<\\/ul>\\n<p>2.8.8<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter searchwp_pre_set_post allowing for filtration of each post object prior to indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Better interoperation with Widgets<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent double search logs in certain cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Properly cancel native search SQL when performing admin search (props Jim)<\\/li>\\n<li><strong>[Fix]<\\/strong> Repaired application of \'Remove all traces\' feature on Advanced settings page<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where incorrect total results counts were logged<\\/li>\\n<li><strong>[Improvement]<\\/strong> PHP Warning cleanup<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better accommodation for customization during import routines<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better accommodation of engine configuration and exclusions when performing AND logic pass<\\/li>\\n<li><strong>[Change]<\\/strong> Update to SWP_Query: post__in and post__not_in parameters are now explicit (previously behaved like hooks)<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.8.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed missing tooltip content<\\/li>\\n<li><strong>[Improvement]<\\/strong> Using searchwp_admin_bar now applies to search modification notices<\\/li>\\n<li><strong>[Improvement]<\\/strong> License key now included in System Information<\\/li>\\n<li><strong>[New]<\\/strong> Taxonomy term slugs are now indexed (use searchwp_indexer_taxonomy_term_index_slug to disable)<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_taxonomy_term allowing for filtration on taxonomy terms prior to indexing<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.8.6<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Fixed an issue with imposed engine config implementation for empty searches<\\/li>\\n<\\/ul>\\n<p>2.8.5<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Engine settings (e.g. exclusions\\/inclusions) are now imposed for empty searches<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_disable_impose_engine_config to disable imposed engine settings for empty searches<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have triggered unnecessary index update requests<\\/li>\\n<li><strong>[Improvement]<\\/strong> Style updates to better match WordPress\' implementation of system font<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of indexer requests<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better support when Admin\\/Dashboard searches are enabled<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better utilization of existing extracted document content when triggering an index rebuild<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better feedback when document parsing dependencies are not available<\\/li>\\n<li><strong>[Update]<\\/strong> Added more file type limiters to engine settings<\\/li>\\n<li><strong>[Update]<\\/strong> Updated translation sources<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.8.4<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_comment to filter comment arguments during indexing<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_pre_get_comments to filter comment arguments during indexing<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_comments_args to filter comment arguments during indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented searching in the WordPress admin (when enabled)<\\/li>\\n<\\/ul>\\n<p>2.8.3<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter searchwp_search_args to filter search arguments at runtime<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of object caching<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better messaging when rebuilding index<\\/li>\\n<li><strong>[Improvement]<\\/strong> Dequeue\\/deregister legacy versions of select2 that are imposed upon SearchWP\'s settings screen\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of regex matches<\\/li>\\n<\\/ul>\\n<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that sometimes prevented the indexer progress bar from displaying after rebuilding index<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have prevented manually edited document content from being fully re-indexed<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed PHP Warning during short circuit check<\\/li>\\n<li><strong>[Fix]<\\/strong> Disabling the minimum character count reduces length to 1 instead of 2<\\/li>\\n<\\/ul>\\n<p>2.8.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a mime type mismatch that prevented accurate Media limiting using All Documents file type<\\/li>\\n<li><strong>[Fix]<\\/strong> Admin Bar and Advanced tab indexer pausing now use the same setting<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue when checking for utf8mb4 support<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved regex pattern for hyphen-separated matches<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved aggressiveness of search algorithm where necessary to prevent unexpected filtration during searches<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.8.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a potential PHP error\\u00a0with write\\u00a0context<\\/li>\\n<\\/ul>\\n<p>2.8<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Document parsing support added for Office documents (.docx, .xlsx, .pptx)<\\/li>\\n<li><strong>[New]<\\/strong> Document parsing support added for OpenOffice\\/LibreOffice documents (.odt, .ods, .odp)<\\/li>\\n<li><strong>[New]<\\/strong> Document parsing support added for Rich Text documents<\\/li>\\n<li><strong>[New]<\\/strong> Settings screen update to better accommodate common actions<\\/li>\\n<li><strong>[New]<\\/strong> Improve settings screen performance by requesting taxonomy terms via AJAX<\\/li>\\n<li><strong>[Fix]<\\/strong> When searchwp_in_admin is enabled searching in Grid view for Media now works as expected<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of large content (including parsed documents)<\\/li>\\n<li><strong>[Update]<\\/strong> Updated translation source<\\/li>\\n<li><strong>[Update]<\\/strong> Updated select2<\\/li>\\n<\\/ul>\\n<p>2.7.2<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of native search query<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a case where searchwp_show_conflict_notices was not respected<\\/li>\\n<li><strong>[Fix]<\\/strong> Fix PHP Warning (Invalid argument supplied for foreach() in \\/wp-includes\\/query.php on line 4890)<\\/li>\\n<\\/ul>\\n<p>2.7.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Cleaned up PHP Warning in SWP_Query<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed positioning of Extensions dropdown, other minor style updates<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with SWP_Query not resetting set hooks causing inaccurate results<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Alternate Indexer may report posts left to index when no post types are enabled<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where AND logic pass was too restrictive in some circumstances<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue when limiting Media results to Images only throwing a PHP Warning<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that caused some WP Admin notices to not display<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refactored some stats logic into SearchWP_Stats<\\/li>\\n<li><strong>[Change]<\\/strong> Changed PHPCS ruleset which resulted in some additional hardening\\/formatting<\\/li>\\n<li><strong>[Update]<\\/strong> Updated translation source<\\/li>\\n<\\/ul>\\n<p>2.7<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter searchwp_weight_mods allowing for direct manipulation of computed weights within the search algorithm<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_license_key to programmatically define SearchWP license key<\\/li>\\n<li><strong>[New]<\\/strong> SearchWP license key can now be defined with SEARCHWP_LICENSE_KEY constant<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_initial_engine_settings to programmatically define default engine configurations on activation<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_keyword_stem_locale to enable keyword stemming in the current locale<\\/li>\\n<li><strong>[New]<\\/strong> Support for \'fields\' =&gt; \'ids\' argument in SWP_Query<\\/li>\\n<li><strong>[New]<\\/strong> Support for post_type argument in SWP_Query<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_purge_pdf_content to remove parsed PDF content during an index purge<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_skip_vendor_libs to prevent loading of any vendor libraries<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_indexer_taxonomy_terms allowing for filtration of taxonomy terms pre-index<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where searchwp_exclusive_regex_matches could have been too greedy<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where a filtered post type could not be enabled in engine settings<\\/li>\\n<li><strong>[Fix]<\\/strong> Use multibyte string manipulation when possible<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the indexer progress bar may not display in WordPress 4.4+<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of matches when taking advantage of searchwp_exclusive_regex_matches<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved handling of deeply serialized meta data<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced indexer query overhead<\\/li>\\n<li><strong>[Improvement]<\\/strong> Keyword stemming is only available if the current locale supports it (if you are using a custom stemmer you will need to update)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Less aggressive checks against failed PDF parsing that generated false positive results<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of unicode whitespace during PDF parsing<\\/li>\\n<li><strong>[Change]<\\/strong> Debug log is now written to searchwp-debug.txt in the base uploads directory<\\/li>\\n<li><strong>[Change]<\\/strong> Parsed PDF content is not removed when the index is purged<\\/li>\\n<li><strong>[Update]<\\/strong> Updated PDF parsing library<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.6.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where AND logic may not be enforced in some circumstances<\\/li>\\n<li><strong>[Fix]<\\/strong> PDF metadata is now properly delted when Nuke on Delete is enabled<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue in the tokenizer that may have prevented tokens from being broken apart when HTML had no whitespace<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a potential issue with PDF content indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with the indexer not fully completing when only Media was enabled<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup when no results were found after tokenizing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved performance when Media is given parent attribution<\\/li>\\n<li><strong>[Improvement]<\\/strong> SearchWP will now internally short circut when an empty search is performed for the main query<\\/li>\\n<li><strong>[Improvement]<\\/strong> Filtered post types are now given priority on the settings screen<\\/li>\\n<li><strong>[New]<\\/strong> Added Dutch translation<\\/li>\\n<\\/ul>\\n<p>2.6<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New class: SWP_Query which aims to mirror WP_Query in many ways, but with a SearchWP twist<\\/li>\\n<li><strong>[New]<\\/strong> Settings UI has been revamped<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_swp_query_args to filter SWP_Query args at runtime<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_init fires when the settings utility has been initialized<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_load fires when SearchWP has loaded<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_before_header fires before the settings header is output<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_nav_tab to implement settings tabs<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_after_header fires after the settings header is output<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_before\\\\my_view where my_view is the name of the settings view for that tab<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_view\\\\my_view where my_view is the name of the settings view for that tab<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_after\\\\my_view where my_view is the name of the settings view for that tab<\\/li>\\n<li><strong>[New]<\\/strong> New action: searchwp_settings_footer fires after each settings view has been displayed<\\/li>\\n<li><strong>[New]<\\/strong> Results weights are included in HTML comment block when debugging is enabled<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_debug_append_weights_to_titles whether weights should be included in HTML comment block debug information<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_show_filter_conflict_notices whether filter conflicts should be shown when debugging is enabled (defaults to false)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better license activation UX<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduction of index overhead by way of pairing to engine settings<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refined list of default common (stop) words<\\/li>\\n<li><strong>[Fix]<\\/strong> Clear out delta ceiling update check when waking up the indexer<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have caused the indexer to loop when a post has no content to index after tokenizing\\/processing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the settings screen spinner would not display<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented loading of some assets if the plugin directory was renamed<\\/li>\\n<li><strong>[Update]<\\/strong> Updated translation files<\\/li>\\n<\\/ul>\\n<p>2.5.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with utf8mb4 (e.g. emoji) support (NOTE: only <em>new<\\/em> installations will support utf8mb4) \\u2014\\u00a0more information at <a href=\\"https:\\/\\/searchwp.com\\/releases\\/\\">https:\\/\\/searchwp.com\\/releases\\/<\\/a><\\/li>\\n<li><strong>[Change]<\\/strong> All camelCase function and method names have been deprecated (not removed (yet)) in favor of underscores<\\/li>\\n<\\/ul>\\n<p>2.5.6<\\/p>\\n<ul>\\n<li><strong>[Improved]<\\/strong> Better settings standardization<\\/li>\\n<\\/ul>\\n<p>2.5.5<\\/p>\\n<ul>\\n<li><strong>[Security Fix]<\\/strong>\\u00a0XSS prevention for authenticated users in the admin with add_query_arg<\\/li>\\n<li><strong>[Improved]<\\/strong> Security improvements: additional\\/redundant escaping\\/preparing\\/casting so as to harden the code base and improve readability<\\/li>\\n<li><strong>[Improved]<\\/strong> More accurate Today stats<\\/li>\\n<li><strong>[Improved]<\\/strong> Better translation support<\\/li>\\n<li><strong>[Improved]<\\/strong> Better exception handling with PDF parsing<\\/li>\\n<li><strong>[Fix]<\\/strong>\\u00a0Better handling of misconfiguration when attributing an excluded post<\\/li>\\n<li><strong>[New]<\\/strong> Added French translation<\\/li>\\n<\\/ul>\\n<p>2.5.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with regex whitelist term duplication in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue when limiting AND fields to one field<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed inconsistent default parameter for searchwp_indexed_post_types filter<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup with filter conflict detection when debugging is enabled<\\/li>\\n<\\/ul>\\n<p>2.5.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong>\\u00a0Fixed an issue that may have prevented taxonomy searches from returning results<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a regression introduced in 2.5 that aimed to optimize the main search query by omitting taxonomies with a weight of zero<\\/li>\\n<li><strong>[Fix]<\\/strong>\\u00a0Fixed an issue that may have prevented supplemental search results from appearing<\\/li>\\n<\\/ul>\\n<p>2.5<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Alternate, browser based indexer for cases where background indexing doesn\'t work<\\/li>\\n<li><strong>[New]<\\/strong> Front end Admin Bar entry that calls out any search modifications put in place (e.g. minimum word length, common words, maximum search length)<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_alternate_indexer to trigger the new browser-based indexer<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_log_search to allow prevention of search logging on a per-case basis<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_init to allow for dynamic initialization of SearchWP<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_max_delta_attempts to catch edge cases causing repeated delta updates<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_indexer_taxonomies allows developers to customize which taxonomies are indexed<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_indexer_unindexed_args to customize WP_Query arguments used to locate unindexed posts<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_indexer_unindexed_media_args to customize WP_Query arguments used to locate unindexed Media<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_failed_index_notice to customize who can see the notice about unindexed posts<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_remove_pre_get_posts to define whether all hooks to pre_get_posts are removed during indexing (a very common conflict)<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_indexer_pre_process_content allows developers to customize the content being indexed before it is processed and indexed<\\/li>\\n<li><strong>[New]<\\/strong> Set default array of excluded IDs to the main search query\'s post__not_in<\\/li>\\n<li><strong>[New]<\\/strong> Set default array of included IDs to the main search query\'s post__in<\\/li>\\n<li><strong>[New]<\\/strong> PDF metadata is now indexed<\\/li>\\n<li><strong>[Change]<\\/strong> Use get_query_var() instead of directly grabbing $wp_query attributes<\\/li>\\n<li><strong>[Change]<\\/strong> Add index.php to default loopback endpoint to avoid false positives with WAFs<\\/li>\\n<li><strong>[Change]<\\/strong> Use debug.txt instead of debug.log<\\/li>\\n<li><strong>[Change]<\\/strong> PDF text extraction abstracted to it\'s own method SWP()-&gt;extract_pdf_text( $post_id )<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented limiting Media results for an engine to more than one MIME type group<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an off-by-one issue that prevented single terms from being indexed when using the searchwp_process_term_limit filter<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that interfered with pagination in the WP admin when searchwp_in_admin was set to true<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup in Dashboard Widget<\\/li>\\n<li><strong>[Fix]<\\/strong> Only output Dashboard Widget assets on the Dashboard<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an overflow issue in Dashboard Widget when collapsed on load<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Dashboard Widget stats transients were not cleared when stats were reset<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better minimum height for statistics graph<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better width restriction on settings screen for post type tabs<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better detection of database environment change that may interfere with indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Weights of less than 0 are now called out to ensure intention of excluding results<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better checks against searchwp_indexed_post_types when displaying settings screen<\\/li>\\n<li><strong>[Improvement]<\\/strong> Main search algorithm optimizations<\\/li>\\n<li><strong>[Improvement]<\\/strong> Indexer now checks for excluded posts before reindexing them after a purge<\\/li>\\n<li><strong>[Improvement]<\\/strong> Optimizations to search algorithm when weights of zero are used<\\/li>\\n<li><strong>[Improvement]<\\/strong> UI improvements on the settings screen<\\/li>\\n<li><strong>[Update]<\\/strong> Updated translation files<\\/li>\\n<li><strong>[Update]<\\/strong> Updated updater<\\/li>\\n<\\/ul>\\n<p>2.4.11<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented post attribution when using explicit IDs<\\/li>\\n<li><strong>[Fix]<\\/strong> Set proper flags when all search terms have been invalidated<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup with Dashboard Widget<\\/li>\\n<li><strong>[Improvement]<\\/strong> Further optimization of results pool reduction when exclusions are in place<\\/li>\\n<li><strong>[Update]<\\/strong> Updated translation source files<\\/li>\\n<li><strong>[Change]<\\/strong> searchwp_term_in filter now has a 3rd parameter with the original (e.g. unstemmed when stemming is enabled) term<\\/li>\\n<\\/ul>\\n<p>2.4.10<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> PHP 5.2 compatibility with PDF parser fallback<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where some search strings were not properly ignored<\\/li>\\n<li><strong>[Fix]<\\/strong> Proper clearing of meta boxes on stats page at certain resolutions<\\/li>\\n<\\/ul>\\n<p>2.4.9<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where limiting Media results to All Documents did not apply the expected limit<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where AND logic refinement may cause zero results to display depending on Title weight<\\/li>\\n<li><strong>[Update]<\\/strong> Updated PHP PDF parser (requires PHP 5.3+, will still fall back to less reliable legacy parser if PHP 5.2)<\\/li>\\n<li><strong>[Change]<\\/strong> Return WP_Error when an invalid search engine name is used<\\/li>\\n<\\/ul>\\n<p>2.4.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where proper weights may not have been properly retained throughout the entire search algorithm, resulting in zero results<\\/li>\\n<li><strong>[Fix]<\\/strong> Default search results now take into account an offset (if one was set)<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_query_offset allowing for customization of the offset of the default search engine<\\/li>\\n<\\/ul>\\n<p>2.4.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup: removed deprecated usage of mysql_get_server_info()<\\/li>\\n<\\/ul>\\n<p>2.4.6<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented parsed PDF content from being indexed on the first pass<\\/li>\\n<li><strong>[New]<\\/strong> Version numbers (SearchWP, WordPress, PHP, MySQL) are now passed along with support requests<\\/li>\\n<\\/ul>\\n<p>2.4.5.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup for in_array() in searchwp.php on line 1588<\\/li>\\n<\\/ul>\\n<p>2.4.5<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Direct integration of support ticket creation within the WordPress admin<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_lightweight_settings allowing for a speedier but degraded settings screen loading (e.g. not loading taxonomy terms)<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_dashboard_widget_cap for more control over Dashboard Widget visibility (defaults to settings cap (which defaults to manage_options))<\\/li>\\n<li><strong>[New]<\\/strong> Settings export\\/import facilitated by copying and pasting JSON of engine configuration(s)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Due to numerous issues with object caching, index validation hashes are stored as options instead of transients<\\/li>\\n<li><strong>[Improvement]<\\/strong> Updated licensing system framework<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of initial UI load on settings screen by obstructing UI until all bindings are properly in place<\\/li>\\n<li><strong>[Change]<\\/strong> Switched to <a href=\\"http:\\/\\/gionkunz.github.io\\/chartist-js\\/\\">Chartist<\\/a> for statistics graphs<\\/li>\\n<li><strong>[Change]<\\/strong> Reinstated automatic theme conflict notices (filter conflicts continue to appear only when debugging is enabled)<\\/li>\\n<li><strong>[Fix]<\\/strong> Search statistics for Today are more accurate<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented Shortcodes from being processed when using searchwp_do_shortcode<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue triggered by a Custom Post Type named label preventing proper SearchWP settings storage<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented Dashboard Widget transient storage if supplemental search names exceeded 17 characters<\\/li>\\n<\\/ul>\\n<p>2.4.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where certain search terms were being double-stemmed<\\/li>\\n<\\/ul>\\n<p>2.4.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where PDFs attributed to their post parent weren\'t showing up in search results<\\/li>\\n<\\/ul>\\n<p>2.4.2<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Resolved query latency introduced in 2.4.1 concerning attribution<\\/li>\\n<\\/ul>\\n<p>2.4.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented parent attribution from working properly in certain cases<\\/li>\\n<\\/ul>\\n<p>2.4<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> SearchWP will now detect whether you\'re using HTTP Basic Authentication<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_basic_auth_creds allowing developers to define HTTP Basic Authentication credentials<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_query_select_inject allowing developers the ability to inject their own statements into the main search query, allowing for extensive customization of results display beyond keyword weights<\\/li>\\n<li><strong>[New]<\\/strong> Search Statistics Dashboard Widget<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_dashboard_widget allowing developers to disable the Search Statistics Dashboard Widget<\\/li>\\n<li><strong>[New]<\\/strong> System Information panel (on the Advanced settings screen) to ease support<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of searchwp_indexer_enabled when used at the same time as searchwp_indexer_paused<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of accented characters<\\/li>\\n<li><strong>[Fix]<\\/strong> Force transient deletion<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where keyword stemming may have not been appropriately applied<\\/li>\\n<li><strong>[Change]<\\/strong> Conflict notices are now only displayed when debugging is enabled<\\/li>\\n<\\/ul>\\n<p>2.3.3<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Admin Bar entry now elaborates on why a post is not indexed (e.g. draft status if not filtered)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Admin Bar entry now more accurately calls out when a post is in the process of being indexed<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have prevented strings of only digits from being properly indexed<\\/li>\\n<\\/ul>\\n<p>2.3.2<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better capture of SQL_BIG_SELECTS errors by including a link to the fix in the Admin Bar<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of character encoding when parsing PDFs<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where posts excluded from the index were not properly listed on the exclusions page<\\/li>\\n<\\/ul>\\n<p>2.3.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a check for DOMDocument and cleaned up PHP warning about empty DOMDocument content<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where saved Custom Field keys were not retrieved properly on the settings screen<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where exclusion fields weren\'t treated with select2 when creating supplemental search engines<\\/li>\\n<li><strong>[Change]<\\/strong> Loading the settings screen UI partial via AJAX is now opt-in\\n<ul>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_lazy_settings allowing developers to trigger a cachebusting version of the settings screen<\\/li>\\n<\\/ul>\\n<\\/li>\\n<\\/ul>\\n<p>2.3<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Added UI feedback when the indexer has been automatically throttled due to excessive server load<\\/li>\\n<li><strong>[New]<\\/strong> Deprecated $searchwp global in favor of new function SWP()<\\/li>\\n<li><strong>[New]<\\/strong> You can now retrieve the specific weights that set the order for search results per-post and per-post-type-per-post (SWP()-&gt;results_weights)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_endpoint allowing developers to customize the endpoint used by the indexer for each pass (uses only the slug, the site_url() is automatically prepended)<\\/li>\\n<li><strong>[New]<\\/strong> SearchWP will now index what it considers valuable HTML element attribute content (e.g. alt text)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_indexer_tag_attributes allowing developers to customize which elements and attributes are considered valuable<\\/li>\\n<li><strong>[Improvement]<\\/strong> Significant performance increase of main search algorithm<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better UTF-8 support when tokenizing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Indexer now ensures it\'s not being throttled before jumpstarting<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reset AUTO_INCREMENT when the index is purged<\\/li>\\n<li><strong>[Improvement]<\\/strong> Deprecated and removed explicit indexed meta flag in favor of utilizing the already present last_index meta flag<\\/li>\\n<li><strong>[Fix]<\\/strong> Removed redundant error_log usage with debugging enabled<\\/li>\\n<li><strong>[Fix]<\\/strong> Properly log searches called directly from search class<\\/li>\\n<li><strong>[Fix]<\\/strong> Empty searches are no longer logged when performed via the API<\\/li>\\n<li><strong>[Change]<\\/strong> Removed Remote Debugging as it no longer applies to support<\\/li>\\n<li><strong>[Change]<\\/strong> Settings screen is now loaded via AJAX so as to get around excessive page caching in the WP admin by certain hosts<\\/li>\\n<li><strong>[Change]<\\/strong> MyISAM is no longer explicitly used when creating custom database tables (uses your MySQL default instead)<\\/li>\\n<li><strong>[Change]<\\/strong> Refined default common words<\\/li>\\n<\\/ul>\\n<p>2.2.3<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Another revision to the indexer stall check<\\/li>\\n<li><strong>[Improvement]<\\/strong> Updated translation source<\\/li>\\n<li><strong>[New]<\\/strong> Added an admin notice if your log file exceeds 2MB<\\/li>\\n<\\/ul>\\n<p>2.2.2<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better indexer stall check<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of search logs (moved from main class method to search class) to better accommodate 3rd party integrations<\\/li>\\n<\\/ul>\\n<p>2.2.1<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of indexer stall check<\\/li>\\n<li><strong>[Improvement]<\\/strong> Switched Admin Bar entry from \'Currently Being Indexed\' to \'In index queue\' for accuracy\'s sake<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of delta updates prior to the initial index being built<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better implementation of searchwp_exclusive_regex_matches usage, matches are now extracted earlier resulting in more concise results<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented search queries from being logged when instantiating the search class directly<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where manually edited PDF content would be overwritten by a subsequent delta index update after saving<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have prevented the indexer from fully waking up when waking up the indexer<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a false positive when checking for WPML Integration<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with Xpdf Integration not saving the extracted text<\\/li>\\n<\\/ul>\\n<p>2.2<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New class: SearchWP_Stats which will eventually house a number of utility methods for better statistics as development continues<\\/li>\\n<li><strong>[New]<\\/strong> SearchWP will now detect if you\'re running a plugin that has an integration Extension available and tell you about it<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_omit_meta_key allows developers to omit specific meta keys from being indexed during indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Hardened the indexer communication process, reducing server resource consumption during indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of regex whitelist matches that result with multi-word tokens (e.g. spaces within) NOTE: having multi-word matches is not recommended<\\/li>\\n<li><strong>[Improvement]<\\/strong> Added $engine parameter to searchwp_query_orderby filter<\\/li>\\n<li><strong>[Improvement]<\\/strong> Simplified the check for a stalled indexer<\\/li>\\n<li><strong>[Improvement]<\\/strong> Multi-term regex whitelist matches will no longer be tokenized but indexed as a whole for better phrase-matching<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Heartbeat index time updates were not prefixed with \\"Last indexed\\"<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the debugger would not properly instantiate thereby preventing additions to the log file<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Heartbeat API-powered timestamp of last index was missing \\"Last Indexed\\" phrasing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where in some circumstances content blocks parsed from PDFs would not be properly separated, resulted in the last word of one section being lumped together with the first word of the next section<\\/li>\\n<li><strong>[Fix]<\\/strong> Prevent over-preparation of terms when performing AND logic refinement<\\/li>\\n<li><strong>[Fix]<\\/strong> Check for indexer being disabled when issuing delta updates<\\/li>\\n<\\/ul>\\n<p>2.1.3<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better encoding and font support for PDF content extraction<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced memory footprint when not indexing PDFs<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where searchwp_settings_cap was not properly applied<\\/li>\\n<li><strong>[Fix]<\\/strong> Reduced aggressiveness when tokenizing PDF content<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed thrown exception when parsing specific PDF encodings<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a PHP 5.2 issue<\\/li>\\n<li><strong>[Fix]<\\/strong> Corrected an include path for ElementXRef.php<\\/li>\\n<\\/ul>\\n<p>2.1<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Significant query performance improvement in AND logic pass<\\/li>\\n<li><strong>[Improvement]<\\/strong> Much improved PDF content extraction when using only PHP as opposed to Xpdf Integration (requires PHP5.3+ else SearchWP will fall back to previous method)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_settings_cap allows you to customize the capability required to manage SearchWP\'s settings in the WordPress admin<\\/li>\\n<li><strong>[New]<\\/strong> You can now bulk-reintroduce posts that failed indexing<\\/li>\\n<\\/ul>\\n<p>2.0.4<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New regex whitelist pattern to support ampersand-joined terms (e.g. M&amp;M)<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where toggling whether the indexer was enabled\\/disabled would sometimes conflict if not done on the SearchWP settings screen<\\/li>\\n<li><strong>[Improvement]<\\/strong> Fixed an issue where umlaut\'s were incorrectly removed from PDF content when extracted using internal (PHP-based) method<\\/li>\\n<li><strong>[Improvement]<\\/strong> Theme conflict detection now takes into account single line comments (does not cover all commented use cases)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved term processing when using built in sanitization prior to searches<\\/li>\\n<\\/ul>\\n<p>2.0.3<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_get_custom_fields allowing developers to pre-fetch (and set) post metadata just before indexing takes place (props Stefan Hans Schonert)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_term_in allowing you to modify each term (per term) used in the main search algorithm<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of filtered terms, allowing extensions more control over the actual search query<\\/li>\\n<li><strong>[Improvement]<\\/strong> searchwp_indexer_loopback_args is now applied to every HTTP call SearchWP makes<\\/li>\\n<\\/ul>\\n<p>2.0.2<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_statistics_cap allows you to filter which capability is required to view and interact with stats<\\/li>\\n<li><strong>[Improvement]<\\/strong> Ignored queries in search statistics are now stored per user, not globally<\\/li>\\n<\\/ul>\\n<p>2.0.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue introduced in 2.0 that prevented the uninstallation routine from properly executing when not using multisite<\\/li>\\n<li><strong>[Improvement]<\\/strong> Resolved an issue in certain hosting environments that may have prevented the indexer from running<\\/li>\\n<\\/ul>\\n<p>2.0<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Shortcode processing: SearchWP can now process your Shortcodes in a number of ways<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_do_shortcode allows you to conditionally tell SearchWP to process all Shortcodes<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_set_post allows you to modify each post object prior to indexing, allowing for conditional processing of Shortcodes and more<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_nuke_on_delete to trigger Nuke on Delete (<em>overrides setting!<\\/em>)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_exclusive_regex_matches to force the indexer to prevent indexing exploded regex matches<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_omit_meta_key_{custom_field_key} allowing for per-key conditional exclusion of post meta when indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refined regex whitelist pattern for matching hyphen-separated-strings<\\/li>\\n<li><strong>[Improvement]<\\/strong> The indexer no longer strips regex matches but instead retains them to better facilitate partial matches<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better language for action\\/conflict notices<\\/li>\\n<li><strong>[Improvement]<\\/strong> You can now restore dismissed action\\/conflict notices in case you want to view them again<\\/li>\\n<li><strong>[Improvement]<\\/strong> Slight update to the settings UI (better active tab contrast, lessened border radii)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better exposure of Statistics feature<\\/li>\\n<li><strong>[Improvement]<\\/strong> Uninstallation routine now better respects multisite environment<\\/li>\\n<li><strong>[Improvement]<\\/strong> You can now exclude by terms that have not been used yet<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better default exclusion of internal metadata when indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where regex whitelist matches were not extracted from supplemental search queries during sanitization<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that might result in duplication of terms that are integers in the index<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a potential issue (during updates) where Supplemental search engine labels would inadvertently have their first letter converted to an \'A\'<\\/li>\\n<li><strong>[Fix]<\\/strong> Redundant preparation of search terms when checking for exclusions by weight of -1<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup<\\/li>\\n<\\/ul>\\n<p>1.9.11<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Added a regex whitelist pattern for hyphen-separated strings often used for serial numbers<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced the overhead of term extraction when processing the regex whitelist which might cause long posts with many regex matches to stall the indexer<\\/li>\\n<\\/ul>\\n<p>1.9.10<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a regression in version 1.9.8 that prevented the installation of new plugins from .org<\\/li>\\n<\\/ul>\\n<p>1.9.9<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where extended term-chunking of long posts may not have completed properly<\\/li>\\n<\\/ul>\\n<p>1.9.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the changelog would not be visible when clicking \'view version details\' links<\\/li>\\n<li><strong>[Change]<\\/strong> Automatic load monitoring is again enabled by default<\\/li>\\n<li><strong>[Improvement]<\\/strong> The notice that outputs an indication of posts that failed to index now respects purposefully excluded post IDs via searchwp_prevent_indexing filter<\\/li>\\n<\\/ul>\\n<p>1.9.7<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_index_comments allows you to prevent comments from being indexed<\\/li>\\n<li><strong>[Improvement]<\\/strong> Prevented potential edge case where the indexer may stall after completing a delta update<\\/li>\\n<li><strong>[Improvement]<\\/strong> More aggressive implementation of term regex whitelist (matches are now indexed fully in tact and not broken apart)<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where problematic posts that failed to index were not properly called out in the WordPress admin<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where \'Any\' Custom Field may not have applied correctly<\\/li>\\n<\\/ul>\\n<p>1.9.5<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where searchwp_in_admin may not properly hijack search results in the WordPress admin as desired<\\/li>\\n<li><strong>[Improvement]<\\/strong> Only return results from the post type being viewed when searchwp_in_admin is enabled and performing a search<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additional optimization and segmentation of settings where appropriate to prevent potential collision<\\/li>\\n<li><strong>[Improvement]<\\/strong> Use the Heartbeat API to dynamically update the Last Indexed time when on post edit screens<\\/li>\\n<\\/ul>\\n<p>1.9.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a CSS rendering issue in Firefox on the Search Stats page<\\/li>\\n<li><strong>[Improvement]<\\/strong> Hardened settings getting and setting mechanism<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_show_conflict_notices allows you to force-hide any conflict warnings generated by SearchWP<\\/li>\\n<\\/ul>\\n<p>1.9.2<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Added a number of actions to allow developers to react to various phases of indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where setting -1 posts per page was incorrectly utilized when performing searches<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that prevented SearchWPSearch instantiation when AJAX calls were made<\\/li>\\n<li><strong>[Improvement]<\\/strong> Modified default term whitelist rules to be more targeted<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced the number of notifications displayed upon activation<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced the number of queries necessary to store\\/retrieve various settings<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better data storage so as to work alongside various object caching plugins without stalling the indexer<\\/li>\\n<\\/ul>\\n<p>1.9<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> You can now ignore queries from Search Stats (to help avoid spam getting in the way)<\\/li>\\n<li><strong>[New]<\\/strong> Term Whitelisting: you can now define regex patterns and in doing so better retain specially formatted terms (e.g. dates, phone numbers, function names) in the index that otherwise would have been stripped of punctuation<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_query_orderby allows open-ended customization of the ORDER BY clause of the main search query<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_force_run allows developers the ability to force SearchWP to run no matter what<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_leinant_accents allowing for \'lazy\' quotes (e.g. searches without quotes will find terms with quotes)<\\/li>\\n<li><strong>[Improvement]<\\/strong> PHP Error cleanup<\\/li>\\n<li><strong>[Improvement]<\\/strong> Revisited index table indices, they\'re now better optimized which should result in noticeable performance improvements<\\/li>\\n<li><strong>[Improvement]<\\/strong> Load monitoring has been removed as it proved to be holding back the indexer resulting in delayed index times<\\/li>\\n<li><strong>[Improvement]<\\/strong> Attachment indexing has been disabled by default to save the (significant) overhead, but it will enable itself if any of your search engine settings incorporate Media<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refined the number of posts indexed per indexer passed, as always this can be filtered<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced the information overload present in the debug log, allowing for easier scanning for issues<\\/li>\\n<li><strong>[Improvement]<\\/strong> Offloaded AJAX handlers to minimize footprint and impact on the indexer<\\/li>\\n<li><strong>[Improvement]<\\/strong> Fixed overflow issues on the Search Stats page<\\/li>\\n<li><strong>[Improvement]<\\/strong> Informational notice linking directly to more information on Filters having everything to do with indexer configuration<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better detection of parallel indexer processes running that could have resulted in duplicate indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Indexer pause\\/unpause has been re-named enable\\/disable to reduce confusion<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where update notifications wouldn\'t show up in the Network Administration on Multisite<\\/li>\\n<\\/ul>\\n<p>1.8.4<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of serialized objects which resulted in <em>_PHP<\\/em>Incomplete_Class errors<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better enforcement of maximum term length when indexing as defined by the database schema<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of Deadlock cases when indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved default common\\/stop words<\\/li>\\n<\\/ul>\\n<p>1.8.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Cleanup of PHP Warnings<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_outside_main_query allowing for specific overrides when performing native searches<\\/li>\\n<li><strong>[Improvement]<\\/strong> Updated translation files (accurate translations will be rewarded, please contact info@searchwp.com)<\\/li>\\n<\\/ul>\\n<p>1.8.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where update notifications would not persist properly<\\/li>\\n<\\/ul>\\n<p>1.8.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where, in certain cases, weight attribution (or a lack thereof) would cause searches to fail<\\/li>\\n<\\/ul>\\n<p>1.8<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> You can now include a LIKE modifier (%) in Custom Field keys (essentially supporting ACF Repeater field (and similar plugins) data storage)<\\/li>\\n<li><strong>[New]<\\/strong> SearchWP will now attempt to detect potential conflicts and add notices in the WordPress admin when it finds potential problems<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where custom keyword stemmers would only be used during indexing, not searching<\\/li>\\n<li><strong>[Improvement]<\\/strong> The Custom Fields dropdown on the settings page is no longer limited to the 25 most-used meta keys<\\/li>\\n<li><strong>[Improvement]<\\/strong> The Custom Fields dropdown now uses select2 to make it easier to quickly select your desired meta key<\\/li>\\n<li><strong>[Improvement]<\\/strong> Various improvements to the main settings screen styles<\\/li>\\n<li><strong>[Improvement]<\\/strong> Fixed an issue where Custom Field meta keys would be over-sanitized when saved in the SearchWP options<\\/li>\\n<li><strong>[Improvement]<\\/strong> Update checks are performed less aggressively, reducing some cases of increased latency in the WordPress admin<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better singleton instantiation, fixing an issue with localization and certain hook utilization<\\/li>\\n<li><strong>[Improvement]<\\/strong> Scheduled events are now properly removed upon plugin deactivation<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduction in query overhead when multiple Custom Field meta keys have the same weight<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduction in query overhead when multiple taxonomies have the same weight<\\/li>\\n<li><strong>[Improvement]<\\/strong> Refactored the main query algorithm so as to improve maintainability and stability over time<\\/li>\\n<li><strong>[Improvement]<\\/strong> Formatting improvements, code quality improvements<\\/li>\\n<li><strong>[Improvement]<\\/strong> Updated translation files (accurate translations will be rewarded, please contact info@searchwp.com)<\\/li>\\n<\\/ul>\\n<p>1.7.2<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New Extension: Term Highlight - highlight search terms when outputting results!<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_found_post_objects allowing for the customization of Post objects returned by searches<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where overriding SearchWP File Content would be overwritten when the post got reindexed<\\/li>\\n<li><strong>[Fix]<\\/strong> Hotfix for a potential update issue, if you do not see an update notification in your dashboard, please download from your Account<\\/li>\\n<\\/ul>\\n<p>1.7<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> There is a new Advanced option called Nuke on Delete that adjusts the uninstallation routine to only remove data if you opt in<\\/li>\\n<li><strong>[Improvement]<\\/strong> AND logic queries now force their own index<\\/li>\\n<li><strong>[Improvement]<\\/strong> Removed unused constant<\\/li>\\n<li><strong>[Improvement]<\\/strong> Offloaded update checks to only occur in the admin and therefore reduce overhead on the front end<\\/li>\\n<li><strong>[Improvement]<\\/strong> Update checks are now performed once a day so as to reduce page load latency when working in the WordPress admin<\\/li>\\n<li><strong>[Improvement]<\\/strong> Changed the way license checks were performed to avoid potential unwanted caching issues<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed invalid textdomain usage for l18n<\\/li>\\n<\\/ul>\\n<p>1.6.10<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where keyword weights between 0 and 1 were converted to integers<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_post_statuses allowing for the customization of which post statuses are considered when indexing and searching<\\/li>\\n<\\/ul>\\n<p>1.6.9<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have generated a SQL error after late term sanitization when performing searches<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that caused taxonomies to be omitted in searches by default upon activation<\\/li>\\n<\\/ul>\\n<p>1.6.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a regression introduced in 1.6.7 that prevented the \'last indexed\' statistic from being properly maintained<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_extra_metadata allowing you to force additional content into the index per post<\\/li>\\n<\\/ul>\\n<p>1.6.7<\\/p>\\n<ul>\\n<li><strong>[Change]<\\/strong> Background indexing process has been updated to better accommodate maintenance mode plugins<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that may have prevented result exclusion given weight of -1 in some cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced the overhead of the logs table (note: search stats will be reset to accommodate this)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Miscellaneous code reorganization and optimization<\\/li>\\n<\\/ul>\\n<p>1.6.6<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New Advanced option to reset Search Stats<\\/li>\\n<\\/ul>\\n<p>1.6.5<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better appropriate suppression of WP_Query filters in internal calls<\\/li>\\n<li><strong>[Improvement]<\\/strong> Admin Bar entry better labels whether the indexer is paused<\\/li>\\n<\\/ul>\\n<p>1.6.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Admin bar entries now only show up when browsing the WordPress admin and the current user can update_options<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where overwriting the stored PDF content may not have properly taken place<\\/li>\\n<li><strong>[Improvement]<\\/strong> Initial AND logic pass now assumes keyword stem to create a better initial results pool<\\/li>\\n<li><strong>[Improvement]<\\/strong> When debugging is enabled, an HTML comment block is output at the bottom of pages to indicate what took place during that pageload<\\/li>\\n<li><strong>[Improvement]<\\/strong> Asset URLs in the admin now better respect alternative placement (props Jason C.)<\\/li>\\n<\\/ul>\\n<p>1.6.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where AND logic was wrongly applied to single term searches if you set searchwp_and_logic_only to be true<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where searchwp_posts_per_page was not properly applied to WordPress native searches<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_big_selects for cases where SearchWP breaches your MySQL-defined max_join_size<\\/li>\\n<\\/ul>\\n<p>1.6.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a PHP 5.2 compatibility error (T<em>PAAMAYIM<\\/em>NEKUDOTAYIM)<\\/li>\\n<\\/ul>\\n<p>1.6.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an error on plugin deletion via WP admin<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where (if you opt to disable automatic delta updates) the queue could be overwritten in some cases<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where (in certain circumstances) searches for values only in Custom Field data may yield no results<\\/li>\\n<\\/ul>\\n<p>1.6<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Added indexer pause toggle to Admin Bar<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_custom_fields allowing you parse custom fields, telling SearchWP what content you want to be indexed<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_custom_field_{$customFieldName} performs the same filtration, but for a single Custom Field<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_excluded_custom_fields allowing you to customize which meta_keys are automatically excluded during indexing<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_background_deltas allowing you to disable automatic delta index updates (you would then need to set up your own via WP-Cron or otherwise, useful for high traffic sites)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_weight_threshold allowing you to specify a minimum weight for search results to be considered (default is zero)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_indexed_post_types allowing you to specify which post types are indexed (note: this controls only what post types are indexed, it has no effect on enabling\\/disabling post types on the SearchWP Settings screen)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_return_orderby_random allowing search results to be returned at random<\\/li>\\n<li><strong>[Improvement]<\\/strong> Indexer optimizations in a number of places, index builds should be even faster (and more considerate of server resources)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Auto-throttling now takes into account your max<em>execution<\\/em>time so as to not exceed it<\\/li>\\n<li><strong>[Improvement]<\\/strong> Indexer now scales how many terms are processed per pass based on your memory_limit (can still be overridden)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of potential table deadlock when indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Overall reduction in memory usage when indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an off-by-one issue when filtering terms by minimum character length when parsing search terms<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the progress meter would automatically dismiss itself after purging the index<\\/li>\\n<\\/ul>\\n<p>1.5.5<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better performance on a number of queries throughout<\\/li>\\n<li><strong>[Improvement]<\\/strong> SearchWP will now monitor load averages (on Linux machines) and auto-throttle when loads get too high<\\/li>\\n<li><strong>[Change]<\\/strong> The default indexer pass timeout (throttle) is now 1 second<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Media may not be indexed on upload<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where terms in file names may be counted twice when indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Many more logging messages included, logs now include internal process identification<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with non-blocking requests and their associated timeouts potentially stalling the indexing process<\\/li>\\n<\\/ul>\\n<p>1.5<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Admin Bar entry (currently displays the last time the current post was indexed)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_admin_bar to allow you to disable the Admin Bar entry if you so choose<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_indexer_throttle allows you to tell the indexer to pause a number of seconds in between passes<\\/li>\\n<li><strong>[Fix]<\\/strong> PHP Warning cleanup<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where keyword stems were not fully utilized in AND logic passes<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where attachments may not be properly reindexed after an edit<\\/li>\\n<li><strong>[Fix]<\\/strong> Better index cleanup of deleted Media<\\/li>\\n<li><strong>[Improvement]<\\/strong> SearchWP\'s indexer will now automatically pause\\/unpause when running WordPress Importer<\\/li>\\n<\\/ul>\\n<p>1.4.9<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a regression that removed the searchwp_and_logic_only filter<\\/li>\\n<\\/ul>\\n<p>1.4.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the default comment weight was not properly set on install<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of additional reduction of AND pool results<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_return_orderby_date to allow developers to return results ordered by date instead of weight<\\/li>\\n<\\/ul>\\n<p>1.4.7<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the minimum word length was not taken into consideration when sanitizing terms<\\/li>\\n<\\/ul>\\n<p>1.4.6<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> More precise refactor of AND logic to prevent potential false positives<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_and_fields allows you to limit which field types apply to AND logic (i.e. limit to Title)<\\/li>\\n<\\/ul>\\n<p>1.4.5<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed potential PHP Warnings<\\/li>\\n<li><strong>[New]<\\/strong> You can now use weights of -1 to forcefully <em>exclude<\\/em> matches<\\/li>\\n<li><strong>[New]<\\/strong> By default SearchWP will now ignore WordPress core postmeta (e.g. _edit_lock)<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_omit_wp_metadata to include WordPress core postmeta in the index<\\/li>\\n<\\/ul>\\n<p>1.4.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Better coverage of deferred index delta updates<\\/li>\\n<\\/ul>\\n<p>1.4.3<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of refinement of AND logic in more cases<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of forced AND logic when it returns zero results<\\/li>\\n<\\/ul>\\n<p>1.4.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a potential issue where the search algorithm refinement may be too aggressive<\\/li>\\n<li><strong>[New]<\\/strong> New Filter: searchwp_custom_stemmer to allow for custom (usually localized) stemming. <em>Requires a re-index if utilized<\\/em><\\/li>\\n<\\/ul>\\n<p>1.4.1<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter: searchwp_and_logic_only to allow you to explicity force SearchWP to use AND logic only<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_refine_and_results tells SearchWP to further restrict AND results to titles<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_max_and_results to allow you to tell SearchWP when you want it to refine AND results<\\/li>\\n<\\/ul>\\n<p>1.4<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Added a new Advanced setting to allow you to pause the indexer without deactivating SearchWP<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_include_comment_author allows you to enable indexing of comment author<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_include_comment_email allows you to enable indexing of comment author email<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_auto_reindex to allow you to disable automatic reindexing of edited posts<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_indexer_paused to allow you to override the Advanced setting programmatically<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where comments were not accurately indexed<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improved stability of results when multiple posts have the same final weight by supplementally sorting by post_date DESC<\\/li>\\n<\\/ul>\\n<p>1.3.6<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter: searchwp_short_circuit to allow you to have SearchWP <em>not<\\/em> run at runtime. Useful when implementing other plugins that utilize search.<\\/li>\\n<\\/ul>\\n<p>1.3.5<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Implemented workaround for issues experienced with Post Types Order that prevented search results from appearing<\\/li>\\n<\\/ul>\\n<p>1.3.4.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed a bug with weight attribution that resulted from the update in 1.3.4<\\/li>\\n<\\/ul>\\n<p>1.3.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where taxonomy\\/custom field weight may not have been appropriate attributed when applicable<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where \'Any\' custom field weight may not have been appropriately applied<\\/li>\\n<li><strong>[Improvement]<\\/strong> Remote debugging info now updates more consistently<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additional method for remote debugging<\\/li>\\n<\\/ul>\\n<p>1.3.3<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Initial implementation of Remote Debugging (found in Advanced settings)<\\/li>\\n<li><strong>[New]<\\/strong> Extension: Xpdf Integration<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_external_pdf_processing to allow you to use your own PDF processing mechanism<\\/li>\\n<li><strong>[Improvement]<\\/strong> Less strict AND logic used in the main query<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better database environment check (needed as a result of <a href=\\"http:\\/\\/bugs.mysql.com\\/bug.php?id=41156\\">MySQL bug 41156<\\/a>)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additional cleanup of SearchWP options during uninstallation<\\/li>\\n<li><strong>[Improvement]<\\/strong> Force license deactivation during uninstallation<\\/li>\\n<\\/ul>\\n<p>1.3.2<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> SearchWP now defaults to AND logic with search terms, huge performance boost as a result (note: if no posts are found via AND, OR will be used)<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_and_logic to revert back to OR logic<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with the new deferred index updates<\\/li>\\n<\\/ul>\\n<p>1.3.1<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Added ability to \'wake up\' the indexer if you feel it has stalled<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Custom Field weights would not be properly retrieved if there were capital letters in the key<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with cron scheduling and management<\\/li>\\n<li><strong>[Improvement]<\\/strong> Delta index updates are now performed in the background<\\/li>\\n<li><strong>[Improvement]<\\/strong> Reduced latency between indexer passes<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better tracking of repeated passes on lengthy index entries<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better accommodation of potential indexer pass overlapping and in doing so reduce the liklihood of database table deadlocking<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better notifications regarding license activation<\\/li>\\n<li><strong>[Improvement]<\\/strong> More useful debugger logging<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better index progress display after purging the index<\\/li>\\n<\\/ul>\\n<p>1.3<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> New filter: searchwp_search_query_order to allow changing the search query order results at runtime<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_max_index_attempts to allow control over how many times the indexer should try to index a post<\\/li>\\n<li><strong>[New]<\\/strong> New filter: searchwp_prevent_indexing to allow exclusion of post IDs from the index process entirely<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better low-level interception of WordPress query process so as to accommodate other plugin workflows<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better realtime monitoring of indexer progress<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better detection and handling of troublesome posts when indexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of \'initial index complete\' notification after purging and reindexing<\\/li>\\n<li><strong>[Improvement]<\\/strong> Cleaned up purging and uninstallation routines<\\/li>\\n<\\/ul>\\n<p>1.2.5<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Search statistics are no longer reset along with purging the index<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better options cleanup both during index purges and uninstallations<\\/li>\\n<li><strong>[Improvement]<\\/strong> Improvement in overall indexer performance, not by a large margin, but some<\\/li>\\n<\\/ul>\\n<p>1.2.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the database environment check was too aggressive and prevented activation before the environment was set up<\\/li>\\n<\\/ul>\\n<p>1.2.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where numeric Custom Field data was not indexed accurately<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better detection for custom database table creation<\\/li>\\n<\\/ul>\\n<p>1.2.2<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better accommodation for regression in 1.2.0 that prevented proper taxonomy exclusion<\\/li>\\n<\\/ul>\\n<p>1.2.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where index progress indicator could exceed 100% after disabling attachment indexing<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where category exclusion would not always apply to search engine settings<\\/li>\\n<\\/ul>\\n<p>1.2.0<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Overall reduction in query time when performing searches (sometimes down to 50%!)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Indexing process now handles huge posts in a more efficient way, avoiding PHP timeouts<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of term indexing resulting in a more accurate index<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where term IDs were not pulled properly during indexing<\\/li>\\n<li><strong>[Change]<\\/strong> Changed the default weight for Titles so as to better meet user expectations<\\/li>\\n<\\/ul>\\n<p>1.1.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the WordPress database prefix was hardcoded in certain situations<\\/li>\\n<li><strong>[Improvement]<\\/strong> Removed redundant SQL call resulting in faster search queries<\\/li>\\n<\\/ul>\\n<p>1.1.1<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> More parameters passed to just about every SearchWP hook, please view the documentation for details<\\/li>\\n<\\/ul>\\n<p>1.1<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> A more formal integration of Extensions such that settings screens can be added<\\/li>\\n<li><strong>[New]<\\/strong> You can now limit Media search results by their type (e.g. search only Documents)<\\/li>\\n<li><strong>[New]<\\/strong> Extension: Term Synonyms - manually define term synonyms<\\/li>\\n<li><strong>[New]<\\/strong> Extension: WPML Integration<\\/li>\\n<li><strong>[New]<\\/strong> Extension: Polylang Integration<\\/li>\\n<li><strong>[New]<\\/strong> Extension: bbPress Integration<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_include that accepts an array of limiting post IDs during searches<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_query_main_join to allow custom joining during the main search query<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_query_join to allow custom joining in per-post-type subqueries when searching<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_query_conditions to allow custom conditions in per-post-type subqueries when searching<\\/li>\\n<li><strong>[New]<\\/strong> New filter searchwp_index_attachments to allow you to disable indexing of Attachments entirely to save index time<\\/li>\\n<li><strong>[Improvement]<\\/strong> Major reduction in query time if you choose to NOT include Media in search results (or limit Media to Documents)<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better edge case coverage to the indexing process; it\'s now less likely to stall arbitrarily<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better delta index updates by skipping autosaves and revisions more aggressively<\\/li>\\n<li><strong>[Improvement]<\\/strong> Fixed a UI issue where the CPT column on the settings screen may expand beyond the right hand column<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better default weights<\\/li>\\n<\\/ul>\\n<p>1.0.10<\\/p>\\n<ul>\\n<li><strong>[New]<\\/strong> Added filter searchwp_common_words<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_enable_parent_attribution_{posttype}<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_enable_attribution_{posttype}<\\/li>\\n<\\/ul>\\n<p>1.0.9<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better cleaning and processing of taxonomy terms<\\/li>\\n<li><strong>[Improvement]<\\/strong> Additional parameter when invoking SearchWPSearch for 3rd party integrations (props Matt Gibbs)<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with Firefox not liking SVG files<\\/li>\\n<\\/ul>\\n<p>1.0.8<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where duplicate terms could get returned when sanitizing<\\/li>\\n<li><strong>[New]<\\/strong> Extension: Fuzzy Searching<\\/li>\\n<li><strong>[New]<\\/strong> Extension: Term Archive Priority<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_results to faciliate filtration of results before they\'re returned<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_query_limit_start to allow offsetting the main query results<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_query_limit_total to allow offsetting the main query results<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_pre_search_terms to allow filtering search terms before searches run<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_load_posts so as to prevent weighty loading of all post data when all you want is IDs (props Matt Gibbs)<\\/li>\\n<li><strong>[Improvement]<\\/strong> More arguments passed to searchwp<em>before<\\/em>query<em>index and searchwp<\\/em>after<em>query<\\/em>index actions<\\/li>\\n<\\/ul>\\n<p>1.0.7<\\/p>\\n<ul>\\n<li><strong>[NOTICE]<\\/strong> Due to an indexer update, it is recommended that you purge your index after updating<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better, more performant indexer behavior during updates<\\/li>\\n<li><strong>[Improvement]<\\/strong> Added logging for supplemental searches<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better punctuation handling during indexing and searching<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better cleanup of stored options when applicable<\\/li>\\n<li><strong>[Fix]<\\/strong> Better logging of original search queries compared to what actually gets sent through the algorithm<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed potential PHP warning<\\/li>\\n<\\/ul>\\n<p>1.0.6<\\/p>\\n<ul>\\n<li><strong>[Improvement]<\\/strong> Better handling of source code-related indexing and searching<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_engine_settings_{$engine} to allow adjustment of weights at runtime<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_max_search_terms to cap the number of search terms that can be searched for (default 6)<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_max_search_terms_supplemental to cap the number of terms for supplemental searches<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_max_search_terms_supplemental_{$engine} to cap the number of terms for supplemental searches by engine<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with empty search queries showing up in search stats<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with CSS alignment of search stats<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where the indexer would index and then re-index posts when not needed<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed a MySQL error when logging indexer actions<\\/li>\\n<\\/ul>\\n<p>1.0.5<\\/p>\\n<ul>\\n<li><strong>[Change]<\\/strong> Updated user-agent of indexer background process for easier debugging<\\/li>\\n<li><strong>[New]<\\/strong> Added initial support for common debugging assistance via searchwp_log action<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better support for WordPress installations in subdirectories<\\/li>\\n<li><strong>[Improvement]<\\/strong> If the initial index is already built by the time you go from activation to settings screen, a notice is displayed<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better support for generating your own pagination with supplemental searches http:\\/\\/d.pr\\/MXgp<\\/li>\\n<li><strong>[Fix]<\\/strong> Stopped \'empty\' search queries from being logged<\\/li>\\n<li><strong>[New]<\\/strong> Added filter searchwp_index_chunk_size to adjust how many posts are indexed at a clip<\\/li>\\n<\\/ul>\\n<p>1.0.4<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Much better handling of all UTF-8 characters both when indexing and when searching<\\/li>\\n<\\/ul>\\n<p>1.0.3<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue with the auto-update script not resolving properly<\\/li>\\n<li><strong>[Improvement]<\\/strong> Better handling of special characters both when indexing and querying<\\/li>\\n<\\/ul>\\n<p>1.0.2<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue where Custom Field weights weren\'t saving properly on the Settings screen<\\/li>\\n<\\/ul>\\n<p>1.0.1<\\/p>\\n<ul>\\n<li><strong>[Fix]<\\/strong> Fixed an issue that would cause searches to fail if an enabled custom post type had a hyphen in it\'s name<\\/li>\\n<li><strong>[Fix]<\\/strong> Fixed an off-by-one issue in generating statistical figures<\\/li>\\n<\\/ul>\\n<p>1.0.0<\\/p>\\n<ul>\\n<li>Initial release<\\/li>\\n<\\/ul>\\n"]}";}', 'no') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(977, 'cptui_new_install', 'false', 'yes'),
(978, 'cptui_post_types', 'a:2:{s:7:"lawfirm";a:28:{s:4:"name";s:7:"lawfirm";s:5:"label";s:8:"Lawfirms";s:14:"singular_label";s:7:"Lawfirm";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:12:"show_in_rest";s:5:"false";s:9:"rest_base";s:0:"";s:11:"has_archive";s:4:"true";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:4:"true";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:13:"custom-fields";}s:10:"taxonomies";a:0:{}s:6:"labels";a:23:{s:9:"menu_name";s:8:"Lawfirms";s:9:"all_items";s:12:"All Lawfirms";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:10:"view_items";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:17:"parent_item_colon";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:10:"attributes";s:0:"";}s:15:"custom_supports";s:0:"";}s:4:"test";a:28:{s:4:"name";s:4:"test";s:5:"label";s:4:"test";s:14:"singular_label";s:4:"test";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:12:"show_in_rest";s:5:"false";s:9:"rest_base";s:0:"";s:11:"has_archive";s:4:"true";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";}s:10:"taxonomies";a:0:{}s:6:"labels";a:23:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:9:"view_item";s:0:"";s:10:"view_items";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:17:"parent_item_colon";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:10:"attributes";s:0:"";}s:15:"custom_supports";s:0:"";}}', 'yes'),
(981, 'searchwp_doing_delta', '', 'no'),
(1059, 'searchwp_transient', '1526841275.0074980258941650390625', 'no'),
(1083, 'swppurge_transient', '1526841265.9409189224243164062500', 'no'),
(1093, 'lawfirmcat_children', 'a:9:{i:31;a:5:{i:0;i:32;i:1;i:35;i:2;i:36;i:3;i:37;i:4;i:39;}i:33;a:2:{i:0;i:34;i:1;i:38;}i:61;a:1:{i:0;i:41;}i:32;a:1:{i:0;i:57;}i:38;a:1:{i:0;i:58;}i:35;a:1:{i:0;i:59;}i:41;a:1:{i:0;i:60;}i:40;a:2:{i:0;i:61;i:1;i:65;}i:65;a:1:{i:0;i:66;}}', 'yes'),
(1094, 'post_count', '3', 'yes'),
(1130, 'cptui_taxonomies', 'a:2:{s:17:"lawfirm_locations";a:21:{s:4:"name";s:17:"lawfirm_locations";s:5:"label";s:13:"Location Cats";s:14:"singular_label";s:12:"Location Cat";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:12:"hierarchical";s:4:"true";s:7:"show_ui";s:4:"true";s:12:"show_in_menu";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:20:"rewrite_hierarchical";s:1:"1";s:17:"show_admin_column";s:5:"false";s:12:"show_in_rest";s:4:"true";s:18:"show_in_quick_edit";s:4:"true";s:9:"rest_base";s:17:"lawfirm_locations";s:6:"labels";a:18:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:9:"edit_item";s:0:"";s:9:"view_item";s:0:"";s:11:"update_item";s:0:"";s:12:"add_new_item";s:0:"";s:13:"new_item_name";s:0:"";s:11:"parent_item";s:0:"";s:17:"parent_item_colon";s:0:"";s:12:"search_items";s:0:"";s:13:"popular_items";s:0:"";s:26:"separate_items_with_commas";s:0:"";s:19:"add_or_remove_items";s:0:"";s:21:"choose_from_most_used";s:0:"";s:9:"not_found";s:0:"";s:8:"no_terms";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";}s:12:"object_types";a:1:{i:0;s:7:"lawfirm";}}s:21:"lawfirm_practiceareas";a:21:{s:4:"name";s:21:"lawfirm_practiceareas";s:5:"label";s:18:"Practice Area Cats";s:14:"singular_label";s:17:"Practice Area Cat";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:12:"hierarchical";s:5:"false";s:7:"show_ui";s:4:"true";s:12:"show_in_menu";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:20:"rewrite_hierarchical";s:1:"0";s:17:"show_admin_column";s:5:"false";s:12:"show_in_rest";s:4:"true";s:18:"show_in_quick_edit";s:0:"";s:9:"rest_base";s:0:"";s:6:"labels";a:18:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:9:"edit_item";s:0:"";s:9:"view_item";s:0:"";s:11:"update_item";s:0:"";s:12:"add_new_item";s:0:"";s:13:"new_item_name";s:0:"";s:11:"parent_item";s:0:"";s:17:"parent_item_colon";s:0:"";s:12:"search_items";s:0:"";s:13:"popular_items";s:0:"";s:26:"separate_items_with_commas";s:0:"";s:19:"add_or_remove_items";s:0:"";s:21:"choose_from_most_used";s:0:"";s:9:"not_found";s:0:"";s:8:"no_terms";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";}s:12:"object_types";a:1:{i:0;s:7:"lawfirm";}}}', 'yes'),
(1274, 'wp_rest_api_controller_one_point_four', '1', 'yes'),
(1275, 'wp_rest_api_controller_post_types', 'a:5:{i:0;s:12:"oembed_cache";i:1;s:12:"user_request";i:2;s:15:"acf-field-group";i:3;s:9:"acf-field";i:4;s:7:"lawfirm";}', 'yes'),
(2019, 'cptp_version', '3.2.2', 'yes'),
(2022, 'add_post_type_for_tax', '', 'yes'),
(2032, 'cptp_permalink_checked', '3.2.2', 'yes'),
(2229, 'category_children', 'a:2:{i:62;a:1:{i:0;i:63;}i:63;a:1:{i:0;i:64;}}', 'yes'),
(2526, 'debug_objects', 'a:2:{s:3:"php";s:1:"1";s:5:"about";s:1:"1";}', 'yes'),
(2752, 'lawfirm_locations_children', 'a:4:{i:293;a:3:{i:0;i:294;i:1;i:301;i:2;i:314;}i:294;a:5:{i:0;i:295;i:1;i:303;i:2;i:311;i:3;i:312;i:4;i:313;}i:301;a:1:{i:0;i:302;}i:314;a:3:{i:0;i:315;i:1;i:318;i:2;i:319;}}', 'yes'),
(2794, 'wp-all-import-pro_85b8495febade7a221f67b0bca7d59d9', 'O:8:"stdClass":15:{s:11:"new_version";s:5:"4.5.4";s:14:"stable_version";s:5:"4.5.4";s:4:"name";s:13:"WP All Import";s:4:"slug";s:17:"wp-all-import-pro";s:3:"url";s:67:"http://www.wpallimport.com/downloads/wp-all-import-pro/?changelog=1";s:12:"last_updated";s:19:"2018-05-23 19:56:07";s:8:"homepage";s:55:"http://www.wpallimport.com/downloads/wp-all-import-pro/";s:7:"package";s:0:"";s:13:"download_link";s:0:"";s:8:"sections";a:2:{s:11:"description";s:129:"<p>Learn more about WP All Import at <a href="https://www.wpallimport.com/" target="_blank">https://www.wpallimport.com/</a></p>\n";s:9:"changelog";s:18769:"<p>4.5.4</p>\n<ul>\n<li>bug fix: import using stream reader</li>\n<li>bug fix: generation temporary files in system temporary folder</li>\n</ul>\n<p>4.5.3</p>\n<ul>\n<li>improvement: add support for Toolset Types</li>\n<li>bug fix: trigger deleted_user action when import deleting a user</li>\n<li>bug fix: add-ons api - searching for existing images in pmxi_images table</li>\n<li>bug fix: php error on array push alias</li>\n</ul>\n<p>4.5.2</p>\n<ul>\n<li>new feature: Automatic Scheduling - run imports on a schedule</li>\n<li>improvement: search for existing images based on remote image URL</li>\n<li>improvement: various backend improvements to image imports</li>\n<li>improvement: various import speed optimizations</li>\n<li>bug fix: remove deprecated function calls for PHP 7.2 compatibility</li>\n<li>bug fix: delete db tables when mu blog deleted</li>\n<li>bug fix: remove BOM from import templates</li>\n<li>bug fix: saving CSV delimiter when changing import file</li>\n</ul>\n<p>4.5.1</p>\n<ul>\n<li>improvement: import images from dropbox</li>\n<li>improvement: skips import process to the first specific record</li>\n<li>improvement: added new filter wp_all_import_is_render_whole_xml_tree</li>\n<li>improvement: added wp_all_import_images_uploads_dir filter into add-ons api</li>\n<li>bug fix: conflict with InfiniteWP</li>\n<li>bug fix: oddity update notification for Link cloaking add-on</li>\n<li>bug fix: load functions before pmxi_before_xml_import</li>\n<li>bug fix: do not re-count category terms when post imported as draft</li>\n<li>bug fix: import base64 encoded images in add-ons</li>\n<li>bug fix: woo order custom fields auto-detection</li>\n<li>security fix - XSS exploit (Special thanks to Mardan Muhidin for reporting)</li>\n<li>security fix - XSS exploit (Special thanks to Yuji Tounai for reporting)</li>\n</ul>\n<p>4.5.0</p>\n<ul>\n<li>improvement: Make the WooCo Short Description expandable</li>\n<li>improvement: show notice when function editor is not saved</li>\n<li>improvement: added timestamp to import log lines</li>\n<li>improvement: added support for bmp images</li>\n<li>improvement: added new action pmxi_before_post_import_{$addon}</li>\n<li>security fix: patch XSS exploit</li>\n<li>bug fix: import pages hierarchy</li>\n<li>bug fix: error in pclzip.lib.php with php 7.1</li>\n<li>bug fix: import taxonomies hierarchy</li>\n<li>bug fix: json to xml convertation</li>\n<li>bug fix: import password protected feeds with port defined</li>\n</ul>\n<p>4.4.9</p>\n<ul>\n<li>improvement: custom fields detection</li>\n<li>improvement: new action wp_all_import_post_skipped</li>\n<li>improvement: updated history page title</li>\n<li>improvement: optimize large imports deletion</li>\n<li>improvement: added import friendly name to confirm screen</li>\n<li>improvement: sql query optimization on manage imports screen</li>\n<li>improvement: added wp_all_import_shard_delay filter</li>\n<li>improvement: added wp_all_import_images_uploads_dir filter</li>\n<li>bug fix: compatibility with WPML</li>\n<li>bug fix: generation image filename</li>\n<li>bug fix: wp_all_import_specified_records filter</li>\n</ul>\n<p>4.4.8</p>\n<ul>\n<li>improvement: added hungarian translation</li>\n<li>bug fix: csv headers generation</li>\n<li>bug fix: import template from Import Settings works again</li>\n<li>bug fix: users no longer logged out when user is update via import</li>\n<li>bug fix: images with encoded quotes</li>\n</ul>\n<p>4.4.7</p>\n<ul>\n<li>bug fix: cron job completed early for imports with xpath</li>\n<li>bug fix: csv headers with non latin characters</li>\n</ul>\n<p>4.4.6</p>\n<ul>\n<li>bug fix: cron job un-triggered on timeout error</li>\n</ul>\n<p>4.4.5</p>\n<ul>\n<li>bug fix: import xls from dropbox</li>\n<li>bug fix: template preview</li>\n</ul>\n<p>4.4.4</p>\n<ul>\n<li>improvement: new filter \'wp_all_import_phpexcel_delimiter\'</li>\n<li>improvement: new filter \'wp_all_import_is_trim_parsed_data\'</li>\n<li>improvement: added new \'filter wp_all_import_skip_x_csv_rows\'</li>\n<li>improvement: added csv delimiter setting to import options screen</li>\n<li>bug fix: taxonomies dropdown list</li>\n<li>bug fix: cron job was never untriggered when calling to undefined function</li>\n<li>bug fix: taxonomies preview</li>\n<li>bug fix: import duplicate tags</li>\n<li>bug fix: importing taxonomy terms that already exist in a different taxonomies</li>\n</ul>\n<p>4.4.3</p>\n<ul>\n<li>bug fix: parsing images for newly added records</li>\n<li>bug fix: the event calendar conflict</li>\n</ul>\n<p>4.4.2</p>\n<ul>\n<li>improvement: added new filter wp_all_import_phpexcel_object to modify excel data before import</li>\n<li>bug fix: search for images ending with underscores in media</li>\n<li>bug fix: import hierarchical posts and pages</li>\n<li>bug fix: import custom post type page templates</li>\n<li>bug fix: matching taxonomies by name</li>\n<li>bug fix: custom fields validation</li>\n</ul>\n<p>4.4.1</p>\n<ul>\n<li>improvement: compatibility with PHP 7.x</li>\n<li>improvement: search for existing attachments option</li>\n<li>improvement: new filter for file path of functions.php file</li>\n<li>bug fix: images preview</li>\n<li>bug fix: improved matching for images similar to image.com.png</li>\n</ul>\n<p>4.4.0</p>\n<ul>\n<li>new feature: added import taxonomies feature</li>\n<li>bug fix: hierarchy taxonomies preview</li>\n<li>bug fix: empty logs folder generation</li>\n<li>bug fix: \'Keep images currently in Media Library\' option for add-ons</li>\n<li>bug fix: import bundles with gz files</li>\n<li>bug fix: custom functions for attachments</li>\n</ul>\n<p>4.3.2</p>\n<ul>\n<li>improvement: \'Force Stream Reader\' setting</li>\n<li>improvement: tar + gz compression support for remote feeds</li>\n<li>improvement: new filter \'wp_all_import_auto_create_csv_headers\'</li>\n<li>improvement: new filter \'wp_all_import_is_base64_images_allowed\'</li>\n<li>improvement: new filter \'wp_all_import_set_post_terms\' to leave a specific category alone when a post is being updated</li>\n<li>bug fix: cron import timeout when set missing outofstock option is enabled</li>\n<li>bug fix: nodes navigation for xpath like /news/item</li>\n<li>bug fix: frozen import template screen for cyrillic XML feeds</li>\n<li>bug fix: conflict between taxonomies & user import</li>\n<li>bug fix: creating users with the same email</li>\n<li>bug fix: enable keep line breaks option by default</li>\n<li>bug fix: composer namespace conflict</li>\n<li>bug fix: images preview when wp is in subdirectory</li>\n<li>bug fix: \'Instead of deletion, set Custom Field\' option for users import</li>\n</ul>\n<p>4.3.1</p>\n<ul>\n<li>fixed issue with libxml 2.9.3</li>\n<li>execute \'pmxi_article_data\' filter for all posts ( new & existing )</li>\n</ul>\n<p>4.3.0</p>\n<ul>\n<li>added de_CH translation</li>\n<li>added support for .svg images</li>\n<li>added possibility for import excerpts for pages</li>\n<li>added new filter \'wp_all_import_specified_records\'</li>\n<li>added new filter \'wp_all_import_is_post_to_delete\'</li>\n<li>fixed saving function editor</li>\n<li>fixed custom fields mapping rules with \'0\' value</li>\n<li>fixed termination of the import if the "Delete source XML file after importing" is checked</li>\n<li>disable XMLReader stream filter for HHVM</li>\n<li>improve search for existing images in media gallery</li>\n</ul>\n<p>4.2.9</p>\n<ul>\n<li>fixed error messages on step 4</li>\n<li>fixed renaming image files</li>\n<li>fixed delete missing records option</li>\n<li>fixed csv to xml convertation in case when there are some equal titles in csv file</li>\n<li>stop using $HTTP_RAW_POST_DATA for PHP 7.x compatibility</li>\n<li>added new action \'pmxi_missing_post\'</li>\n</ul>\n<p>4.2.8</p>\n<ul>\n<li>update required database tables</li>\n</ul>\n<p>4.2.7</p>\n<ul>\n<li>fixed detecting root nodes with colons in names</li>\n<li>fixed php notice "Undefined variable: existing_meta_keys"</li>\n<li>fixed rendering special chars in function editor</li>\n<li>fixed css for WordPress 4.4</li>\n<li>added feature to delete only posts not import</li>\n<li>added feature to download template/bundle from import settings</li>\n<li>added new option for importing images "Use images currently in Media Library"</li>\n<li>remove periods to hyphens convertation in image name</li>\n<li>auto detect dropbox URLs and change to dl=1</li>\n<li>changed comma delimiting behavior/UI in image meta</li>\n</ul>\n<p>4.2.6</p>\n<ul>\n<li>fixed preview prices</li>\n<li>fixed counting XML nodes</li>\n</ul>\n<p>4.2.5</p>\n<ul>\n<li>fixed \'Delete source XML file after importing\' option</li>\n<li>fixed ‘Instead of deletion, change post status to Draft’ option</li>\n<li>fixed reading XML files with NS in element names</li>\n<li>added ‘WooCommerce Order’ to post type list on step 1</li>\n</ul>\n<p>4.2.4</p>\n<ul>\n<li>fixed duplicate matching by custom field</li>\n<li>fixed error messages on step1 in case when server throws fatal error e.q. time limit exception</li>\n<li>fixed option "Delete posts that are no longer present in your file", now it works with empty CSV files which has only one header row</li>\n<li>fixed importing custom fields with the same name</li>\n<li>fixed custom functions in images preview</li>\n<li>added es_ES translation</li>\n<li>added de_DE translation</li>\n<li>added iterative ajax delete process ( deleting associated posts )</li>\n</ul>\n<p>4.2.3</p>\n<ul>\n<li>Fixed removing uploaded XML source file on re-run process</li>\n</ul>\n<p>4.2.2</p>\n<ul>\n<li>Fixed saving function editor</li>\n</ul>\n<p>4.2.1</p>\n<ul>\n<li>fixed duplicate matching by custom field ( cron )</li>\n<li>fixed converting image filenames to lowercase</li>\n<li>fixed import html to image description</li>\n<li>fixed import _wp_old_slug</li>\n<li>added Post ID to manual record matching</li>\n<li>added \'Comment status\' to \'Choose data to update\' section</li>\n<li>added \'cancel\' to cron API /wp-cron.php?import_key=Kt&amp;import_id=407&amp;action=cancel</li>\n<li>added function editor</li>\n</ul>\n<p>4.2.0</p>\n<ul>\n<li>fixed parsing CSV with empty lines</li>\n<li>fixed parsing multiple IF statements</li>\n<li>fixed preview in case when ‘Disable the visual editor when writing’ is enabled</li>\n<li>fixed conflict with WooCommerce - Store Exporter Deluxe</li>\n<li>added possibility to start synchronized cron requests &amp;sync=1</li>\n<li>added notifications for required addons</li>\n<li>added support for wp all export bundle</li>\n<li>added support for manual import bundle</li>\n<li>added feature \'click to download import file\'</li>\n<li>added validation for excerpt and images sections</li>\n<li>added auto-detect a broken Unique ID notification</li>\n<li>added import template notifications</li>\n<li>removed support for importing WooCommerce Orders</li>\n<li>changed absolute paths to relative in db</li>\n<li>updated cron response messages</li>\n<li>moved uploaded files to \'Use existing\' dropdown</li>\n</ul>\n<p>4.1.7</p>\n<ul>\n<li>added support for Excel files ( .xls, .xlsx )</li>\n<li>added new option \'Do not remove images from media gallery\' on import<br />\nsettings screen</li>\n<li>added new options to taxonomies import \'Try to match terms to<br />\nexisting child Product Categories\' &amp; \'Only assign Products to the<br />\nimported Product Category, not the entire hierarchy\'</li>\n<li>fixed excessive update requests</li>\n<li>added options to \'Delete associated posts</li>\n</ul>\n<p>4.1.6</p>\n<ul>\n<li>load ini_set only on plugins pages</li>\n<li>fixed saving import template</li>\n<li>added import post format via XPath</li>\n</ul>\n<p>4.1.5</p>\n<ul>\n<li>fixed import page template</li>\n<li>added a second argument to pmxi_saved_post action ( SimpleXML object ) of current record</li>\n</ul>\n<p>4.1.4</p>\n<ul>\n<li>fixed Apply mapping rules before splitting via separator symbol for manual hierarchy</li>\n<li>fixed path equal or less than</li>\n<li>fixed changing unique key when moving back from confirm screen</li>\n<li>fixed override page template</li>\n<li>fixed unlink images on deleting missing posts</li>\n<li>updated wp_all_import_is_post_to_update filter with second argument XML node as array</li>\n<li>updated compatibility with WP All Export</li>\n<li>added filter wp_all_import_feed_type</li>\n<li>added possibility to use php to calculate URL on first step [add_to_url("https://google.com/")]</li>\n</ul>\n<p>4.1.3</p>\n<ul>\n<li>fixed un triggering issue on cron jobs for empty files</li>\n<li>changed updater priority from 10 to 20</li>\n<li>added post parent option for all hierarchical CPT</li>\n</ul>\n<p>4.1.2</p>\n<ul>\n<li>Important security fixes - additional hardening, prevention of blind SQL injection and reflected XSS attacks</li>\n</ul>\n<p>4.1.1</p>\n<ul>\n<li>critical security fix - stopping non-logged in users from accessing adminInit https://www.wpallimport.com/2015/02/wp-import-4-1-1-mandatory-security-update/</li>\n<li>added new filter wp_all_import_is_post_to_update to skip needed posts add_filter(\'wp_all_import_is_post_to_update\', \'is_post_to_update\', 10, 1);</li>\n<li>added new option Search for existing attachments to prevent duplicates in media library</li>\n<li>fixed imports pagination</li>\n<li>fixed preview taxonomies</li>\n<li>fixed upload folder creation when \'upload_dir\' filter defined</li>\n<li>fixed db schema for wpmu when new site added</li>\n</ul>\n<p>4.1.0</p>\n<ul>\n<li>fixed cron execution when titles are not defined</li>\n<li>added an option to separate hierarchy groups via symbol</li>\n<li>added separator symbol for manually nested taxonomies</li>\n</ul>\n<p>4.0.9</p>\n<ul>\n<li>added license key setting for automatic update</li>\n<li>added option search images through attachments</li>\n<li>added option assign term to the bottom level term in the hierarchy</li>\n</ul>\n<p>4.0.8</p>\n<ul>\n<li>fixed taxonomies preview</li>\n<li>fixed import meta description for images</li>\n<li>added feature to assign posts to needed terms</li>\n<li>added new option for taxonomies Apply mapping rules before splitting via separator symbol</li>\n<li>added set with XPath option for comment status, ping status, page parent, page template</li>\n</ul>\n<p>4.0.7</p>\n<ul>\n<li>fixed feed detection for rss chanels</li>\n<li>fixed parsing json data</li>\n<li>fixed add only new images option</li>\n<li>fixed delete missing records option</li>\n<li>added ability to import custom fields with the same name</li>\n<li>added port setting</li>\n</ul>\n<p>4.0.6</p>\n<ul>\n<li>fixed encoding for taxonomies mapping</li>\n<li>optimization for delete missing records option</li>\n<li>fixed feed type auto-detection</li>\n<li>fixed changes that related to _wp_page_template meta data</li>\n</ul>\n<p>4.0.5</p>\n<ul>\n<li>fixed template parsing when php function arguments contains an array()</li>\n<li>fixed error msg when feed is html page e.g. page 404</li>\n<li>fixed xpath building</li>\n<li>update hierarchy taxonomies options</li>\n</ul>\n<p>4.0.4</p>\n<ul>\n<li>changed main file name to wp-all-import-pro.php</li>\n<li>fixed feed type auto-detection</li>\n<li>fixed bug with empty unique keys</li>\n</ul>\n<p>4.0.3</p>\n<ul>\n<li>fixed re-count record when a file has been changed at an import setting screen</li>\n<li>fixed database schema auto-update</li>\n<li>fixed uploading large files</li>\n<li>fixed auto-detecting root element</li>\n<li>fixed log storage in database</li>\n<li>fixed cron execution when "do not create new records" option is enabled</li>\n<li>fixed feed type detection</li>\n<li>fixed unlink attachment source when posts updated/deleted</li>\n<li>fixed specialchars in taxnomies/categories mapping</li>\n<li>updated taxonomies hierarchy settings</li>\n<li>added a limit 10 to the existing meta values</li>\n</ul>\n<p>4.0.2</p>\n<ul>\n<li>speed up the import of taxonomies/categories</li>\n<li>added taxonomies/categories mapping feature</li>\n<li>added custom fields auto-detection feature</li>\n<li>added custom fields mapping feature</li>\n<li>added images/taxonomies preview feature</li>\n<li>added unofficial support for more file formats - json &amp; sql</li>\n<li>added new setting (secure mode) to protect your files</li>\n<li>better import logs</li>\n<li>updated design</li>\n</ul>\n<p>3.4.2</p>\n<ul>\n<li>fixed navigation bug</li>\n<li>fixed search duplicates</li>\n<li>fixed duplicate categories</li>\n<li>fixed path builder for element attributes</li>\n<li>fixed cron processing for already uploaded files (XML)</li>\n<li>added taxonomies for pages</li>\n</ul>\n<p>3.4.1</p>\n<ul>\n<li>fixed pmxi_delete_post action: this action was executed after posts were deleted</li>\n<li>fixed import menu order &amp; post parent for pages</li>\n<li>fixed import log for continue import feature</li>\n<li>added is update author option</li>\n<li>fixed post formats</li>\n<li>fixed cron processing: WP_Error object was not initialized</li>\n<li>fixed cron processing for import where XPath filtering is defined</li>\n<li>fixed UTC dates on manage imports page</li>\n</ul>\n<p>3.4.0</p>\n<ul>\n<li>fixed: import empty content</li>\n<li>fixed: log files</li>\n<li>fixed: detect image extension</li>\n<li>fixed: terms hierarchy on cron job execution</li>\n</ul>\n<p>3.3.9</p>\n<ul>\n<li>added: feature to do not escape shortcodes</li>\n<li>fixed: pre-processing logic</li>\n<li>fixed: downloading images with unicode url</li>\n<li>fixed: clear non ASCII/invalid symbols in CSV files</li>\n<li>fixed: import option \'Instead of using original image file name, set file name(s)\'</li>\n</ul>\n<p>3.3.8</p>\n<ul>\n<li>fixed: admin notices</li>\n<li>fixed: creation duplicates draft post via cron</li>\n<li>fixed: images with encoded symbols</li>\n<li>fixed: upload file via URL</li>\n<li>fixed: php notices</li>\n<li>added: compatibility with WP 3.9</li>\n</ul>\n<p>3.3.7</p>\n<ul>\n<li>updated convertation CSV to XML with XMLWriter</li>\n<li>fixed import *.zip files</li>\n<li>fixed xpath helper on step 2</li>\n<li>fixed showing zeros in XML tree</li>\n<li>allow post content to be empty on step 3</li>\n<li>added autodetect session mode</li>\n<li>delete deprecated settings my csv contain html code and case sensitivity</li>\n<li>fixed deleting history files</li>\n<li>fixed autodetect image extensions</li>\n<li>fixed increasing SQL query length</li>\n<li>added error messages</li>\n<li>fixed "High Speed Small File Processing" option</li>\n</ul>\n<p>3.3.6</p>\n<ul>\n<li>fixed: multiple cron execution</li>\n<li>fixed: load options template</li>\n<li>fixed: session initialization</li>\n<li>fixed: import search</li>\n<li>fixed: attachment author on cron execution</li>\n<li>fixed: download images option</li>\n<li>added: errors messages to the log</li>\n<li>added: "not contains" filter to step 2</li>\n<li>added: compatibility with categories mapping addon</li>\n<li>updated: cpt navigation on step 4</li>\n</ul>\n<p>3.3.5</p>\n<ul>\n<li>fixed bug with cron processing</li>\n<li>fixed bug with saving wrong image name</li>\n<li>added serialized custom fields feature</li>\n<li>added compatibility with user import add-on</li>\n<li>added compatibility with 3rd party developers</li>\n<li>added new setting \'Cron processing time limit\'</li>\n</ul>\n";}s:7:"banners";a:2:{s:4:"high";s:55:"http://ps.w.org/wp-all-import/assets/banner-772x250.png";s:3:"low";s:0:"";}s:8:"requires";s:5:"3.6.1";s:6:"tested";s:5:"4.9.6";s:6:"author";s:6:"Soflyy";s:12:"contributors";O:8:"stdClass":2:{s:6:"soflyy";s:38:"https://profiles.wordpress.org/soflyy/";s:11:"wpallimport";s:43:"https://profiles.wordpress.org/wpallimport/";}}', 'no'),
(2795, 'wp-all-import-pro_timeout_85b8495febade7a221f67b0bca7d59d9', '1531436798', 'yes'),
(2800, 'hookturn_acftcp_license_key', 'e7571ba1ffc7949980302747424143a1', 'yes'),
(2805, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TXpZd01EaDhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMExUQTNMVEk0SURJd09qVXlPak0zIjtzOjM6InVybCI7czoyODoiaHR0cDovL2xhd3llcnMtZGlyZWN0b3J5LmNvbSI7fQ==', 'yes'),
(2806, '63a7ef4ac01620f4c0bfd0435ea66b0e', 'a:2:{s:7:"timeout";i:1531444496;s:5:"value";s:7456:"{"new_version":"2.3.0","stable_version":"2.3.0","name":"ACF Theme Code Pro","slug":"acf_theme_code_pro","url":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/?changelog=1","last_updated":"2018-02-12 17:47:26","homepage":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/","package":"https:\\/\\/hookturn.io\\/edd-sl\\/package_download\\/MTUzMTU1NjA5NDplNzU3MWJhMWZmYzc5NDk5ODAzMDI3NDc0MjQxNDNhMToxNTo3ZGZmMTg2MmE3ZWFhMTM3NGY0YTY3MzkzNDA0MmJhYjpodHRwQC8vbGF3eWVycy1kaXJlY3RvcnkuY29tOjA=","download_link":"https:\\/\\/hookturn.io\\/edd-sl\\/package_download\\/MTUzMTU1NjA5NDplNzU3MWJhMWZmYzc5NDk5ODAzMDI3NDc0MjQxNDNhMToxNTo3ZGZmMTg2MmE3ZWFhMTM3NGY0YTY3MzkzNDA0MmJhYjpodHRwQC8vbGF3eWVycy1kaXJlY3RvcnkuY29tOjA=","sections":{"description":"<p>Save time &amp; automatically generate the code required to implement Advanced Custom Fields in your themes!<br \\/>\\nACF Theme Code Pro is a premium add-on\\u00a0for the awesome\\u00a0<a href=\\"https:\\/\\/www.advancedcustomfields.com\\/pro\\/\\" target=\\"_blank\\" rel=\\"nofollow noopener noreferrer\\">Advanced Custom Fields Pro<\\/a>\\u00a0WordPress plugin.<\\/p>\\n<p>[ecquote]<\\/p>\\n<p>Whenever you publish, edit or update an ACF Field Group, the code required to implement your unique custom fields is conveniently displayed in a <strong>Theme Code<\\/strong> section right below the Field Group settings.<\\/p>\\n<p>Features<\\/p>\\n<ul>\\n<li>Clipboard icons to easily copy code blocks into your theme<\\/li>\\n<li>Field names and variables are automatically updated<\\/li>\\n<li>Code generated is based on the official ACF documentation<\\/li>\\n<li>Great for offline ACF documentation<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for the premium ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Flexible content field<\\/li>\\n<li>Repeater field<\\/li>\\n<li>Gallery field<\\/li>\\n<li>Clone field<\\/li>\\n<li>Group field<\\/li>\\n<li>Link field<\\/li>\\n<li>Range field<\\/li>\\n<li>Button field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for these 3rd Party fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Font Awesome field<\\/li>\\n<li>Google font selector field<\\/li>\\n<li>Image crop field<\\/li>\\n<li>Markdown field<\\/li>\\n<li>Nav Menu field<\\/li>\\n<li>RGBA Colour field<\\/li>\\n<li>Sidebar Selector field<\\/li>\\n<li>Smart Button field<\\/li>\\n<li>Table field<\\/li>\\n<li>TablePress field<\\/li>\\n<li>Address Field<\\/li>\\n<li>Number Slider Field<\\/li>\\n<li>Post Type Select Field<\\/li>\\n<li>Code Field<\\/li>\\n<li>Link Field<\\/li>\\n<li>Link Picker Field<\\/li>\\n<li>YouTube Picker Field<\\/li>\\n<li>Range Field<\\/li>\\n<li>Focal Point Field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates the code for all standard ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Text<\\/li>\\n<li>Text Area<\\/li>\\n<li>Number<\\/li>\\n<li>Email<\\/li>\\n<li>Password<\\/li>\\n<li>WYSIWYG<\\/li>\\n<li>File<\\/li>\\n<li>Image<\\/li>\\n<li>Select<\\/li>\\n<li>Checkbox<\\/li>\\n<li>Radio<\\/li>\\n<li>True \\/ False<\\/li>\\n<li>User<\\/li>\\n<li>Google Map<\\/li>\\n<li>Date Picker<\\/li>\\n<li>Date Time Picker<\\/li>\\n<li>Time Picker<\\/li>\\n<li>Color Picker<\\/li>\\n<li>Page Link<\\/li>\\n<li>Post Object<\\/li>\\n<li>Relationship<\\/li>\\n<li>Taxonomy<\\/li>\\n<li>oEmbed<\\/li>\\n<\\/ul>\\n<p>New in Version 2 : Location Rule Support<\\/p>\\n<p>ACF Theme Code Pro can generate code for multiple location rules on each field group, you\\u2019re using ACF Pro this includes locations\\u00a0like <strong>Options<\\/strong>, <strong>Users<\\/strong>, <strong>Widgets<\\/strong>, <strong>Comments<\\/strong>, <strong>Terms<\\/strong> and <strong>Attachments.<\\/strong><br \\/>\\nWorks best with:<\\/p>\\n<ul>\\n<li>Advanced Custom Fields\\u00a0Pro v5.6.8 or higher<\\/li>\\n<li>Advanced Custom Fields (Free) v4.4 or v5.0<\\/li>\\n<li>WordPress 4.9.4 or higher<\\/li>\\n<\\/ul>\\n<p>Current Pro Version<\\/p>\\n<ul>\\n<li>Version 2.3.0\\u00a0released in February 2018<\\/li>\\n<\\/ul>\\n<p>If you\'d like to \'try before you buy\' you can\\u00a0<a href=\\"https:\\/\\/wordpress.org\\/plugins\\/acf-theme-code\\/\\" target=\\"_blank\\" rel=\\"noopener noreferrer\\">check out our free version<\\/a> on WordPress.org. Our free version has basic support for the free version of Advanced Custom Fields.<br \\/>\\nThe ACF Theme Code Plugin was created by:<br \\/>\\nAaron &amp; Ben, two WordPress developers based in Melbourne, Australia.<\\/p>\\n<p>[plugin_authors_block]<\\/p>\\n","changelog":"<p>2.3.0<\\/p>\\n<ul>\\n<li>New Field Supported: ACF Ninja Forms add on<\\/li>\\n<li>New Field Supported: ACF Gravity Forms add on<\\/li>\\n<li>New Field Supported: ACF RGBA Colour picker<\\/li>\\n<li>New Field(s) Supported: ACF qTranslate<\\/li>\\n<li>Core: Resolved EDD Conflicts<\\/li>\\n<li>Core: Improved Widget Location Variables<\\/li>\\n<li>Fix: EDD naming conflict<\\/li>\\n<li>Fix: Location error if visual editor is disabled<\\/li>\\n<li>Fix: Select Conflict with Seamless Field Group Option<\\/li>\\n<\\/ul>\\n<p>2.2.0<\\/p>\\n<ul>\\n<li>New Field Supported: Button Field found in ACF Pro v5.6.3<\\/li>\\n<li>New Field Supported: Range Field found in ACF Pro v5.6.2<\\/li>\\n<li>Core: Copy All Feature Added<\\/li>\\n<\\/ul>\\n<p>2.1.0<\\/p>\\n<ul>\\n<li>New Field Supported: Group Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Link Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Range Field (Third Party)<\\/li>\\n<li>New Field Supported: Focal Point Field (Third Party)<\\/li>\\n<li>Field: Code field improved to escape output by default<\\/li>\\n<li>Field: Google Map field improved to return lat, lng &amp;\\u00a0address<\\/li>\\n<li>Core: resolved an issue with legacy PHP versions<\\/li>\\n<li>Fix: Bug in File field PHP when returned as a URL<\\/li>\\n<\\/ul>\\n<p>2.0.0<\\/p>\\n<ul>\\n<li>Core : Theme Code Pro now generates code based on your location rules!<\\/li>\\n<li>Core : Theme Code Pro now supports all official ACF Add ons!<\\/li>\\n<li>Core : Theme Code Pro now works when ACF Pro is included in a theme!<\\/li>\\n<li>Location Supported : Options Page<\\/li>\\n<li>Location Supported : Widget<\\/li>\\n<li>Location Supported : Comment<\\/li>\\n<li>Location Supported : Taxonomy Term<\\/li>\\n<li>Location Supported : User<\\/li>\\n<li>Location Supported : Attachment<\\/li>\\n<li>Add-on supported : Options Page<\\/li>\\n<li>Add on supported : Repeater Field<\\/li>\\n<li>Add on supported : Gallery Field<\\/li>\\n<li>Add on supported : Flexible Content Field<\\/li>\\n<li>Fix : Minor bug in file field example link markup<\\/li>\\n<li>Fix : Support for Quicklinks feature within locations<\\/li>\\n<\\/ul>\\n<p>1.2.0<\\/p>\\n<ul>\\n<li>Field : Clone - major improvements to the clone field code output<\\/li>\\n<li>New Field Supported : Address Field<\\/li>\\n<li>New Field Supported : Number Slider Field<\\/li>\\n<li>New Field Supported : Post Type Select Field<\\/li>\\n<li>New Field Supported : Code Field<\\/li>\\n<li>New Field Supported : Link Field<\\/li>\\n<li>New Field Supported : Link Picker Field<\\/li>\\n<li>New Field Supported : YouTube Picker Field<\\/li>\\n<li>Core : Special characters now removed from variable names<\\/li>\\n<li>Fix : Compatibility with CPTUI Pro Plugin<\\/li>\\n<\\/ul>\\n<p>1.1.0<\\/p>\\n<ul>\\n<li>Core: Quicklinks feature with anchor links to the relevant theme code block<\\/li>\\n<li>Core: Notice updates &amp; various bug fixes<\\/li>\\n<li>Core: Plugin options screen moved under Settings<\\/li>\\n<\\/ul>\\n<p>1.0.3<\\/p>\\n<ul>\\n<li>Fix: Use the_sub_field method for nested File fields with return format URL<\\/li>\\n<\\/ul>\\n<p>1.0.2<\\/p>\\n<ul>\\n<li>Field: Fix for Post Object when using ACF 4<\\/li>\\n<li>Core: Various internal code improvements<\\/li>\\n<\\/ul>\\n"},"banners":{"high":"","low":""}}";}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_pmxi_files`
#

DROP TABLE IF EXISTS `wp_pmxi_files`;


#
# Table structure of table `wp_pmxi_files`
#

CREATE TABLE `wp_pmxi_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `import_id` bigint(20) unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci,
  `path` text COLLATE utf8mb4_unicode_520_ci,
  `registered_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_pmxi_files`
#
INSERT INTO `wp_pmxi_files` ( `id`, `import_id`, `name`, `path`, `registered_on`) VALUES
(43, 6, 'Lawyers_V2_Sheet1_20_.csv', '/wpallimport/uploads/283faeaad5fa01b72870dcaf68c405dd/Lawyers_V2_Sheet1_20_.xml', '2018-05-28 23:51:21') ;

#
# End of data contents of table `wp_pmxi_files`
# --------------------------------------------------------



#
# Delete any existing table `wp_pmxi_history`
#

DROP TABLE IF EXISTS `wp_pmxi_history`;


#
# Table structure of table `wp_pmxi_history`
#

CREATE TABLE `wp_pmxi_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `import_id` bigint(20) unsigned NOT NULL,
  `type` enum('manual','processing','trigger','continue','') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `time_run` text COLLATE utf8mb4_unicode_520_ci,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `summary` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_pmxi_history`
#
INSERT INTO `wp_pmxi_history` ( `id`, `import_id`, `type`, `time_run`, `date`, `summary`) VALUES
(27, 6, 'manual', '3', '2018-05-28 04:48:18', '0 Lawfirms created 9 updated 0 deleted 0 skipped'),
(28, 6, 'manual', '3', '2018-05-28 04:51:41', '0 Lawfirms created 9 updated 0 deleted 0 skipped'),
(29, 6, 'manual', '3', '2018-05-28 16:27:48', '0 Lawfirms created 9 updated 0 deleted 0 skipped'),
(30, 6, 'manual', '3', '2018-05-28 16:29:00', '0 Lawfirms created 9 updated 0 deleted 0 skipped'),
(31, 6, 'manual', '3', '2018-05-28 23:51:21', '0 Lawfirms created 9 updated 0 deleted 0 skipped') ;

#
# End of data contents of table `wp_pmxi_history`
# --------------------------------------------------------



#
# Delete any existing table `wp_pmxi_images`
#

DROP TABLE IF EXISTS `wp_pmxi_images`;


#
# Table structure of table `wp_pmxi_images`
#

CREATE TABLE `wp_pmxi_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attachment_id` bigint(20) unsigned NOT NULL,
  `image_url` varchar(600) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `image_filename` varchar(600) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_pmxi_images`
#

#
# End of data contents of table `wp_pmxi_images`
# --------------------------------------------------------



#
# Delete any existing table `wp_pmxi_imports`
#

DROP TABLE IF EXISTS `wp_pmxi_imports`;


#
# Table structure of table `wp_pmxi_imports`
#

CREATE TABLE `wp_pmxi_imports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_import_id` bigint(20) NOT NULL DEFAULT '0',
  `name` text COLLATE utf8mb4_unicode_520_ci,
  `friendly_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `type` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `feed_type` enum('xml','csv','zip','gz','') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `path` text COLLATE utf8mb4_unicode_520_ci,
  `xpath` text COLLATE utf8mb4_unicode_520_ci,
  `options` longtext COLLATE utf8mb4_unicode_520_ci,
  `registered_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `root_element` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `processing` tinyint(1) NOT NULL DEFAULT '0',
  `executing` tinyint(1) NOT NULL DEFAULT '0',
  `triggered` tinyint(1) NOT NULL DEFAULT '0',
  `queue_chunk_number` bigint(20) NOT NULL DEFAULT '0',
  `first_import` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `count` bigint(20) NOT NULL DEFAULT '0',
  `imported` bigint(20) NOT NULL DEFAULT '0',
  `created` bigint(20) NOT NULL DEFAULT '0',
  `updated` bigint(20) NOT NULL DEFAULT '0',
  `skipped` bigint(20) NOT NULL DEFAULT '0',
  `deleted` bigint(20) NOT NULL DEFAULT '0',
  `canceled` tinyint(1) NOT NULL DEFAULT '0',
  `canceled_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed` tinyint(1) NOT NULL DEFAULT '0',
  `failed_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `settings_update_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_activity` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `iteration` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_pmxi_imports`
#
INSERT INTO `wp_pmxi_imports` ( `id`, `parent_import_id`, `name`, `friendly_name`, `type`, `feed_type`, `path`, `xpath`, `options`, `registered_on`, `root_element`, `processing`, `executing`, `triggered`, `queue_chunk_number`, `first_import`, `count`, `imported`, `created`, `updated`, `skipped`, `deleted`, `canceled`, `canceled_on`, `failed`, `failed_on`, `settings_update_on`, `last_activity`, `iteration`) VALUES
(6, 0, 'Lawyers_V2_Sheet1_20_.csv', '', 'upload', '', '/wpallimport/uploads/283faeaad5fa01b72870dcaf68c405dd/Lawyers_V2_Sheet1_20_.csv', '/node', 'a:186:{s:4:"type";s:4:"post";s:21:"is_override_post_type";i:0;s:15:"post_type_xpath";s:0:"";s:8:"deligate";s:0:"";s:11:"wizard_type";s:3:"new";s:11:"custom_type";s:7:"lawfirm";s:14:"featured_delim";s:1:",";s:10:"atch_delim";s:1:",";s:25:"is_search_existing_attach";s:1:"0";s:15:"post_taxonomies";a:1:{s:17:"lawfirm_locations";s:286:"[{"item_id":"1","left":2,"right":7,"parent_id":null,"xpath":"{parentlocationscat[1]}","assign":true},{"item_id":"2","left":3,"right":6,"parent_id":"1","xpath":"{lawfirmstate[1]}","assign":true},{"item_id":"3","left":4,"right":5,"parent_id":"2","xpath":"{lawfirmcity[1]}","assign":true}]";}s:6:"parent";s:1:"0";s:23:"is_multiple_page_parent";s:3:"yes";s:18:"single_page_parent";s:0:"";s:5:"order";s:1:"0";s:6:"status";s:7:"publish";s:13:"page_template";s:7:"default";s:25:"is_multiple_page_template";s:3:"yes";s:20:"single_page_template";s:0:"";s:15:"page_taxonomies";a:0:{}s:9:"date_type";s:8:"specific";s:4:"date";s:3:"now";s:10:"date_start";s:3:"now";s:8:"date_end";s:3:"now";s:11:"custom_name";a:0:{}s:12:"custom_value";a:0:{}s:13:"custom_format";a:2:{i:0;s:1:"0";i:1;s:1:"0";}s:14:"custom_mapping";a:0:{}s:17:"serialized_values";a:2:{i:0;s:7:"["",""]";i:1;s:7:"["",""]";}s:20:"custom_mapping_rules";a:2:{i:0;s:2:"[]";i:1;s:2:"[]";}s:14:"comment_status";s:6:"closed";s:20:"comment_status_xpath";s:0:"";s:11:"ping_status";s:4:"open";s:17:"ping_status_xpath";s:0:"";s:12:"create_draft";s:2:"no";s:6:"author";s:0:"";s:12:"post_excerpt";s:0:"";s:9:"post_slug";s:0:"";s:11:"attachments";s:0:"";s:19:"is_import_specified";s:1:"0";s:16:"import_specified";s:0:"";s:16:"is_delete_source";i:0;s:8:"is_cloak";i:0;s:10:"unique_key";s:12:"{lawfirm[1]}";s:14:"tmp_unique_key";s:12:"{lawfirm[1]}";s:9:"feed_type";s:4:"auto";s:22:"search_existing_images";s:1:"1";s:18:"create_new_records";s:1:"1";s:17:"is_delete_missing";s:1:"0";s:20:"set_missing_to_draft";s:1:"0";s:20:"is_update_missing_cf";s:1:"0";s:22:"update_missing_cf_name";s:0:"";s:23:"update_missing_cf_value";s:0:"";s:20:"is_keep_former_posts";s:2:"no";s:16:"is_update_status";s:1:"1";s:17:"is_update_content";s:1:"1";s:15:"is_update_title";s:1:"1";s:14:"is_update_slug";s:1:"1";s:17:"is_update_excerpt";s:1:"1";s:20:"is_update_categories";s:1:"1";s:16:"is_update_author";s:1:"1";s:24:"is_update_comment_status";s:1:"1";s:19:"is_update_post_type";s:1:"1";s:23:"update_categories_logic";s:11:"full_update";s:15:"taxonomies_list";s:1:"0";s:20:"taxonomies_only_list";s:0:"";s:22:"taxonomies_except_list";s:0:"";s:21:"is_update_attachments";s:1:"1";s:16:"is_update_images";s:1:"1";s:19:"update_images_logic";s:11:"full_update";s:15:"is_update_dates";s:1:"1";s:20:"is_update_menu_order";s:1:"1";s:16:"is_update_parent";s:1:"1";s:19:"is_keep_attachments";s:1:"0";s:12:"is_keep_imgs";s:1:"0";s:20:"do_not_remove_images";s:1:"1";s:23:"is_update_custom_fields";s:1:"1";s:26:"update_custom_fields_logic";s:11:"full_update";s:18:"custom_fields_list";s:1:"0";s:23:"custom_fields_only_list";s:0:"";s:25:"custom_fields_except_list";s:0:"";s:18:"duplicate_matching";s:4:"auto";s:19:"duplicate_indicator";s:5:"title";s:21:"custom_duplicate_name";s:0:"";s:22:"custom_duplicate_value";s:0:"";s:18:"is_update_previous";i:0;s:12:"is_scheduled";s:0:"";s:16:"scheduled_period";s:0:"";s:13:"friendly_name";s:0:"";s:19:"records_per_request";s:2:"20";s:24:"auto_records_per_request";i:0;s:18:"auto_rename_images";s:1:"0";s:25:"auto_rename_images_suffix";s:0:"";s:11:"images_name";s:8:"filename";s:11:"post_format";s:8:"standard";s:17:"post_format_xpath";s:0:"";s:8:"encoding";s:5:"UTF-8";s:9:"delimiter";s:1:",";s:16:"image_meta_title";s:0:"";s:22:"image_meta_title_delim";s:1:",";s:18:"image_meta_caption";s:0:"";s:24:"image_meta_caption_delim";s:1:",";s:14:"image_meta_alt";s:0:"";s:20:"image_meta_alt_delim";s:1:",";s:22:"image_meta_description";s:0:"";s:28:"image_meta_description_delim";s:1:",";s:34:"image_meta_description_delim_logic";s:8:"separate";s:12:"status_xpath";s:0:"";s:15:"download_images";s:3:"yes";s:17:"converted_options";s:1:"1";s:15:"update_all_data";s:3:"yes";s:12:"is_fast_mode";s:1:"0";s:9:"chuncking";s:1:"1";s:17:"import_processing";s:4:"ajax";s:26:"processing_iteration_logic";s:4:"auto";s:28:"records_per_request_detected";i:0;s:16:"save_template_as";s:1:"0";s:5:"title";s:12:"{lawfirm[1]}";s:7:"content";s:19:"{lawfirmaddress[1]}";s:4:"name";s:0:"";s:18:"is_keep_linebreaks";s:1:"1";s:13:"is_leave_html";s:1:"0";s:14:"fix_characters";i:0;s:9:"pid_xpath";s:0:"";s:10:"slug_xpath";s:0:"";s:11:"title_xpath";s:0:"";s:14:"featured_image";s:0:"";s:23:"download_featured_image";s:0:"";s:23:"download_featured_delim";s:1:",";s:22:"gallery_featured_image";s:0:"";s:22:"gallery_featured_delim";s:1:",";s:11:"is_featured";s:1:"1";s:17:"is_featured_xpath";s:0:"";s:20:"set_image_meta_title";s:1:"0";s:22:"set_image_meta_caption";s:1:"0";s:18:"set_image_meta_alt";s:1:"0";s:26:"set_image_meta_description";s:1:"0";s:18:"auto_set_extension";s:1:"0";s:13:"new_extension";s:0:"";s:9:"tax_logic";a:2:{s:17:"lawfirm_locations";s:12:"hierarchical";s:21:"lawfirm_practiceareas";s:8:"multiple";}s:10:"tax_assing";a:2:{s:17:"lawfirm_locations";s:1:"1";s:21:"lawfirm_practiceareas";s:1:"1";}s:11:"term_assing";a:2:{s:17:"lawfirm_locations";s:1:"1";s:21:"lawfirm_practiceareas";s:1:"1";}s:20:"multiple_term_assing";a:2:{s:17:"lawfirm_locations";s:1:"1";s:21:"lawfirm_practiceareas";s:1:"1";}s:23:"tax_hierarchical_assing";a:1:{s:17:"lawfirm_locations";a:2:{i:0;s:1:"1";s:6:"NUMBER";s:1:"1";}}s:34:"tax_hierarchical_last_level_assign";a:1:{s:17:"lawfirm_locations";s:1:"0";}s:16:"tax_single_xpath";a:2:{s:17:"lawfirm_locations";s:0:"";s:21:"lawfirm_practiceareas";s:0:"";}s:18:"tax_multiple_xpath";a:2:{s:17:"lawfirm_locations";s:0:"";s:21:"lawfirm_practiceareas";s:25:"{lawfirmpracticeareas[1]}";}s:22:"tax_hierarchical_xpath";a:1:{s:17:"lawfirm_locations";a:2:{i:0;s:0:"";i:1;s:0:"";}}s:18:"tax_multiple_delim";a:2:{s:17:"lawfirm_locations";s:1:",";s:21:"lawfirm_practiceareas";s:1:",";}s:22:"tax_hierarchical_delim";a:1:{s:17:"lawfirm_locations";s:1:">";}s:25:"tax_manualhierarchy_delim";a:1:{s:17:"lawfirm_locations";s:1:",";}s:29:"tax_hierarchical_logic_entire";a:1:{s:17:"lawfirm_locations";s:1:"0";}s:29:"tax_hierarchical_logic_manual";a:1:{s:17:"lawfirm_locations";s:1:"1";}s:18:"tax_enable_mapping";a:2:{s:17:"lawfirm_locations";s:1:"0";s:21:"lawfirm_practiceareas";s:1:"0";}s:25:"tax_is_full_search_single";a:2:{s:17:"lawfirm_locations";s:1:"0";s:21:"lawfirm_practiceareas";s:1:"0";}s:27:"tax_is_full_search_multiple";a:2:{s:17:"lawfirm_locations";s:1:"0";s:21:"lawfirm_practiceareas";s:1:"0";}s:29:"tax_assign_to_one_term_single";a:2:{s:17:"lawfirm_locations";s:1:"0";s:21:"lawfirm_practiceareas";s:1:"0";}s:31:"tax_assign_to_one_term_multiple";a:2:{s:17:"lawfirm_locations";s:1:"0";s:21:"lawfirm_practiceareas";s:1:"0";}s:11:"tax_mapping";a:2:{s:17:"lawfirm_locations";s:2:"[]";s:21:"lawfirm_practiceareas";s:2:"[]";}s:17:"tax_logic_mapping";a:2:{s:17:"lawfirm_locations";s:1:"0";s:21:"lawfirm_practiceareas";s:1:"0";}s:31:"is_tax_hierarchical_group_delim";a:1:{s:17:"lawfirm_locations";s:1:"0";}s:28:"tax_hierarchical_group_delim";a:1:{s:17:"lawfirm_locations";s:1:"|";}s:12:"nested_files";a:0:{}s:17:"xml_reader_engine";s:1:"0";s:13:"taxonomy_type";s:0:"";s:15:"taxonomy_parent";s:0:"";s:13:"taxonomy_slug";s:4:"auto";s:19:"taxonomy_slug_xpath";s:0:"";s:15:"import_img_tags";s:1:"1";s:28:"search_existing_images_logic";s:11:"by_filename";s:24:"enable_import_scheduling";s:5:"false";s:17:"scheduling_enable";s:1:"0";s:22:"scheduling_weekly_days";s:0:"";s:17:"scheduling_run_on";s:6:"weekly";s:22:"scheduling_monthly_day";s:0:"";s:16:"scheduling_times";a:1:{i:0;s:0:"";}s:19:"scheduling_timezone";s:19:"America/Los_Angeles";s:3:"acf";a:1:{i:4;s:1:"1";}s:6:"fields";a:4:{s:19:"field_5ac3d6fb2e3b5";a:5:{s:17:"is_ignore_empties";s:1:"0";s:11:"is_variable";s:3:"csv";s:7:"foreach";s:0:"";s:9:"separator";s:1:"|";s:4:"rows";a:2:{i:1;a:7:{s:19:"field_5af9d4521c2dd";s:20:"{avvoprofilelink[1]}";s:19:"field_5af9d4801c2de";s:24:"{attorneylicensedfor[1]}";s:19:"field_5af9d6151c2e1";s:18:"{attorneyphone[1]}";s:19:"field_5af9d7691c2e2";s:20:"{attorneyaddress[1]}";s:19:"field_5af9d83a1c2e4";s:0:"";s:19:"field_5af9d88d1c2e6";a:5:{s:17:"is_ignore_empties";s:1:"0";s:11:"is_variable";s:3:"csv";s:7:"foreach";s:0:"";s:9:"separator";s:1:"|";s:4:"rows";a:2:{i:1;a:3:{s:19:"field_5af9d8a61c2e7";s:23:"{attorneyschoolname[1]}";s:19:"field_5af9d8b11c2e8";s:24:"{attorneyschoolmajor[1]}";s:19:"field_5af9d8df1c2e9";s:26:"{attorneyyeargraduated[1]}";}s:9:"ROWNUMBER";a:3:{s:19:"field_5af9d8a61c2e7";s:0:"";s:19:"field_5af9d8b11c2e8";s:0:"";s:19:"field_5af9d8df1c2e9";s:0:"";}}}s:19:"field_5ac3d7052e3b6";s:18:"{attorneynames[1]}";}s:9:"ROWNUMBER";a:7:{s:19:"field_5af9d4521c2dd";s:0:"";s:19:"field_5af9d4801c2de";s:0:"";s:19:"field_5af9d6151c2e1";s:0:"";s:19:"field_5af9d7691c2e2";s:0:"";s:19:"field_5af9d83a1c2e4";s:0:"";s:19:"field_5af9d88d1c2e6";a:5:{s:11:"is_variable";s:2:"no";s:17:"is_ignore_empties";s:1:"0";s:7:"foreach";s:0:"";s:9:"separator";s:1:"|";s:4:"rows";a:1:{s:9:"ROWNUMBER";a:3:{s:19:"field_5af9d8a61c2e7";s:0:"";s:19:"field_5af9d8b11c2e8";s:0:"";s:19:"field_5af9d8df1c2e9";s:0:"";}}}s:19:"field_5ac3d7052e3b6";s:0:"";}}}s:19:"field_5b00bcdaf6b8c";s:17:"{lawfirmphone[1]}";s:19:"field_5b00bcf9f6b8d";s:19:"{lawfirmwebsite[1]}";s:19:"field_5b00bffad59f3";s:0:"";}s:23:"is_multiple_field_value";a:0:{}s:14:"multiple_value";a:0:{}s:16:"fields_delimiter";a:0:{}s:13:"is_update_acf";s:1:"1";s:16:"update_acf_logic";s:11:"full_update";s:8:"acf_list";s:1:"0";s:13:"acf_only_list";s:0:"";s:15:"acf_except_list";s:0:"";}', '2018-05-28 23:51:24', 'node', 0, 0, 0, 0, '2018-05-20 00:11:25', 9, 9, 0, 9, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '2018-05-28 23:51:15', '2018-05-28 23:51:23', 23) ;

#
# End of data contents of table `wp_pmxi_imports`
# --------------------------------------------------------



#
# Delete any existing table `wp_pmxi_posts`
#

DROP TABLE IF EXISTS `wp_pmxi_posts`;


#
# Table structure of table `wp_pmxi_posts`
#

CREATE TABLE `wp_pmxi_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `import_id` bigint(20) unsigned NOT NULL,
  `unique_key` text COLLATE utf8mb4_unicode_520_ci,
  `product_key` text COLLATE utf8mb4_unicode_520_ci,
  `iteration` bigint(20) NOT NULL DEFAULT '0',
  `specified` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `import_id` (`import_id`),
  KEY `post_id` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_pmxi_posts`
#
INSERT INTO `wp_pmxi_posts` ( `id`, `post_id`, `import_id`, `unique_key`, `product_key`, `iteration`, `specified`) VALUES
(37, 98, 6, 'Agreement Resources, LLC', '', 22, 0),
(38, 99, 6, 'Akin Gump Strauss Hauer & Feld LLP', '', 22, 0),
(39, 100, 6, 'Alan R Goodman', '', 22, 0),
(40, 101, 6, 'Alekman Ditusa, LLC', '', 22, 0),
(41, 102, 6, 'Allen Agnitti, Esquire', '', 22, 0),
(42, 103, 6, 'Allison, Angier, & Mchale LLP', '', 22, 0),
(43, 104, 6, 'Allyn & Ball, PC', '', 22, 0),
(44, 105, 6, 'American International College; Holyoke Com. Coll.', '', 22, 0),
(45, 106, 6, 'Browne George Ross LLP', '', 22, 0) ;

#
# End of data contents of table `wp_pmxi_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_pmxi_templates`
#

DROP TABLE IF EXISTS `wp_pmxi_templates`;


#
# Table structure of table `wp_pmxi_templates`
#

CREATE TABLE `wp_pmxi_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `options` longtext COLLATE utf8mb4_unicode_520_ci,
  `scheduled` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `title` text COLLATE utf8mb4_unicode_520_ci,
  `content` longtext COLLATE utf8mb4_unicode_520_ci,
  `is_keep_linebreaks` tinyint(1) NOT NULL DEFAULT '0',
  `is_leave_html` tinyint(1) NOT NULL DEFAULT '0',
  `fix_characters` tinyint(1) NOT NULL DEFAULT '0',
  `meta` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_pmxi_templates`
#

#
# End of data contents of table `wp_pmxi_templates`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=8103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 4, '_edit_last', '2'),
(3, 4, '_edit_lock', '1526842234:2'),
(28, 10, '_edit_last', '1'),
(29, 10, '_edit_lock', '1527042389:2'),
(3403, 61, '_edit_last', '2'),
(3404, 61, '_edit_lock', '1526786752:2'),
(4591, 87, '_edit_last', '2'),
(4592, 87, '_edit_lock', '1527032866:2'),
(4596, 89, '_edit_last', '2'),
(4597, 89, '_edit_lock', '1527111268:2'),
(4599, 90, '_edit_last', '2'),
(4600, 90, '_edit_lock', '1527448952:2'),
(5239, 90, '_wp_old_slug', 'this-is-a-new-post-copy-copy__trashed'),
(5241, 89, '_wp_old_slug', 'this-is-a-new-post-copy__trashed'),
(5243, 87, '_wp_old_slug', 'this-is-a-new-post__trashed'),
(5244, 96, '_edit_last', '2'),
(5245, 96, '_edit_lock', '1531434103:2'),
(5246, 96, '_wp_page_template', 'page-home.php'),
(7717, 98, '_attorneys', 'field_5ac3d6fb2e3b5'),
(7718, 98, '_attorneys_0_avvo_profile', 'field_5af9d4521c2dd'),
(7719, 98, 'attorneys_0_avvo_profile', 'https://www.avvo.com/attorneys/01103-ma-alan-goodman-1317924.html'),
(7720, 98, '_attorneys_0_years_licensed_for', 'field_5af9d4801c2de'),
(7721, 98, 'attorneys_0_years_licensed_for', '30'),
(7722, 98, '_attorneys_0_attorney_phone', 'field_5af9d6151c2e1'),
(7723, 98, 'attorneys_0_attorney_phone', ''),
(7724, 98, '_attorneys_0_attorney_address', 'field_5af9d7691c2e2'),
(7725, 98, 'attorneys_0_attorney_address', ''),
(7726, 98, '_attorneys_0_attorney_fax_number', 'field_5af9d83a1c2e4'),
(7727, 98, 'attorneys_0_attorney_fax_number', ''),
(7728, 98, '_attorneys_0_attorney_education', 'field_5af9d88d1c2e6'),
(7729, 98, '_attorneys_0_attorney_education_0_school_name', 'field_5af9d8a61c2e7'),
(7730, 98, 'attorneys_0_attorney_education_0_school_name', 'Northeastern University School of Law'),
(7731, 98, '_attorneys_0_attorney_education_0_school_degree', 'field_5af9d8b11c2e8'),
(7732, 98, 'attorneys_0_attorney_education_0_school_degree', ''),
(7733, 98, '_attorneys_0_attorney_education_0_school_year_graduated', 'field_5af9d8df1c2e9'),
(7734, 98, 'attorneys_0_attorney_education_0_school_year_graduated', '1986'),
(7735, 98, 'attorneys_0_attorney_education', '1'),
(7736, 98, '_attorneys_0_attorney_name', 'field_5ac3d7052e3b6'),
(7737, 98, 'attorneys_0_attorney_name', 'Stephen M Linsky'),
(7738, 98, 'attorneys', '1'),
(7739, 98, '_lawfirm_phone', 'field_5b00bcdaf6b8c'),
(7740, 98, 'lawfirm_phone', '(617) 439-4700'),
(7741, 98, '_lawfirm_website_url', 'field_5b00bcf9f6b8d'),
(7742, 98, 'lawfirm_website_url', 'http://www.bostonlawcollaborative.com/blc/563-BLC.html'),
(7743, 98, '_lawfirm_fax_number', 'field_5b00bffad59f3'),
(7744, 98, 'lawfirm_fax_number', ''),
(7745, 98, '_wp_page_template', 'default'),
(7746, 99, '_attorneys', 'field_5ac3d6fb2e3b5'),
(7747, 99, '_attorneys_0_avvo_profile', 'field_5af9d4521c2dd'),
(7748, 99, 'attorneys_0_avvo_profile', 'https://www.avvo.com/attorneys/00936-pr-jaime-fonalledas-647048.html'),
(7749, 99, '_attorneys_0_years_licensed_for', 'field_5af9d4801c2de'),
(7750, 99, 'attorneys_0_years_licensed_for', '11'),
(7751, 99, '_attorneys_0_attorney_phone', 'field_5af9d6151c2e1'),
(7752, 99, 'attorneys_0_attorney_phone', ''),
(7753, 99, '_attorneys_0_attorney_address', 'field_5af9d7691c2e2'),
(7754, 99, 'attorneys_0_attorney_address', ''),
(7755, 99, '_attorneys_0_attorney_fax_number', 'field_5af9d83a1c2e4'),
(7756, 99, 'attorneys_0_attorney_fax_number', ''),
(7757, 99, '_attorneys_0_attorney_education', 'field_5af9d88d1c2e6'),
(7758, 99, '_attorneys_0_attorney_education_0_school_name', 'field_5af9d8a61c2e7'),
(7759, 99, 'attorneys_0_attorney_education_0_school_name', 'Loyola University New Orleans College of Law '),
(7760, 99, '_attorneys_0_attorney_education_0_school_degree', 'field_5af9d8b11c2e8'),
(7761, 99, 'attorneys_0_attorney_education_0_school_degree', ''),
(7762, 99, '_attorneys_0_attorney_education_0_school_year_graduated', 'field_5af9d8df1c2e9'),
(7763, 99, 'attorneys_0_attorney_education_0_school_year_graduated', '2004 '),
(7764, 99, 'attorneys_0_attorney_education', '1'),
(7765, 99, '_attorneys_0_attorney_name', 'field_5ac3d7052e3b6'),
(7766, 99, 'attorneys_0_attorney_name', 'Jaime L Fonalledas'),
(7767, 99, 'attorneys', '1'),
(7768, 99, '_lawfirm_phone', 'field_5b00bcdaf6b8c'),
(7769, 99, 'lawfirm_phone', ''),
(7770, 99, '_lawfirm_website_url', 'field_5b00bcf9f6b8d'),
(7771, 99, 'lawfirm_website_url', ''),
(7772, 99, '_lawfirm_fax_number', 'field_5b00bffad59f3'),
(7773, 99, 'lawfirm_fax_number', ''),
(7774, 99, '_wp_page_template', 'default'),
(7775, 100, '_attorneys', 'field_5ac3d6fb2e3b5'),
(7776, 100, '_attorneys_0_avvo_profile', 'field_5af9d4521c2dd'),
(7777, 100, 'attorneys_0_avvo_profile', ''),
(7778, 100, '_attorneys_0_years_licensed_for', 'field_5af9d4801c2de'),
(7779, 100, 'attorneys_0_years_licensed_for', ''),
(7780, 100, '_attorneys_0_attorney_phone', 'field_5af9d6151c2e1'),
(7781, 100, 'attorneys_0_attorney_phone', ''),
(7782, 100, '_attorneys_0_attorney_address', 'field_5af9d7691c2e2'),
(7783, 100, 'attorneys_0_attorney_address', ''),
(7784, 100, '_attorneys_0_attorney_fax_number', 'field_5af9d83a1c2e4'),
(7785, 100, 'attorneys_0_attorney_fax_number', ''),
(7786, 100, '_attorneys_0_attorney_education', 'field_5af9d88d1c2e6'),
(7787, 100, '_attorneys_0_attorney_education_0_school_name', 'field_5af9d8a61c2e7'),
(7788, 100, 'attorneys_0_attorney_education_0_school_name', ''),
(7789, 100, '_attorneys_0_attorney_education_0_school_degree', 'field_5af9d8b11c2e8'),
(7790, 100, 'attorneys_0_attorney_education_0_school_degree', ''),
(7791, 100, '_attorneys_0_attorney_education_0_school_year_graduated', 'field_5af9d8df1c2e9'),
(7792, 100, 'attorneys_0_attorney_education_0_school_year_graduated', ''),
(7793, 100, 'attorneys_0_attorney_education', '1'),
(7794, 100, '_attorneys_0_attorney_name', 'field_5ac3d7052e3b6'),
(7795, 100, 'attorneys_0_attorney_name', 'Alan R Goodman'),
(7796, 100, 'attorneys', '1'),
(7797, 100, '_lawfirm_phone', 'field_5b00bcdaf6b8c'),
(7798, 100, 'lawfirm_phone', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(7799, 100, '_lawfirm_website_url', 'field_5b00bcf9f6b8d'),
(7800, 100, 'lawfirm_website_url', ''),
(7801, 100, '_lawfirm_fax_number', 'field_5b00bffad59f3'),
(7802, 100, 'lawfirm_fax_number', ''),
(7803, 100, '_wp_page_template', 'default'),
(7804, 101, '_attorneys', 'field_5ac3d6fb2e3b5'),
(7805, 101, '_attorneys_0_avvo_profile', 'field_5af9d4521c2dd'),
(7806, 101, 'attorneys_0_avvo_profile', 'https://www.avvo.com/attorneys/01103-ma-laura-mangini-4303334.html '),
(7807, 101, '_attorneys_0_years_licensed_for', 'field_5af9d4801c2de'),
(7808, 101, 'attorneys_0_years_licensed_for', '4'),
(7809, 101, '_attorneys_0_attorney_phone', 'field_5af9d6151c2e1'),
(7810, 101, 'attorneys_0_attorney_phone', ''),
(7811, 101, '_attorneys_0_attorney_address', 'field_5af9d7691c2e2'),
(7812, 101, 'attorneys_0_attorney_address', '1550 Main St Rm 401, Springfield, MA, 01103-1429 '),
(7813, 101, '_attorneys_0_attorney_fax_number', 'field_5af9d83a1c2e4'),
(7814, 101, 'attorneys_0_attorney_fax_number', ''),
(7815, 101, '_attorneys_0_attorney_education', 'field_5af9d88d1c2e6'),
(7816, 101, '_attorneys_0_attorney_education_0_school_name', 'field_5af9d8a61c2e7'),
(7817, 101, 'attorneys_0_attorney_education_0_school_name', ''),
(7818, 101, '_attorneys_0_attorney_education_0_school_degree', 'field_5af9d8b11c2e8'),
(7819, 101, 'attorneys_0_attorney_education_0_school_degree', ''),
(7820, 101, '_attorneys_0_attorney_education_0_school_year_graduated', 'field_5af9d8df1c2e9'),
(7821, 101, 'attorneys_0_attorney_education_0_school_year_graduated', ''),
(7822, 101, 'attorneys_0_attorney_education', '1'),
(7823, 101, '_attorneys_0_attorney_name', 'field_5ac3d7052e3b6'),
(7824, 101, 'attorneys_0_attorney_name', 'Laura Mangini'),
(7825, 101, '_attorneys_1_avvo_profile', 'field_5af9d4521c2dd'),
(7826, 101, 'attorneys_1_avvo_profile', ' https://www.avvo.com/attorneys/01103-ma-ryan-alekman-1475043.html'),
(7827, 101, '_attorneys_1_years_licensed_for', 'field_5af9d4801c2de'),
(7828, 101, 'attorneys_1_years_licensed_for', '19'),
(7829, 101, '_attorneys_1_attorney_phone', 'field_5af9d6151c2e1'),
(7830, 101, 'attorneys_1_attorney_phone', NULL),
(7831, 101, '_attorneys_1_attorney_address', 'field_5af9d7691c2e2'),
(7832, 101, 'attorneys_1_attorney_address', ' 55 State StreetFirst Floor, Springfield, MA, 01103'),
(7833, 101, '_attorneys_1_attorney_fax_number', 'field_5af9d83a1c2e4'),
(7834, 101, 'attorneys_1_attorney_fax_number', NULL),
(7835, 101, '_attorneys_1_attorney_education', 'field_5af9d88d1c2e6'),
(7836, 101, '_attorneys_1_attorney_education_0_school_name', 'field_5af9d8a61c2e7'),
(7837, 101, 'attorneys_1_attorney_education_0_school_name', 'Western New England College School of Law'),
(7838, 101, '_attorneys_1_attorney_education_0_school_degree', 'field_5af9d8b11c2e8'),
(7839, 101, 'attorneys_1_attorney_education_0_school_degree', ''),
(7840, 101, '_attorneys_1_attorney_education_0_school_year_graduated', 'field_5af9d8df1c2e9'),
(7841, 101, 'attorneys_1_attorney_education_0_school_year_graduated', ' 1997'),
(7842, 101, 'attorneys_1_attorney_education', '1'),
(7843, 101, '_attorneys_1_attorney_name', 'field_5ac3d7052e3b6'),
(7844, 101, 'attorneys_1_attorney_name', 'Ryan Edward Alekman'),
(7845, 101, 'attorneys', '2'),
(7846, 101, '_lawfirm_phone', 'field_5b00bcdaf6b8c'),
(7847, 101, 'lawfirm_phone', '(413) 781-0000'),
(7848, 101, '_lawfirm_website_url', 'field_5b00bcf9f6b8d'),
(7849, 101, 'lawfirm_website_url', ''),
(7850, 101, '_lawfirm_fax_number', 'field_5b00bffad59f3'),
(7851, 101, 'lawfirm_fax_number', ''),
(7852, 101, '_wp_page_template', 'default'),
(7853, 102, '_attorneys', 'field_5ac3d6fb2e3b5'),
(7854, 102, '_attorneys_0_avvo_profile', 'field_5af9d4521c2dd'),
(7855, 102, 'attorneys_0_avvo_profile', ''),
(7856, 102, '_attorneys_0_years_licensed_for', 'field_5af9d4801c2de'),
(7857, 102, 'attorneys_0_years_licensed_for', ''),
(7858, 102, '_attorneys_0_attorney_phone', 'field_5af9d6151c2e1'),
(7859, 102, 'attorneys_0_attorney_phone', ''),
(7860, 102, '_attorneys_0_attorney_address', 'field_5af9d7691c2e2'),
(7861, 102, 'attorneys_0_attorney_address', ''),
(7862, 102, '_attorneys_0_attorney_fax_number', 'field_5af9d83a1c2e4'),
(7863, 102, 'attorneys_0_attorney_fax_number', ''),
(7864, 102, '_attorneys_0_attorney_education', 'field_5af9d88d1c2e6'),
(7865, 102, '_attorneys_0_attorney_education_0_school_name', 'field_5af9d8a61c2e7'),
(7866, 102, 'attorneys_0_attorney_education_0_school_name', ''),
(7867, 102, '_attorneys_0_attorney_education_0_school_degree', 'field_5af9d8b11c2e8'),
(7868, 102, 'attorneys_0_attorney_education_0_school_degree', ''),
(7869, 102, '_attorneys_0_attorney_education_0_school_year_graduated', 'field_5af9d8df1c2e9'),
(7870, 102, 'attorneys_0_attorney_education_0_school_year_graduated', ''),
(7871, 102, 'attorneys_0_attorney_education', '1'),
(7872, 102, '_attorneys_0_attorney_name', 'field_5ac3d7052e3b6'),
(7873, 102, 'attorneys_0_attorney_name', 'Allen Henry Agnitti'),
(7874, 102, 'attorneys', '1'),
(7875, 102, '_lawfirm_phone', 'field_5b00bcdaf6b8c'),
(7876, 102, 'lawfirm_phone', ''),
(7877, 102, '_lawfirm_website_url', 'field_5b00bcf9f6b8d'),
(7878, 102, 'lawfirm_website_url', ''),
(7879, 102, '_lawfirm_fax_number', 'field_5b00bffad59f3'),
(7880, 102, 'lawfirm_fax_number', ''),
(7881, 102, '_wp_page_template', 'default'),
(7882, 103, '_attorneys', 'field_5ac3d6fb2e3b5'),
(7883, 103, '_attorneys_0_avvo_profile', 'field_5af9d4521c2dd'),
(7884, 103, 'attorneys_0_avvo_profile', ''),
(7885, 103, '_attorneys_0_years_licensed_for', 'field_5af9d4801c2de'),
(7886, 103, 'attorneys_0_years_licensed_for', ''),
(7887, 103, '_attorneys_0_attorney_phone', 'field_5af9d6151c2e1'),
(7888, 103, 'attorneys_0_attorney_phone', ''),
(7889, 103, '_attorneys_0_attorney_address', 'field_5af9d7691c2e2'),
(7890, 103, 'attorneys_0_attorney_address', ''),
(7891, 103, '_attorneys_0_attorney_fax_number', 'field_5af9d83a1c2e4'),
(7892, 103, 'attorneys_0_attorney_fax_number', ''),
(7893, 103, '_attorneys_0_attorney_education', 'field_5af9d88d1c2e6'),
(7894, 103, '_attorneys_0_attorney_education_0_school_name', 'field_5af9d8a61c2e7'),
(7895, 103, 'attorneys_0_attorney_education_0_school_name', ''),
(7896, 103, '_attorneys_0_attorney_education_0_school_degree', 'field_5af9d8b11c2e8'),
(7897, 103, 'attorneys_0_attorney_education_0_school_degree', ''),
(7898, 103, '_attorneys_0_attorney_education_0_school_year_graduated', 'field_5af9d8df1c2e9') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(7899, 103, 'attorneys_0_attorney_education_0_school_year_graduated', ''),
(7900, 103, 'attorneys_0_attorney_education', '1'),
(7901, 103, '_attorneys_0_attorney_name', 'field_5ac3d7052e3b6'),
(7902, 103, 'attorneys_0_attorney_name', 'Michael A. McHale'),
(7903, 103, '_attorneys_1_avvo_profile', 'field_5af9d4521c2dd'),
(7904, 103, 'attorneys_1_avvo_profile', NULL),
(7905, 103, '_attorneys_1_years_licensed_for', 'field_5af9d4801c2de'),
(7906, 103, 'attorneys_1_years_licensed_for', NULL),
(7907, 103, '_attorneys_1_attorney_phone', 'field_5af9d6151c2e1'),
(7908, 103, 'attorneys_1_attorney_phone', NULL),
(7909, 103, '_attorneys_1_attorney_address', 'field_5af9d7691c2e2'),
(7910, 103, 'attorneys_1_attorney_address', NULL),
(7911, 103, '_attorneys_1_attorney_fax_number', 'field_5af9d83a1c2e4'),
(7912, 103, 'attorneys_1_attorney_fax_number', NULL),
(7913, 103, '_attorneys_1_attorney_education', 'field_5af9d88d1c2e6'),
(7914, 103, '_attorneys_1_attorney_education_0_school_name', 'field_5af9d8a61c2e7'),
(7915, 103, 'attorneys_1_attorney_education_0_school_name', ''),
(7916, 103, '_attorneys_1_attorney_education_0_school_degree', 'field_5af9d8b11c2e8'),
(7917, 103, 'attorneys_1_attorney_education_0_school_degree', ''),
(7918, 103, '_attorneys_1_attorney_education_0_school_year_graduated', 'field_5af9d8df1c2e9'),
(7919, 103, 'attorneys_1_attorney_education_0_school_year_graduated', ''),
(7920, 103, 'attorneys_1_attorney_education', '1'),
(7921, 103, '_attorneys_1_attorney_name', 'field_5ac3d7052e3b6'),
(7922, 103, 'attorneys_1_attorney_name', 'Donald James Allison'),
(7923, 103, 'attorneys', '2'),
(7924, 103, '_lawfirm_phone', 'field_5b00bcdaf6b8c'),
(7925, 103, 'lawfirm_phone', ''),
(7926, 103, '_lawfirm_website_url', 'field_5b00bcf9f6b8d'),
(7927, 103, 'lawfirm_website_url', ''),
(7928, 103, '_lawfirm_fax_number', 'field_5b00bffad59f3'),
(7929, 103, 'lawfirm_fax_number', ''),
(7930, 103, '_wp_page_template', 'default'),
(7931, 104, '_attorneys', 'field_5ac3d6fb2e3b5'),
(7932, 104, '_attorneys_0_avvo_profile', 'field_5af9d4521c2dd'),
(7933, 104, 'attorneys_0_avvo_profile', ''),
(7934, 104, '_attorneys_0_years_licensed_for', 'field_5af9d4801c2de'),
(7935, 104, 'attorneys_0_years_licensed_for', ''),
(7936, 104, '_attorneys_0_attorney_phone', 'field_5af9d6151c2e1'),
(7937, 104, 'attorneys_0_attorney_phone', ''),
(7938, 104, '_attorneys_0_attorney_address', 'field_5af9d7691c2e2'),
(7939, 104, 'attorneys_0_attorney_address', ''),
(7940, 104, '_attorneys_0_attorney_fax_number', 'field_5af9d83a1c2e4'),
(7941, 104, 'attorneys_0_attorney_fax_number', ''),
(7942, 104, '_attorneys_0_attorney_education', 'field_5af9d88d1c2e6'),
(7943, 104, '_attorneys_0_attorney_education_0_school_name', 'field_5af9d8a61c2e7'),
(7944, 104, 'attorneys_0_attorney_education_0_school_name', ''),
(7945, 104, '_attorneys_0_attorney_education_0_school_degree', 'field_5af9d8b11c2e8'),
(7946, 104, 'attorneys_0_attorney_education_0_school_degree', ''),
(7947, 104, '_attorneys_0_attorney_education_0_school_year_graduated', 'field_5af9d8df1c2e9'),
(7948, 104, 'attorneys_0_attorney_education_0_school_year_graduated', ''),
(7949, 104, 'attorneys_0_attorney_education', '1'),
(7950, 104, '_attorneys_0_attorney_name', 'field_5ac3d7052e3b6'),
(7951, 104, 'attorneys_0_attorney_name', 'Shawn Patrick Allyn'),
(7952, 104, 'attorneys', '1'),
(7953, 104, '_lawfirm_phone', 'field_5b00bcdaf6b8c'),
(7954, 104, 'lawfirm_phone', ''),
(7955, 104, '_lawfirm_website_url', 'field_5b00bcf9f6b8d'),
(7956, 104, 'lawfirm_website_url', ''),
(7957, 104, '_lawfirm_fax_number', 'field_5b00bffad59f3'),
(7958, 104, 'lawfirm_fax_number', ''),
(7959, 104, '_wp_page_template', 'default'),
(7960, 105, '_attorneys', 'field_5ac3d6fb2e3b5'),
(7961, 105, '_attorneys_0_avvo_profile', 'field_5af9d4521c2dd'),
(7962, 105, 'attorneys_0_avvo_profile', ''),
(7963, 105, '_attorneys_0_years_licensed_for', 'field_5af9d4801c2de'),
(7964, 105, 'attorneys_0_years_licensed_for', ''),
(7965, 105, '_attorneys_0_attorney_phone', 'field_5af9d6151c2e1'),
(7966, 105, 'attorneys_0_attorney_phone', ''),
(7967, 105, '_attorneys_0_attorney_address', 'field_5af9d7691c2e2'),
(7968, 105, 'attorneys_0_attorney_address', ''),
(7969, 105, '_attorneys_0_attorney_fax_number', 'field_5af9d83a1c2e4'),
(7970, 105, 'attorneys_0_attorney_fax_number', ''),
(7971, 105, '_attorneys_0_attorney_education', 'field_5af9d88d1c2e6'),
(7972, 105, '_attorneys_0_attorney_education_0_school_name', 'field_5af9d8a61c2e7'),
(7973, 105, 'attorneys_0_attorney_education_0_school_name', ''),
(7974, 105, '_attorneys_0_attorney_education_0_school_degree', 'field_5af9d8b11c2e8'),
(7975, 105, 'attorneys_0_attorney_education_0_school_degree', ''),
(7976, 105, '_attorneys_0_attorney_education_0_school_year_graduated', 'field_5af9d8df1c2e9'),
(7977, 105, 'attorneys_0_attorney_education_0_school_year_graduated', ''),
(7978, 105, 'attorneys_0_attorney_education', '1'),
(7979, 105, '_attorneys_0_attorney_name', 'field_5ac3d7052e3b6'),
(7980, 105, 'attorneys_0_attorney_name', 'Corinne A Rock'),
(7981, 105, 'attorneys', '1'),
(7982, 105, '_lawfirm_phone', 'field_5b00bcdaf6b8c'),
(7983, 105, 'lawfirm_phone', ''),
(7984, 105, '_lawfirm_website_url', 'field_5b00bcf9f6b8d'),
(7985, 105, 'lawfirm_website_url', ''),
(7986, 105, '_lawfirm_fax_number', 'field_5b00bffad59f3'),
(7987, 105, 'lawfirm_fax_number', ''),
(7988, 105, '_wp_page_template', 'default'),
(7989, 106, '_attorneys', 'field_5ac3d6fb2e3b5'),
(7990, 106, '_attorneys_0_avvo_profile', 'field_5af9d4521c2dd'),
(7991, 106, 'attorneys_0_avvo_profile', 'https://www.avvo.com/attorneys/00918-pr-jonathan-gottfried-4611041.html'),
(7992, 106, '_attorneys_0_years_licensed_for', 'field_5af9d4801c2de'),
(7993, 106, 'attorneys_0_years_licensed_for', ''),
(7994, 106, '_attorneys_0_attorney_phone', 'field_5af9d6151c2e1'),
(7995, 106, 'attorneys_0_attorney_phone', '(310) 274-7100'),
(7996, 106, '_attorneys_0_attorney_address', 'field_5af9d7691c2e2'),
(7997, 106, 'attorneys_0_attorney_address', ''),
(7998, 106, '_attorneys_0_attorney_fax_number', 'field_5af9d83a1c2e4') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(7999, 106, 'attorneys_0_attorney_fax_number', ''),
(8000, 106, '_attorneys_0_attorney_education', 'field_5af9d88d1c2e6'),
(8001, 106, '_attorneys_0_attorney_education_0_school_name', 'field_5af9d8a61c2e7'),
(8002, 106, 'attorneys_0_attorney_education_0_school_name', 'Harvard Univ Law School'),
(8003, 106, '_attorneys_0_attorney_education_0_school_degree', 'field_5af9d8b11c2e8'),
(8004, 106, 'attorneys_0_attorney_education_0_school_degree', ''),
(8005, 106, '_attorneys_0_attorney_education_0_school_year_graduated', 'field_5af9d8df1c2e9'),
(8006, 106, 'attorneys_0_attorney_education_0_school_year_graduated', ''),
(8007, 106, 'attorneys_0_attorney_education', '1'),
(8008, 106, '_attorneys_0_attorney_name', 'field_5ac3d7052e3b6'),
(8009, 106, 'attorneys_0_attorney_name', 'Jonathan L. Gottfried'),
(8010, 106, 'attorneys', '1'),
(8011, 106, '_lawfirm_phone', 'field_5b00bcdaf6b8c'),
(8012, 106, 'lawfirm_phone', '(310) 274-7100'),
(8013, 106, '_lawfirm_website_url', 'field_5b00bcf9f6b8d'),
(8014, 106, 'lawfirm_website_url', ''),
(8015, 106, '_lawfirm_fax_number', 'field_5b00bffad59f3'),
(8016, 106, 'lawfirm_fax_number', ''),
(8017, 106, '_wp_page_template', 'default'),
(8018, 106, '_edit_lock', '1531434290:2'),
(8019, 107, '_edit_last', '2'),
(8020, 107, '_edit_lock', '1531339586:2'),
(8021, 107, 'attorneys', ''),
(8022, 107, '_attorneys', 'field_5ac3d6fb2e3b5'),
(8023, 107, 'lawfirm_phone', ''),
(8024, 107, '_lawfirm_phone', 'field_5b00bcdaf6b8c'),
(8025, 107, 'lawfirm_website_url', ''),
(8026, 107, '_lawfirm_website_url', 'field_5b00bcf9f6b8d'),
(8027, 107, 'lawfirm_fax_number', ''),
(8028, 107, '_lawfirm_fax_number', 'field_5b00bffad59f3'),
(8029, 108, '_edit_last', '2'),
(8030, 108, '_edit_lock', '1531434291:2'),
(8031, 108, 'attorneys', ''),
(8032, 108, '_attorneys', 'field_5ac3d6fb2e3b5'),
(8033, 108, 'lawfirm_phone', ''),
(8034, 108, '_lawfirm_phone', 'field_5b00bcdaf6b8c'),
(8035, 108, 'lawfirm_website_url', ''),
(8036, 108, '_lawfirm_website_url', 'field_5b00bcf9f6b8d'),
(8037, 108, 'lawfirm_fax_number', ''),
(8038, 108, '_lawfirm_fax_number', 'field_5b00bffad59f3'),
(8039, 109, '_edit_last', '2'),
(8040, 109, '_edit_lock', '1527629616:2'),
(8041, 98, '_edit_lock', '1531342755:2'),
(8042, 110, '_edit_last', '2'),
(8043, 110, '_edit_lock', '1527629894:2'),
(8050, 113, '_edit_last', '2'),
(8051, 113, '_wp_page_template', 'default'),
(8052, 113, '_edit_lock', '1528081158:2'),
(8053, 106, '_edit_last', '2'),
(8054, 118, '_edit_last', '2'),
(8055, 118, '_edit_lock', '1531434291:2'),
(8056, 118, 'attorneys', ''),
(8057, 118, '_attorneys', 'field_5ac3d6fb2e3b5'),
(8058, 118, 'lawfirm_phone', ''),
(8059, 118, '_lawfirm_phone', 'field_5b00bcdaf6b8c'),
(8060, 118, 'lawfirm_website_url', ''),
(8061, 118, '_lawfirm_website_url', 'field_5b00bcf9f6b8d'),
(8062, 118, 'lawfirm_fax_number', ''),
(8063, 118, '_lawfirm_fax_number', 'field_5b00bffad59f3'),
(8064, 119, '_edit_last', '2'),
(8065, 119, '_edit_lock', '1531339585:2'),
(8066, 119, 'attorneys', ''),
(8067, 119, '_attorneys', 'field_5ac3d6fb2e3b5'),
(8068, 119, 'lawfirm_phone', ''),
(8069, 119, '_lawfirm_phone', 'field_5b00bcdaf6b8c'),
(8070, 119, 'lawfirm_website_url', ''),
(8071, 119, '_lawfirm_website_url', 'field_5b00bcf9f6b8d'),
(8072, 119, 'lawfirm_fax_number', ''),
(8073, 119, '_lawfirm_fax_number', 'field_5b00bffad59f3'),
(8074, 100, '_edit_lock', '1531342776:2'),
(8075, 101, '_edit_lock', '1531342777:2'),
(8076, 102, '_edit_lock', '1531342777:2'),
(8077, 99, '_edit_lock', '1531428589:2'),
(8078, 99, '_edit_last', '2'),
(8079, 120, '_edit_last', '2'),
(8080, 120, '_edit_lock', '1531434290:2'),
(8081, 96, 'select_cities', '315'),
(8082, 96, '_select_cities', 'field_5b47d12d38dc2'),
(8083, 123, 'select_cities', '315'),
(8084, 123, '_select_cities', 'field_5b47d12d38dc2'),
(8085, 96, 'select_top_cities_0_select_city', '315'),
(8086, 96, '_select_top_cities_0_select_city', 'field_5b47d12d38dc2'),
(8087, 96, 'select_top_cities_1_select_city', '318'),
(8088, 96, '_select_top_cities_1_select_city', 'field_5b47d12d38dc2'),
(8089, 96, 'select_top_cities_2_select_city', '303'),
(8090, 96, '_select_top_cities_2_select_city', 'field_5b47d12d38dc2'),
(8091, 96, 'select_top_cities', '3'),
(8092, 96, '_select_top_cities', 'field_5b47d1be80f53'),
(8093, 125, 'select_cities', '315'),
(8094, 125, '_select_cities', 'field_5b47d12d38dc2'),
(8095, 125, 'select_top_cities_0_select_city', '315'),
(8096, 125, '_select_top_cities_0_select_city', 'field_5b47d12d38dc2'),
(8097, 125, 'select_top_cities_1_select_city', '318'),
(8098, 125, '_select_top_cities_1_select_city', 'field_5b47d12d38dc2'),
(8099, 125, 'select_top_cities_2_select_city', '303'),
(8100, 125, '_select_top_cities_2_select_city', 'field_5b47d12d38dc2'),
(8101, 125, 'select_top_cities', '3'),
(8102, 125, '_select_top_cities', 'field_5b47d1be80f53') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(4, 2, '2018-04-03 19:34:39', '2018-04-03 19:34:39', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"lawfirm";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:4:{i:0;s:7:"excerpt";i:1;s:14:"featured_image";i:2;s:10:"categories";i:3;s:4:"tags";}s:11:"description";s:0:"";}', 'Lawfirms', 'lawfirms', 'publish', 'closed', 'closed', '', 'group_5ac3d6f49abc9', '', '', '2018-05-20 18:29:37', '2018-05-20 18:29:37', '', 0, 'http://lawyers-directory.com/?post_type=acf-field-group&#038;p=4', 0, 'acf-field-group', '', 0),
(5, 2, '2018-04-03 19:34:39', '2018-04-03 19:34:39', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:12:"Add Attorney";}', 'Attorneys', 'attorneys', 'publish', 'closed', 'closed', '', 'field_5ac3d6fb2e3b5', '', '', '2018-04-03 19:34:39', '2018-04-03 19:34:39', '', 4, 'http://lawyers-directory.com/?post_type=acf-field&p=5', 0, 'acf-field', '', 0),
(6, 2, '2018-04-03 19:34:39', '2018-04-03 19:34:39', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Attorney Name', 'attorney_name', 'publish', 'closed', 'closed', '', 'field_5ac3d7052e3b6', '', '', '2018-05-14 18:44:01', '2018-05-14 18:44:01', '', 5, 'http://lawyers-directory.com/?post_type=acf-field&#038;p=6', 0, 'acf-field', '', 0),
(10, 2, '2018-04-04 17:34:19', '2018-04-04 17:34:19', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Static Page', '', 'publish', 'closed', 'closed', '', 'static-page', '', '', '2018-04-06 17:32:13', '2018-04-06 17:32:13', '', 0, 'http://lawyers-directory.com/?page_id=10', 0, 'page', '', 0),
(11, 2, '2018-04-04 17:34:19', '2018-04-04 17:34:19', '', 'Welcome', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-04-04 17:34:19', '2018-04-04 17:34:19', '', 10, 'http://lawyers-directory.com/2018/04/04/10-revision-v1/', 0, 'revision', '', 0),
(12, 2, '2018-04-04 17:36:07', '2018-04-04 17:36:07', '', 'Front Page', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-04-04 17:36:07', '2018-04-04 17:36:07', '', 10, 'http://lawyers-directory.com/2018/04/04/10-revision-v1/', 0, 'revision', '', 0),
(13, 2, '2018-04-06 17:12:32', '2018-04-06 17:12:32', '', 'Static Page', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-04-06 17:12:32', '2018-04-06 17:12:32', '', 10, 'http://lawyers-directory.com/2018/04/06/10-revision-v1/', 0, 'revision', '', 0),
(14, 2, '2018-04-06 17:32:13', '2018-04-06 17:32:13', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Static Page', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-04-06 17:32:13', '2018-04-06 17:32:13', '', 10, 'http://lawyers-directory.com/2018/04/06/10-revision-v1/', 0, 'revision', '', 0),
(17, 2, '2018-05-14 18:44:01', '2018-05-14 18:44:01', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Avvo Profile', 'avvo_profile', 'publish', 'closed', 'closed', '', 'field_5af9d4521c2dd', '', '', '2018-05-14 18:44:01', '2018-05-14 18:44:01', '', 5, 'http://lawyers-directory.com/?post_type=acf-field&p=17', 1, 'acf-field', '', 0),
(18, 2, '2018-05-14 18:44:01', '2018-05-14 18:44:01', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Years Licensed', 'years_licensed_for', 'publish', 'closed', 'closed', '', 'field_5af9d4801c2de', '', '', '2018-05-14 18:44:01', '2018-05-14 18:44:01', '', 5, 'http://lawyers-directory.com/?post_type=acf-field&p=18', 2, 'acf-field', '', 0),
(21, 2, '2018-05-14 18:44:01', '2018-05-14 18:44:01', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Attorney Phone', 'attorney_phone', 'publish', 'closed', 'closed', '', 'field_5af9d6151c2e1', '', '', '2018-05-20 00:41:01', '2018-05-20 00:41:01', '', 5, 'http://lawyers-directory.com/?post_type=acf-field&#038;p=21', 3, 'acf-field', '', 0),
(23, 2, '2018-05-14 18:44:01', '2018-05-14 18:44:01', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Attorney Address', 'attorney_address', 'publish', 'closed', 'closed', '', 'field_5af9d7691c2e2', '', '', '2018-05-20 00:41:01', '2018-05-20 00:41:01', '', 5, 'http://lawyers-directory.com/?post_type=acf-field&#038;p=23', 4, 'acf-field', '', 0),
(24, 2, '2018-05-14 18:44:01', '2018-05-14 18:44:01', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Attorney Fax Number', 'attorney_fax_number', 'publish', 'closed', 'closed', '', 'field_5af9d83a1c2e4', '', '', '2018-05-20 00:41:01', '2018-05-20 00:41:01', '', 5, 'http://lawyers-directory.com/?post_type=acf-field&#038;p=24', 5, 'acf-field', '', 0),
(26, 2, '2018-05-14 18:44:01', '2018-05-14 18:44:01', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:10:"Add School";}', 'Attorney Education', 'attorney_education', 'publish', 'closed', 'closed', '', 'field_5af9d88d1c2e6', '', '', '2018-05-20 00:41:01', '2018-05-20 00:41:01', '', 5, 'http://lawyers-directory.com/?post_type=acf-field&#038;p=26', 6, 'acf-field', '', 0),
(27, 2, '2018-05-14 18:44:01', '2018-05-14 18:44:01', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'School Name', 'school_name', 'publish', 'closed', 'closed', '', 'field_5af9d8a61c2e7', '', '', '2018-05-14 18:44:01', '2018-05-14 18:44:01', '', 26, 'http://lawyers-directory.com/?post_type=acf-field&p=27', 0, 'acf-field', '', 0),
(28, 2, '2018-05-14 18:44:01', '2018-05-14 18:44:01', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'School Degree', 'school_degree', 'publish', 'closed', 'closed', '', 'field_5af9d8b11c2e8', '', '', '2018-05-14 18:44:01', '2018-05-14 18:44:01', '', 26, 'http://lawyers-directory.com/?post_type=acf-field&p=28', 1, 'acf-field', '', 0),
(29, 2, '2018-05-14 18:44:01', '2018-05-14 18:44:01', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'School Year Graduated', 'school_year_graduated', 'publish', 'closed', 'closed', '', 'field_5af9d8df1c2e9', '', '', '2018-05-14 18:44:01', '2018-05-14 18:44:01', '', 26, 'http://lawyers-directory.com/?post_type=acf-field&p=29', 2, 'acf-field', '', 0),
(37, 2, '2018-05-20 00:11:00', '2018-05-20 00:11:00', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Lawfirm Phone', 'lawfirm_phone', 'publish', 'closed', 'closed', '', 'field_5b00bcdaf6b8c', '', '', '2018-05-20 00:11:00', '2018-05-20 00:11:00', '', 4, 'http://lawyers-directory.com/?post_type=acf-field&p=37', 1, 'acf-field', '', 0),
(38, 2, '2018-05-20 00:11:00', '2018-05-20 00:11:00', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Lawfirm Website URL', 'lawfirm_website_url', 'publish', 'closed', 'closed', '', 'field_5b00bcf9f6b8d', '', '', '2018-05-20 04:12:46', '2018-05-20 04:12:46', '', 4, 'http://lawyers-directory.com/?post_type=acf-field&#038;p=38', 2, 'acf-field', '', 0),
(48, 2, '2018-05-20 00:23:32', '2018-05-20 00:23:32', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Lawfirm Fax Number', 'lawfirm_fax_number', 'publish', 'closed', 'closed', '', 'field_5b00bffad59f3', '', '', '2018-05-20 00:23:32', '2018-05-20 00:23:32', '', 4, 'http://lawyers-directory.com/?post_type=acf-field&p=48', 3, 'acf-field', '', 0),
(61, 2, '2018-05-20 03:14:38', '2018-05-20 03:14:38', 'yooooooo', 'Garretts Post Here', '', 'publish', 'closed', 'closed', '', 'garretts-post-here', '', '', '2018-05-20 03:28:11', '2018-05-20 03:28:11', '', 0, 'http://lawyers-directory.com/?post_type=garrett_cpt&#038;p=61', 0, 'garrett_cpt', '', 0),
(87, 2, '2018-05-22 23:49:16', '2018-05-22 23:49:16', 'Garrett Content', 'This is a new post', '', 'publish', 'open', 'open', '', 'this-is-a-new-post', '', '', '2018-05-27 05:29:56', '2018-05-27 05:29:56', '', 0, 'http://lawyers-directory.com/?p=87', 0, 'post', '', 0),
(88, 2, '2018-05-22 23:49:16', '2018-05-22 23:49:16', 'Garrett Content', 'This is a new post', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2018-05-22 23:49:16', '2018-05-22 23:49:16', '', 87, 'http://lawyers-directory.com/87-revision-v1/', 0, 'revision', '', 0),
(89, 2, '2018-05-23 03:40:49', '2018-05-23 03:40:49', 'Garrett Content', 'This is a new post  Copy', '', 'publish', 'open', 'open', '', 'this-is-a-new-post-copy', '', '', '2018-05-27 05:29:56', '2018-05-27 05:29:56', '', 0, 'http://lawyers-directory.com/this-is-a-new-post-copy/', 0, 'post', '', 0),
(90, 2, '2018-05-23 03:40:51', '2018-05-23 03:40:51', 'Garrett Content', 'This is a new post  Copy  Copy', '', 'publish', 'open', 'open', '', 'this-is-a-new-post-copy-copy', '', '', '2018-05-27 05:29:56', '2018-05-27 05:29:56', '', 0, 'http://lawyers-directory.com/this-is-a-new-post-copy-copy/', 0, 'post', '', 0),
(93, 2, '2018-05-23 17:41:11', '2018-05-23 17:41:11', 'Garrett Content', 'This is a new post  Copy  Copy', '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', '2018-05-23 17:41:11', '2018-05-23 17:41:11', '', 90, 'http://lawyers-directory.com/90-revision-v1/', 0, 'revision', '', 0),
(94, 2, '2018-05-23 21:34:28', '2018-05-23 21:34:28', 'Garrett Content', 'This is a new post  Copy', '', 'inherit', 'closed', 'closed', '', '89-revision-v1', '', '', '2018-05-23 21:34:28', '2018-05-23 21:34:28', '', 89, 'http://lawyers-directory.com/89-revision-v1/', 0, 'revision', '', 0),
(96, 2, '2018-05-28 01:36:04', '2018-05-28 01:36:04', '', 'Homepage', '', 'publish', 'closed', 'closed', '', 'homepage', '', '', '2018-07-12 22:24:03', '2018-07-12 22:24:03', '', 0, 'http://lawyers-directory.com/?page_id=96', 0, 'page', '', 0),
(97, 2, '2018-05-28 01:36:04', '2018-05-28 01:36:04', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '96-revision-v1', '', '', '2018-05-28 01:36:04', '2018-05-28 01:36:04', '', 96, 'http://lawyers-directory.com/96-revision-v1/', 0, 'revision', '', 0),
(98, 2, '2018-05-28 23:51:22', '2018-05-28 23:51:22', '30 Walpole Street, Norwood, MA, 02062-3356', 'Agreement Resources, LLC', '', 'publish', 'closed', 'open', '', 'agreement-resources-llc', '', '', '2018-05-28 23:51:22', '2018-05-28 23:51:22', '', 0, 'http://lawyers-directory.com/lawfirm/agreement-resources-llc/', 0, 'lawfirm', '', 0),
(99, 2, '2018-05-28 23:51:22', '2018-05-28 23:51:22', '1300 19th Northwest, Washington, DC, 20036', 'Akin Gump Strauss Hauer & Feld LLP', '', 'publish', 'closed', 'open', '', 'akin-gump-strauss-hauer-feld-llp', '', '', '2018-07-12 16:55:26', '2018-07-12 16:55:26', '', 0, 'http://lawyers-directory.com/lawfirm/akin-gump-strauss-hauer-feld-llp/', 0, 'lawfirm', '', 0),
(100, 2, '2018-05-28 23:51:22', '2018-05-28 23:51:22', '', 'Alan R Goodman', '', 'publish', 'closed', 'open', '', 'alan-r-goodman', '', '', '2018-05-28 23:51:22', '2018-05-28 23:51:22', '', 0, 'http://lawyers-directory.com/lawfirm/alan-r-goodman/', 0, 'lawfirm', '', 0),
(101, 2, '2018-05-28 23:51:22', '2018-05-28 23:51:22', '1550 Main St Rm 401, Springfield, MA, 01103-1429', 'Alekman Ditusa, LLC', '', 'publish', 'closed', 'open', '', 'alekman-ditusa-llc', '', '', '2018-05-28 23:51:22', '2018-05-28 23:51:22', '', 0, 'http://lawyers-directory.com/lawfirm/alekman-ditusa-llc/', 0, 'lawfirm', '', 0),
(102, 2, '2018-05-28 23:51:22', '2018-05-28 23:51:22', '', 'Allen Agnitti, Esquire', '', 'publish', 'closed', 'open', '', 'allen-agnitti-esquire', '', '', '2018-05-28 23:51:22', '2018-05-28 23:51:22', '', 0, 'http://lawyers-directory.com/lawfirm/allen-agnitti-esquire/', 0, 'lawfirm', '', 0),
(103, 2, '2018-05-28 23:51:22', '2018-05-28 23:51:22', '', 'Allison, Angier, & Mchale LLP', '', 'publish', 'closed', 'open', '', 'allison-angier-mchale-llp', '', '', '2018-05-28 23:51:23', '2018-05-28 23:51:23', '', 0, 'http://lawyers-directory.com/lawfirm/allison-angier-mchale-llp/', 0, 'lawfirm', '', 0),
(104, 2, '2018-05-28 23:51:22', '2018-05-28 23:51:22', '', 'Allyn & Ball, PC', '', 'publish', 'closed', 'open', '', 'allyn-ball-pc', '', '', '2018-05-28 23:51:23', '2018-05-28 23:51:23', '', 0, 'http://lawyers-directory.com/lawfirm/allyn-ball-pc/', 0, 'lawfirm', '', 0),
(105, 2, '2018-05-28 23:51:22', '2018-05-28 23:51:22', '', 'American International College; Holyoke Com. Coll.', '', 'publish', 'closed', 'open', '', 'american-international-college-holyoke-com-coll', '', '', '2018-05-28 23:51:23', '2018-05-28 23:51:23', '', 0, 'http://lawyers-directory.com/lawfirm/american-international-college-holyoke-com-coll/', 0, 'lawfirm', '', 0),
(106, 2, '2018-05-28 23:51:22', '2018-05-28 23:51:22', '2121 Avenue Of The Stars Ste 2400, Los Angeles, CA, 90067-5048', 'Browne George Ross LLP', '', 'publish', 'closed', 'open', '', 'browne-george-ross-llp', '', '', '2018-07-12 21:09:19', '2018-07-12 21:09:19', '', 0, 'http://lawyers-directory.com/lawfirm/browne-george-ross-llp/', 0, 'lawfirm', '', 0),
(107, 2, '2018-05-29 00:15:20', '2018-05-29 00:15:20', '', 'Garrett Test', '', 'publish', 'closed', 'closed', '', 'garrett-test', '', '', '2018-07-10 17:29:02', '2018-07-10 17:29:02', '', 0, 'http://lawyers-directory.com/?post_type=lawfirm&#038;p=107', 0, 'lawfirm', '', 0),
(108, 2, '2018-05-29 00:28:26', '2018-05-29 00:28:26', '', 'Garrett Mass Test', '', 'publish', 'closed', 'closed', '', 'garrett-mass-test', '', '', '2018-07-12 21:09:32', '2018-07-12 21:09:32', '', 0, 'http://lawyers-directory.com/?post_type=lawfirm&#038;p=108', 0, 'lawfirm', '', 0),
(109, 2, '2018-05-29 21:35:58', '2018-05-29 21:35:58', 'awg', 'weqgr', '', 'publish', 'closed', 'closed', '', 'weqgr', '', '', '2018-05-29 21:35:58', '2018-05-29 21:35:58', '', 0, 'http://lawyers-directory.com/?post_type=test&#038;p=109', 0, 'test', '', 0),
(110, 2, '2018-05-29 21:40:36', '2018-05-29 21:40:36', 'zsdg', 'szd', '', 'publish', 'closed', 'closed', '', 'szd', '', '', '2018-05-29 21:40:36', '2018-05-29 21:40:36', '', 0, 'http://lawyers-directory.com/?post_type=lawfirms&#038;p=110', 0, 'lawfirms', '', 0),
(113, 2, '2018-05-30 05:20:22', '2018-05-30 05:20:22', '', 'PA Test', '', 'publish', 'closed', 'closed', '', 'pa-test', '', '', '2018-06-04 03:01:39', '2018-06-04 03:01:39', '', 0, 'http://lawyers-directory.com/?page_id=113', 0, 'page', '', 0),
(114, 2, '2018-05-30 05:20:22', '2018-05-30 05:20:22', '', 'designers', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2018-05-30 05:20:22', '2018-05-30 05:20:22', '', 113, 'http://lawyers-directory.com/113-revision-v1/', 0, 'revision', '', 0),
(115, 2, '2018-06-04 03:01:39', '2018-06-04 03:01:39', '', 'PA Test', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2018-06-04 03:01:39', '2018-06-04 03:01:39', '', 113, 'http://lawyers-directory.com/113-revision-v1/', 0, 'revision', '', 0),
(117, 2, '2018-07-09 15:35:31', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-07-09 15:35:31', '0000-00-00 00:00:00', '', 0, 'http://lawyers-directory.com/?p=117', 0, 'post', '', 0),
(118, 2, '2018-07-10 17:29:27', '2018-07-10 17:29:27', '', 'Garrett Test  Copy', '', 'publish', 'closed', 'closed', '', 'garrett-test-copy', '', '', '2018-07-12 21:09:39', '2018-07-12 21:09:39', '', 0, 'http://lawyers-directory.com/lawfirm/garrett-test-copy/', 0, 'lawfirm', '', 0),
(119, 2, '2018-07-11 16:38:28', '2018-07-11 16:38:28', '', 'Garrett Test  Copy  Copy', '', 'publish', 'closed', 'closed', '', 'garrett-test-copy-copy', '', '', '2018-07-11 17:56:16', '2018-07-11 17:56:16', '', 0, 'http://lawyers-directory.com/lawfirm/garrett-test-copy-copy/', 0, 'lawfirm', '', 0),
(120, 2, '2018-07-12 22:09:30', '2018-07-12 22:09:30', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:13:"page-home.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}', 'Homepage', 'homepage', 'publish', 'closed', 'closed', '', 'group_5b47d0f7325cb', '', '', '2018-07-12 22:23:51', '2018-07-12 22:23:51', '', 0, 'http://lawyers-directory.com/?post_type=acf-field-group&#038;p=120', 0, 'acf-field-group', '', 0),
(121, 2, '2018-07-12 22:09:30', '2018-07-12 22:09:30', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Section Three', '', 'publish', 'closed', 'closed', '', 'field_5b47d10038dc1', '', '', '2018-07-12 22:09:30', '2018-07-12 22:09:30', '', 120, 'http://lawyers-directory.com/?post_type=acf-field&p=121', 0, 'acf-field', '', 0),
(122, 2, '2018-07-12 22:09:30', '2018-07-12 22:09:30', 'a:13:{s:4:"type";s:8:"taxonomy";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:8:"taxonomy";s:17:"lawfirm_locations";s:10:"field_type";s:6:"select";s:10:"allow_null";i:0;s:8:"add_term";i:0;s:10:"save_terms";i:0;s:10:"load_terms";i:0;s:13:"return_format";s:2:"id";s:8:"multiple";i:0;}', 'Select City', 'select_city', 'publish', 'closed', 'closed', '', 'field_5b47d12d38dc2', '', '', '2018-07-12 22:23:51', '2018-07-12 22:23:51', '', 124, 'http://lawyers-directory.com/?post_type=acf-field&#038;p=122', 0, 'acf-field', '', 0),
(123, 2, '2018-07-12 22:09:51', '2018-07-12 22:09:51', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '96-revision-v1', '', '', '2018-07-12 22:09:51', '2018-07-12 22:09:51', '', 96, 'http://lawyers-directory.com/96-revision-v1/', 0, 'revision', '', 0),
(124, 2, '2018-07-12 22:10:57', '2018-07-12 22:10:57', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:12:"Add Top City";}', 'Select Top Cities', 'select_top_cities', 'publish', 'closed', 'closed', '', 'field_5b47d1be80f53', '', '', '2018-07-12 22:10:57', '2018-07-12 22:10:57', '', 120, 'http://lawyers-directory.com/?post_type=acf-field&p=124', 1, 'acf-field', '', 0),
(125, 2, '2018-07-12 22:11:39', '2018-07-12 22:11:39', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '96-revision-v1', '', '', '2018-07-12 22:11:39', '2018-07-12 22:11:39', '', 96, 'http://lawyers-directory.com/96-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_swp_cf`
#

DROP TABLE IF EXISTS `wp_swp_cf`;


#
# Table structure of table `wp_swp_cf`
#

CREATE TABLE `wp_swp_cf` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `metakey` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term` int(20) unsigned NOT NULL,
  `count` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `metakey` (`metakey`),
  KEY `term` (`term`),
  KEY `postidindex` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_swp_cf`
#
INSERT INTO `wp_swp_cf` ( `id`, `metakey`, `term`, `count`, `post_id`) VALUES
(61, 'attorneys_0_attorney_name', 10, 1, 75),
(62, 'attorneys_0_attorney_name', 11, 1, 75),
(63, 'attorneys_0_attorney_name', 24, 1, 76),
(64, 'attorneys_0_attorney_name', 25, 1, 76),
(65, 'attorneys_0_attorney_name', 26, 1, 77),
(66, 'attorneys_0_attorney_name', 27, 1, 77),
(67, 'attorneys_0_attorney_name', 37, 1, 78),
(68, 'attorneys_0_attorney_name', 38, 1, 78),
(69, 'attorneys_0_attorney_name', 40, 1, 79),
(70, 'attorneys_0_attorney_name', 41, 1, 79),
(71, 'attorneys_0_attorney_name', 43, 1, 79),
(72, 'attorneys_0_attorney_name', 46, 1, 80),
(73, 'attorneys_0_attorney_name', 47, 1, 80),
(74, 'attorneys_0_attorney_name', 49, 1, 81),
(75, 'attorneys_0_attorney_name', 52, 1, 81),
(76, 'attorneys_0_attorney_name', 53, 1, 81),
(77, 'attorneys_0_attorney_name', 60, 1, 82),
(78, 'attorneys_0_attorney_name', 61, 1, 82),
(79, 'attorneys_0_attorney_name', 75, 1, 83),
(80, 'attorneys_0_attorney_name', 76, 1, 83) ;

#
# End of data contents of table `wp_swp_cf`
# --------------------------------------------------------



#
# Delete any existing table `wp_swp_index`
#

DROP TABLE IF EXISTS `wp_swp_index`;


#
# Table structure of table `wp_swp_index`
#

CREATE TABLE `wp_swp_index` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term` bigint(20) unsigned NOT NULL,
  `content` bigint(20) unsigned NOT NULL DEFAULT '0',
  `title` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment` bigint(20) unsigned NOT NULL DEFAULT '0',
  `excerpt` bigint(20) unsigned NOT NULL DEFAULT '0',
  `slug` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `termindex` (`term`),
  KEY `postidindex` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=309 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_swp_index`
#
INSERT INTO `wp_swp_index` ( `id`, `term`, `content`, `title`, `comment`, `excerpt`, `slug`, `post_id`) VALUES
(232, 1, 0, 1, 0, 0, 1, 75),
(233, 2, 0, 1, 0, 0, 1, 75),
(234, 3, 0, 1, 0, 0, 1, 75),
(235, 4, 1, 0, 0, 0, 0, 75),
(236, 5, 1, 0, 0, 0, 0, 75),
(237, 6, 1, 0, 0, 0, 0, 75),
(238, 7, 3, 0, 0, 0, 0, 75),
(239, 8, 3, 0, 0, 0, 0, 75),
(240, 9, 2, 0, 0, 0, 0, 75),
(241, 10, 0, 0, 0, 0, 0, 75),
(242, 11, 0, 0, 0, 0, 0, 75),
(243, 12, 0, 1, 0, 0, 1, 76),
(244, 13, 0, 1, 0, 0, 1, 76),
(245, 14, 0, 1, 0, 0, 1, 76),
(246, 15, 0, 2, 0, 0, 1, 76),
(247, 16, 0, 2, 0, 0, 1, 76),
(248, 17, 0, 1, 0, 0, 1, 76),
(249, 18, 0, 1, 0, 0, 0, 76),
(250, 19, 3, 0, 0, 0, 0, 76),
(251, 20, 1, 0, 0, 0, 0, 76),
(252, 21, 1, 0, 0, 0, 0, 76),
(253, 22, 1, 0, 0, 0, 0, 76),
(254, 23, 3, 0, 0, 0, 0, 76),
(255, 24, 0, 0, 0, 0, 0, 76),
(256, 25, 0, 0, 0, 0, 0, 76),
(257, 26, 0, 1, 0, 0, 1, 77),
(258, 27, 0, 1, 0, 0, 1, 77),
(259, 28, 0, 1, 0, 0, 1, 78),
(260, 29, 0, 1, 0, 0, 1, 78),
(261, 3, 0, 1, 0, 0, 1, 78),
(262, 30, 3, 0, 0, 0, 0, 78),
(263, 31, 1, 0, 0, 0, 0, 78),
(264, 32, 3, 0, 0, 0, 0, 78),
(265, 33, 1, 0, 0, 0, 0, 78),
(266, 34, 3, 0, 0, 0, 0, 78),
(267, 35, 3, 0, 0, 0, 0, 78),
(268, 36, 2, 0, 0, 0, 0, 78),
(269, 37, 0, 0, 0, 0, 0, 78),
(270, 38, 0, 0, 0, 0, 0, 78),
(271, 40, 0, 1, 0, 0, 1, 79),
(272, 41, 0, 1, 0, 0, 1, 79),
(273, 42, 0, 1, 0, 0, 1, 79),
(274, 43, 0, 0, 0, 0, 0, 79),
(275, 44, 0, 1, 0, 0, 1, 80),
(276, 45, 0, 1, 0, 0, 1, 80),
(277, 46, 0, 1, 0, 0, 1, 80),
(278, 17, 0, 1, 0, 0, 1, 80),
(279, 47, 0, 0, 0, 0, 0, 80),
(280, 49, 0, 2, 0, 0, 1, 81),
(281, 50, 0, 2, 0, 0, 1, 81),
(282, 51, 0, 1, 0, 0, 0, 81),
(283, 52, 0, 0, 0, 0, 0, 81),
(284, 53, 0, 0, 0, 0, 0, 81),
(285, 54, 0, 1, 0, 0, 1, 82),
(286, 55, 0, 1, 0, 0, 1, 82),
(287, 56, 0, 1, 0, 0, 1, 82),
(288, 57, 0, 1, 0, 0, 1, 82),
(289, 58, 0, 1, 0, 0, 1, 82),
(290, 59, 0, 1, 0, 0, 1, 82),
(291, 60, 0, 0, 0, 0, 0, 82),
(292, 61, 0, 0, 0, 0, 0, 82),
(293, 62, 0, 1, 0, 0, 1, 83),
(294, 63, 0, 1, 0, 0, 1, 83),
(295, 64, 0, 1, 0, 0, 1, 83),
(296, 17, 0, 1, 0, 0, 1, 83),
(297, 65, 3, 0, 0, 0, 0, 83),
(298, 66, 1, 0, 0, 0, 0, 83),
(299, 67, 1, 0, 0, 0, 0, 83),
(300, 68, 1, 0, 0, 0, 0, 83),
(301, 69, 3, 0, 0, 0, 0, 83),
(302, 70, 1, 0, 0, 0, 0, 83),
(303, 71, 1, 0, 0, 0, 0, 83),
(304, 72, 3, 0, 0, 0, 0, 83),
(305, 73, 3, 0, 0, 0, 0, 83),
(306, 74, 2, 0, 0, 0, 0, 83),
(307, 75, 0, 0, 0, 0, 0, 83),
(308, 76, 0, 0, 0, 0, 0, 83) ;

#
# End of data contents of table `wp_swp_index`
# --------------------------------------------------------



#
# Delete any existing table `wp_swp_log`
#

DROP TABLE IF EXISTS `wp_swp_log`;


#
# Table structure of table `wp_swp_log`
#

CREATE TABLE `wp_swp_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event` enum('search','action') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'search',
  `query` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tstamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `hits` mediumint(9) unsigned NOT NULL,
  `engine` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `wpsearch` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `eventindex` (`event`),
  KEY `queryindex` (`query`),
  KEY `engineindex` (`engine`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_swp_log`
#
INSERT INTO `wp_swp_log` ( `id`, `event`, `query`, `tstamp`, `hits`, `engine`, `wpsearch`) VALUES
(1, 'search', 'cali', '2018-05-19 19:42:30', 0, 'default', 0),
(2, 'search', 'brow', '2018-05-19 19:51:00', 0, 'default', 0),
(3, 'search', 'brow', '2018-05-19 19:53:27', 0, 'default', 0),
(4, 'search', 'brow', '2018-05-19 19:53:30', 0, 'default', 0),
(5, 'search', 'garrett', '2018-05-19 20:04:10', 1, 'default', 0),
(6, 'search', 'Brown', '2018-05-19 20:04:20', 0, 'default', 0),
(7, 'search', 'jona', '2018-05-19 20:05:06', 0, 'default', 0),
(8, 'search', 'garrett', '2018-05-19 20:08:02', 1, 'default', 0),
(9, 'search', 'brown', '2018-05-19 20:08:08', 0, 'default', 0),
(10, 'search', 'brown', '2018-05-19 20:09:25', 0, 'default', 0),
(11, 'search', 'Garrett', '2018-05-19 20:14:44', 1, 'default', 0),
(12, 'search', 'Garrett\'s Post', '2018-05-19 20:15:00', 1, 'default', 0),
(13, 'search', 'jona', '2018-05-19 20:17:08', 0, 'default', 0),
(14, 'search', 'wtfm', '2018-05-19 20:19:20', 0, 'default', 0),
(15, 'search', 'wtfm', '2018-05-19 20:20:16', 0, 'default', 0),
(16, 'search', 'brown', '2018-05-19 20:21:58', 0, 'default', 0),
(17, 'search', 'brown', '2018-05-19 20:22:46', 0, 'default', 0),
(18, 'search', 'brown', '2018-05-19 20:22:48', 0, 'default', 0),
(19, 'search', 'brown', '2018-05-19 20:22:50', 0, 'default', 0),
(20, 'search', 'Garrett', '2018-05-19 20:22:57', 1, 'default', 0),
(21, 'search', 'Garrett', '2018-05-19 20:27:30', 1, 'default', 0),
(22, 'search', 'wtfman', '2018-05-19 20:27:37', 1, 'default', 0),
(23, 'search', 'yooooooo', '2018-05-19 20:28:59', 1, 'default', 0),
(24, 'search', 'Garrett', '2018-05-19 20:30:53', 1, 'default', 0),
(25, 'search', 'Garrett\'s Post', '2018-05-19 20:31:01', 1, 'default', 0),
(26, 'search', 'Allen', '2018-05-19 20:31:14', 1, 'default', 0),
(27, 'search', 'brown', '2018-05-19 20:31:30', 0, 'default', 0),
(28, 'search', 'Brown', '2018-05-19 20:31:41', 0, 'default', 0),
(29, 'search', 'Allen', '2018-05-19 20:31:47', 1, 'default', 0),
(30, 'search', 'Browne', '2018-05-19 20:32:12', 1, 'default', 0),
(31, 'search', 'Brow', '2018-05-19 20:32:22', 0, 'default', 0),
(32, 'search', 'Brow', '2018-05-19 20:32:26', 0, 'default', 0),
(33, 'search', 'Brow', '2018-05-19 20:32:28', 0, 'default', 0),
(34, 'search', 'Brown', '2018-05-19 20:39:44', 0, 'default', 0),
(35, 'search', 'Brown', '2018-05-19 20:39:46', 0, 'default', 0),
(36, 'search', 'Browne', '2018-05-19 20:39:49', 1, 'default', 0),
(37, 'search', 'George', '2018-05-19 20:40:52', 1, 'default', 0),
(38, 'search', 'Jonathan', '2018-05-19 20:41:02', 1, 'default', 0),
(39, 'search', '(310) 274-7100', '2018-05-19 20:41:28', 0, 'default', 0),
(40, 'search', '(310) 274-7100', '2018-05-19 20:42:49', 0, 'default', 0),
(41, 'search', '(310) 274-7100', '2018-05-19 20:42:54', 0, 'default', 0),
(42, 'search', '(310) 274-7100', '2018-05-19 20:42:56', 0, 'default', 0),
(43, 'search', '(310) 274-7100', '2018-05-19 20:43:01', 0, 'default', 0),
(44, 'search', '7100', '2018-05-19 20:43:31', 0, 'default', 0),
(45, 'search', '(310) 274-7100', '2018-05-19 20:43:55', 0, 'default', 0),
(46, 'search', 'jonathan', '2018-05-19 20:45:05', 1, 'default', 0),
(47, 'search', 'jonathan l.', '2018-05-19 20:45:20', 1, 'default', 0),
(48, 'search', 'george', '2018-05-19 20:45:38', 1, 'default', 0),
(49, 'search', 'goodman', '2018-05-19 20:45:49', 1, 'default', 0),
(50, 'search', 'jonathan', '2018-05-19 20:47:24', 1, 'default', 0) ;

#
# End of data contents of table `wp_swp_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_swp_tax`
#

DROP TABLE IF EXISTS `wp_swp_tax`;


#
# Table structure of table `wp_swp_tax`
#

CREATE TABLE `wp_swp_tax` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `term` int(20) unsigned NOT NULL,
  `count` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taxonomy` (`taxonomy`),
  KEY `term` (`term`),
  KEY `postidindex` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_swp_tax`
#

#
# End of data contents of table `wp_swp_tax`
# --------------------------------------------------------



#
# Delete any existing table `wp_swp_terms`
#

DROP TABLE IF EXISTS `wp_swp_terms`;


#
# Table structure of table `wp_swp_terms`
#

CREATE TABLE `wp_swp_terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(80) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `reverse` varchar(80) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `stem` varchar(80) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `termunique` (`term`),
  KEY `termindex` (`term`(2)),
  KEY `stemindex` (`stem`(2))
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


#
# Data contents of table `wp_swp_terms`
#
INSERT INTO `wp_swp_terms` ( `id`, `term`, `reverse`, `stem`) VALUES
(1, 'agreement', 'tnemeerga', 'agreement'),
(2, 'resources', 'secruoser', 'resourc'),
(3, 'llc', 'cll', 'llc'),
(4, 'walpole', 'eloplaw', 'walpol'),
(5, 'street', 'teerts', 'street'),
(6, 'norwood', 'doowron', 'norwood'),
(7, '02062', '26020', '02062'),
(8, '3356', '6533', '3356'),
(9, '02062-3356', '6533-26020', '02062-3356'),
(10, 'stephen', 'nehpets', 'stephen'),
(11, 'linsky', 'yksnil', 'linski'),
(12, 'akin', 'nika', 'akin'),
(13, 'gump', 'pmug', 'gump'),
(14, 'strauss', 'ssuarts', 'strauss'),
(15, 'hauer', 'reuah', 'hauer'),
(16, 'feld', 'dlef', 'feld'),
(17, 'llp', 'pll', 'llp'),
(18, 'hauer & feld', 'dlef & reuah', 'hauer & feld'),
(19, '1300', '0031', '1300'),
(20, '19th', 'ht91', '19th'),
(21, 'northwest', 'tsewhtron', 'northwest'),
(22, 'washington', 'notgnihsaw', 'washington'),
(23, '20036', '63002', '20036'),
(24, 'jaime', 'emiaj', 'jaim'),
(25, 'fonalledas', 'sadellanof', 'fonalleda'),
(26, 'alan', 'nala', 'alan'),
(27, 'goodman', 'namdoog', 'goodman'),
(28, 'alekman', 'namkela', 'alekman'),
(29, 'ditusa', 'asutid', 'ditusa'),
(30, '1550', '0551', '1550'),
(31, 'main', 'niam', 'main'),
(32, '401', '104', '401'),
(33, 'springfield', 'dleifgnirps', 'springfield'),
(34, '01103', '30110', '01103'),
(35, '1429', '9241', '1429'),
(36, '01103-1429', '9241-30110', '01103-1429'),
(37, 'laura', 'arual', 'laura'),
(38, 'mangini', 'inignam', 'mangini'),
(40, 'allen', 'nella', 'allen'),
(41, 'agnitti', 'ittinga', 'agnitti'),
(42, 'esquire', 'eriuqse', 'esquir'),
(43, 'henry', 'yrneh', 'henri'),
(44, 'allison', 'nosilla', 'allison'),
(45, 'angier', 'reigna', 'angier'),
(46, 'mchale', 'elahcm', 'mchale'),
(47, 'michael', 'leahcim', 'michael'),
(49, 'allyn', 'nylla', 'allyn'),
(50, 'ball', 'llab', 'ball'),
(51, 'allyn & ball', 'llab & nylla', 'allyn & bal'),
(52, 'shawn', 'nwahs', 'shawn'),
(53, 'patrick', 'kcirtap', 'patrick'),
(54, 'american', 'nacirema', 'american'),
(55, 'international', 'lanoitanretni', 'intern'),
(56, 'college', 'egelloc', 'colleg'),
(57, 'holyoke', 'ekoyloh', 'holyok'),
(58, 'com', 'moc', 'com'),
(59, 'coll', 'lloc', 'coll'),
(60, 'corinne', 'enniroc', 'corinn'),
(61, 'rock', 'kcor', 'rock'),
(62, 'browne', 'enworb', 'brown'),
(63, 'george', 'egroeg', 'georg'),
(64, 'ross', 'ssor', 'ross'),
(65, '2121', '1212', '2121'),
(66, 'avenue', 'euneva', 'avenu'),
(67, 'stars', 'srats', 'star'),
(68, 'ste', 'ets', 'ste'),
(69, '2400', '0042', '2400'),
(70, 'los', 'sol', 'lo'),
(71, 'angeles', 'selegna', 'angel'),
(72, '90067', '76009', '90067'),
(73, '5048', '8405', '5048'),
(74, '90067-5048', '8405-76009', '90067-5048'),
(75, 'jonathan', 'nahtanoj', 'jonathan'),
(76, 'gottfried', 'deirfttog', 'gottfri') ;

#
# End of data contents of table `wp_swp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(8, 2, 0),
(8, 3, 0),
(8, 6, 0),
(8, 8, 0),
(9, 4, 0),
(9, 5, 0),
(9, 7, 0),
(9, 9, 0),
(87, 62, 0),
(89, 62, 0),
(89, 63, 0),
(89, 64, 0),
(90, 62, 0),
(90, 94, 0),
(90, 95, 0),
(98, 293, 1),
(98, 294, 2),
(98, 295, 3),
(98, 296, 1),
(98, 297, 2),
(98, 298, 3),
(98, 299, 4),
(98, 300, 5),
(99, 293, 1),
(99, 301, 2),
(99, 302, 3),
(99, 304, 0),
(100, 293, 1),
(100, 294, 2),
(100, 303, 3),
(101, 293, 1),
(101, 294, 2),
(101, 299, 2),
(101, 303, 3),
(101, 304, 1),
(101, 305, 3),
(101, 306, 4),
(101, 307, 5),
(101, 308, 6),
(101, 309, 7),
(101, 310, 8),
(102, 293, 1),
(102, 294, 2),
(102, 303, 3),
(103, 293, 1),
(103, 294, 2),
(103, 311, 3),
(104, 293, 1),
(104, 294, 2),
(104, 312, 3),
(105, 293, 1),
(105, 294, 2),
(105, 313, 3),
(106, 293, 1),
(106, 304, 2),
(106, 314, 2),
(106, 315, 3),
(107, 293, 0),
(107, 297, 0),
(107, 314, 0),
(107, 316, 0),
(107, 318, 0),
(108, 293, 0),
(108, 298, 0),
(108, 304, 0),
(108, 314, 0),
(108, 315, 0),
(118, 293, 0),
(118, 297, 0),
(118, 314, 0),
(118, 315, 0),
(119, 293, 0),
(119, 297, 0),
(119, 314, 0),
(119, 316, 0),
(119, 319, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=320 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'lawfirm-cate', '', 0, 1),
(3, 3, 'lawfirm-cate', '', 2, 1),
(4, 4, 'lawfirm-cate', '', 0, 1),
(5, 5, 'lawfirm-cate', '', 4, 1),
(6, 6, 'lawfirm-cat', '', 0, 1),
(7, 7, 'lawfirm-cat', '', 0, 1),
(8, 8, 'lawfirm-cat', '', 6, 1),
(9, 9, 'lawfirm-cat', '', 7, 1),
(31, 31, 'lawfirmcat', '', 0, 0),
(32, 32, 'lawfirmcat', '', 31, 0),
(33, 33, 'lawfirmcat', '', 0, 0),
(34, 34, 'lawfirmcat', '', 33, 0),
(35, 35, 'lawfirmcat', '', 31, 0),
(36, 36, 'lawfirmcat', '', 31, 0),
(37, 37, 'lawfirmcat', '', 31, 0),
(38, 38, 'lawfirmcat', '', 33, 0),
(39, 39, 'lawfirmcat', '', 31, 0),
(40, 40, 'lawfirmcat', '', 0, 0),
(41, 41, 'lawfirmcat', '', 61, 0),
(43, 43, 'lawfirmtags', '', 0, 0),
(44, 44, 'lawfirmtags', '', 0, 0),
(45, 45, 'lawfirmtags', '', 0, 0),
(46, 46, 'lawfirmtags', '', 0, 0),
(47, 47, 'lawfirmtags', '', 0, 0),
(48, 48, 'lawfirmtags', '', 0, 0),
(49, 49, 'lawfirmtags', '', 0, 0),
(50, 50, 'lawfirmtags', '', 0, 0),
(51, 51, 'lawfirmtags', '', 0, 0),
(52, 52, 'lawfirmtags', '', 0, 0),
(53, 53, 'lawfirmtags', '', 0, 0),
(54, 54, 'lawfirmtags', '', 0, 0),
(55, 55, 'lawfirmtags', '', 0, 0),
(56, 56, 'lawfirmtags', '', 0, 0),
(57, 57, 'lawfirmcat', '', 32, 0),
(58, 58, 'lawfirmcat', '', 38, 0),
(59, 59, 'lawfirmcat', '', 35, 0),
(60, 60, 'lawfirmcat', '', 41, 0),
(61, 61, 'lawfirmcat', '', 40, 0),
(62, 62, 'category', '', 0, 3),
(63, 63, 'category', '', 62, 1),
(64, 64, 'category', '', 63, 1),
(65, 65, 'lawfirmcat', '', 40, 0),
(66, 66, 'lawfirmcat', '', 65, 0),
(94, 94, 'post_tag', '', 0, 1),
(95, 95, 'post_tag', '', 0, 1),
(293, 293, 'lawfirm_locations', '', 0, 13),
(294, 294, 'lawfirm_locations', '', 293, 7),
(295, 295, 'lawfirm_locations', '', 294, 1),
(296, 296, 'lawfirm_practiceareas', '', 0, 1),
(297, 297, 'lawfirm_practiceareas', '', 0, 4),
(298, 298, 'lawfirm_practiceareas', '', 0, 2),
(299, 299, 'lawfirm_practiceareas', '', 0, 2),
(300, 300, 'lawfirm_practiceareas', '', 0, 1),
(301, 301, 'lawfirm_locations', '', 293, 1),
(302, 302, 'lawfirm_locations', '', 301, 1),
(303, 303, 'lawfirm_locations', '', 294, 3),
(304, 304, 'lawfirm_practiceareas', '', 0, 4),
(305, 305, 'lawfirm_practiceareas', '', 0, 1),
(306, 306, 'lawfirm_practiceareas', '', 0, 1),
(307, 307, 'lawfirm_practiceareas', '', 0, 1),
(308, 308, 'lawfirm_practiceareas', '', 0, 1),
(309, 309, 'lawfirm_practiceareas', '', 0, 1),
(310, 310, 'lawfirm_practiceareas', '', 0, 1),
(311, 311, 'lawfirm_locations', '', 294, 1),
(312, 312, 'lawfirm_locations', '', 294, 1),
(313, 313, 'lawfirm_locations', '', 294, 1),
(314, 314, 'lawfirm_locations', '', 293, 5),
(315, 315, 'lawfirm_locations', '', 314, 3),
(316, 316, 'lawfirm_practiceareas', '', 0, 2),
(318, 318, 'lawfirm_locations', '', 314, 1),
(319, 319, 'lawfirm_locations', '', 314, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=320 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'California', 'california', 0),
(3, 'San Diego', 'san-diego', 0),
(4, 'Arizona', 'arizona', 0),
(5, 'Phoenix', 'phoenix', 0),
(6, 'California', 'california', 0),
(7, 'Arizona', 'arizona', 0),
(8, 'San Diego', 'san-diego', 0),
(9, 'Phoenix', 'phoenix', 0),
(31, 'Massachusetts', 'massachusetts', 0),
(32, 'Norwood', 'norwood', 0),
(33, 'Dist. of Columbia', 'dist-of-columbia', 0),
(34, 'Washington', 'washington', 0),
(35, 'Springfield', 'springfield', 0),
(36, 'Amherst', 'amherst', 0),
(37, 'Holyoke', 'holyoke', 0),
(38, 'Dist. of Columbia', 'dist-of-columbia-dist-of-columbia', 0),
(39, 'Agawam', 'agawam', 0),
(40, 'California', 'california', 0),
(41, 'Los Angeles', 'los-angeles', 0),
(43, 'Lawsuits and disputes', 'lawsuits-and-disputes', 0),
(44, 'Arbitration', 'arbitration', 0),
(45, 'Mediation', 'mediation', 0),
(46, 'Family', 'family', 0),
(47, 'Employment and labor', 'employment-and-labor', 0),
(48, 'Litigation', 'litigation', 0),
(49, 'Personal injury', 'personal-injury', 0),
(50, 'Administrative law', 'administrative-law', 0),
(51, 'General practice', 'general-practice', 0),
(52, 'Car accident', 'car-accident', 0),
(53, 'DUI and DWI', 'dui-and-dwi', 0),
(54, 'Motorcycle accident.Trucking accident', 'motorcycle-accident-trucking-accident', 0),
(55, 'Business | Litigation', 'business-litigation', 0),
(56, 'Business', 'business', 0),
(57, '02062-3356', '02062-3356', 0),
(58, '20036', '20036', 0),
(59, '01103-1429', '01103-1429', 0),
(60, '90067-5048', '90067-5048', 0),
(61, 'Los Angeles County', 'los-angeles-county', 0),
(62, 'Cat 1', 'cat-1', 0),
(63, 'cat 2', 'cat-2', 0),
(64, 'cat 3', 'cat-3', 0),
(65, 'Los Angeles', 'los-angeles-california', 0),
(66, '90067-5048', '90067-5048-los-angeles-california', 0),
(94, 'tag 1', 'tag-1', 0),
(95, 'tag 2', 'tag-2', 0),
(293, 'Locations', 'locations', 0),
(294, 'Massachusetts', 'massachusetts', 0),
(295, 'Norwood', 'norwood', 0),
(296, 'Lawsuits and disputes', 'lawsuits-and-disputes', 0),
(297, 'Arbitration', 'arbitration', 0),
(298, 'Mediation', 'mediation', 0),
(299, 'Family', 'family', 0),
(300, 'Employment and labor', 'employment-and-labor', 0),
(301, 'Dist. of Columbia', 'dist-of-columbia', 0),
(302, 'Dist. of Columbia', 'dist-of-columbia-dist-of-columbia-locations', 0),
(303, 'Springfield', 'springfield', 0),
(304, 'Litigation', 'litigation', 0),
(305, 'Personal injury', 'personal-injury', 0),
(306, 'Administrative law', 'administrative-law', 0),
(307, 'General practice', 'general-practice', 0),
(308, 'Car accident', 'car-accident', 0),
(309, 'DUI and DWI', 'dui-and-dwi', 0),
(310, 'Motorcycle accident.Trucking accident', 'motorcycle-accident-trucking-accident', 0),
(311, 'Amherst', 'amherst', 0),
(312, 'Holyoke', 'holyoke', 0),
(313, 'Agawam', 'agawam', 0),
(314, 'California', 'california', 0),
(315, 'Los Angeles', 'los-angeles', 0),
(316, 'Business', 'business', 0),
(318, 'San Diego', 'san-diego', 0),
(319, 'San Elijo', 'san-elijo', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(20, 2, 'nickname', '1p21.admin'),
(21, 2, 'first_name', 'Garrett'),
(22, 2, 'last_name', 'Cullen'),
(23, 2, 'description', ''),
(24, 2, 'rich_editing', 'true'),
(25, 2, 'syntax_highlighting', 'true'),
(26, 2, 'comment_shortcuts', 'false'),
(27, 2, 'admin_color', 'fresh'),
(28, 2, 'use_ssl', '0'),
(29, 2, 'show_admin_bar_front', 'true'),
(30, 2, 'locale', ''),
(31, 2, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(32, 2, 'wp_user_level', '10'),
(33, 2, 'dismissed_wp_pointers', 'pksn1,wp496_privacy,custom-post-type-permalinks-settings'),
(34, 2, 'session_tokens', 'a:1:{s:64:"ec0992ffcf03ad3ed6fa34fb429dbffe43071cda48317b7bd919007fd822cc34";a:4:{s:10:"expiration";i:1531496242;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36";s:5:"login";i:1531323442;}}'),
(35, 2, 'wp_dashboard_quick_press_last_post_id', '117'),
(36, 2, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}'),
(37, 2, 'closedpostboxes_lawfirm', 'a:0:{}'),
(38, 2, 'metaboxhidden_lawfirm', 'a:3:{i:0;s:12:"postimagediv";i:1;s:11:"postexcerpt";i:2;s:7:"slugdiv";}'),
(39, 2, 'wp_user-settings', 'editor=tinymce'),
(40, 2, 'wp_user-settings-time', '1526778217'),
(41, 2, 'acf_user_settings', 'a:0:{}'),
(42, 2, 'edit_lawfirm_per_page', '200') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(2, '1p21.admin', '$P$BGTGoBHr/0dY/BevmY7NjBPAtedv9b1', '1p21-admin', 'garrett@1point21interactive.com', '', '2018-05-10 16:59:24', '', 0, 'Garrett Cullen') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

